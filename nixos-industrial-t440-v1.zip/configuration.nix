{ ... }:

{
  # Safety-first overlay:
  # keep the machine's existing NixOS configuration and add Industrial/Niri.
  #
  # Nothing in this repository invents disk UUIDs, boot settings, users,
  # passwords, or hardware-configuration.nix.
  imports = [
    /etc/nixos/configuration.nix
    ./modules/industrial.nix
  ];
}

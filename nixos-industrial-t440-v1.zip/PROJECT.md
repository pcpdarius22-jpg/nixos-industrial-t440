# Project: Niri Industrial / ThinkPad T440

## Source of truth

This document describes the intended product. Code changes should preserve these goals unless a newer explicit decision replaces them.

## Machine

Primary target: Lenovo ThinkPad T440 with Intel integrated graphics.

The machine is performance-constrained by modern standards. The UI must get its identity from layout, typography, line work and interaction rather than expensive blur, large shadows or decorative compositing.

## The look

The target is the dark Industrial reference:

- near-black surface
- thin graphite borders
- off-white monospace text
- restrained burnt-orange accent
- a dark wireframe terrain / technical-grid wallpaper
- square corners
- small instrumentation
- large areas of intentional emptiness

It must not drift into:
- paper-white themes
- glassmorphism
- neon cyberpunk
- rounded dashboard cards
- huge widgets
- generic gaming HUDs

## Default desktop

At rest, the desktop should feel almost empty.

Always visible:
- workspace position, conceptually `0/7`
- centered time
- very small system indicators

Hidden until interaction:
- top edge: system overview
- left edge: workspaces
- right edge: context
- bottom edge: launcher

The edge panels should feel like parts of the machine becoming available, not four permanent application windows.

## Workspace model

Seven named Niri workspaces:

0. work
1. web
2. music
3. reader
4. code
5. comm
6. files

Niri remains Niri: scrolling tiling and its normal column model should be respected rather than forcing it to imitate Sway.

## Motion

Motion is functional and short.

Good:
- panel slides from an edge
- focused workspace indicator moves
- clock change can later get a subtle digit transition
- wallpaper reaction can later be introduced carefully

Bad:
- bounce
- long easing
- gratuitous blur
- constant movement
- distracting animated wallpaper

## Performance rules

Before adding a daemon or framework, ask whether it needs to run all the time.

Prefer:
- event-driven Niri IPC
- low-frequency status sampling only where needed
- native Wayland
- no shadows
- no blur
- small dependency surface

## System architecture

Niri must come from the installed NixOS generation.

Never revive the old design where a TTY script enters `nix shell`, downloads another Niri/Mesa stack, and launches that temporary compositor against the real display hardware.

The first installation path overlays the existing `/etc/nixos/configuration.nix` rather than replacing the whole machine configuration.

## Safety workflow

1. edit repository
2. run `bash scripts/test`
3. validate config
4. launch `industrial-niri-session`
5. visually inspect on the T440
6. refine live files
7. only when accepted: `bash scripts/apply`

`test` must remain temporary. `apply` is the explicit permanent step.

## Live iteration

Once the base session works:

- Niri config lives at `niri/config.kdl`
- Quickshell config lives at `quickshell/shell.qml`
- both are run directly from the Git checkout
- save/edit/inspect should be fast

The desired working loop is:

`Niri desktop → Foot → Codex/editor → save → live reload → look → refine`

TTY is recovery, not the design studio.

## First milestone

Do not try to complete every panel feature in v1.

v1 succeeds if:

- the installed NixOS Niri session starts reliably
- Foot/Fuzzel work
- seven named workspaces work
- the dark Industrial wallpaper and top instrumentation bar appear
- the four edge interactions appear
- UI files can be edited and reloaded live
- reboot recovery remains simple

Only after this baseline is proven should deeper music/context controls, notifications, lock screen, wallpaper reactions and boot visuals be added.

# Industrial UI notes

Reference characteristics:

- black / graphite base
- orange used only for state and focus
- fine monochrome technical line work
- centered clock with a small axis/crosshair accent
- top status bar visually hugs the display
- edge panels reveal on hover
- square geometry
- small monospace labels
- no decorative cards at rest

## v1 panel behavior

Top:
- 30 px persistent
- expands downward on hover
- system summary in five instrument cells

Left:
- 3 px hot edge
- expands into a 7-workspace rail

Right:
- 3 px hot edge
- expands into context/status

Bottom:
- 3 px hot edge
- expands into quick-launch strip

This is intentionally a first functional approximation. Once it is running on
the physical 1366×768 T440 screen, spacing and proportions should be refined
visually rather than guessed in advance.

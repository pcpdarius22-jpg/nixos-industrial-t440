{ pkgs, ... }:

let
  industrialNiriSession = pkgs.writeShellScriptBin "industrial-niri-session" ''
    set -eu

    root="''${INDUSTRIAL_REPO:-$HOME/nixos-industrial-t440}"
    config="$root/niri/config.kdl"

    if [ ! -r "$config" ]; then
      echo "Industrial Niri config not found: $config" >&2
      echo "Clone the repository to ~/nixos-industrial-t440 or set INDUSTRIAL_REPO." >&2
      exit 1
    fi

    export NIRI_CONFIG="$config"
    exec ${pkgs.niri}/bin/niri-session
  '';
in
{
  # Use NixOS' own Niri integration so the compositor and graphics stack
  # belong to the same NixOS generation.
  programs.niri = {
    enable = true;
    # Keep the base system lean: use GTK rather than pulling Nautilus in
    # only as a portal file chooser.
    useNautilus = false;
  };

  # Quickshell's battery service talks to UPower.
  services.upower.enable = true;

  environment.systemPackages = with pkgs; [
    industrialNiriSession

    # Core desktop
    quickshell
    foot
    fuzzel
    xwayland-satellite
    swaybg
    mako

    # Small desktop utilities
    wl-clipboard
    grim
    slurp
    brightnessctl
    playerctl
    wireplumber
    iproute2
    jq

    # User-facing tools for the first usable build
    yazi
    btop
    qutebrowser
  ];
}

import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Services.UPower

ShellRoot {
    id: root

    readonly property color bg: "#0a0d0f"
    readonly property color bg2: "#0d1114"
    readonly property color line: "#2a3238"
    readonly property color text: "#c9ced1"
    readonly property color dim: "#747c81"
    readonly property color orange: "#e2632f"

    property var workspaceNames: ["work", "web", "music", "reader", "code", "comm", "files"]
    property int workspaceIndex: 0
    property string workspaceName: "work"
    property string activeTitle: "DESKTOP"
    property string activeApp: "niri"
    property var windowsById: ({})
    property string volumeText: "--"
    property string netText: "--"

    function workspaceNumber(name) {
        for (var i = 0; i < workspaceNames.length; ++i)
            if (workspaceNames[i] === name)
                return i
        return -1
    }

    function setFocusedWindow(win) {
        if (!win)
            return
        activeTitle = (win.title && win.title.length > 0) ? win.title : "UNTITLED"
        activeApp = (win.app_id && win.app_id.length > 0) ? win.app_id : "unknown"
    }

    function handleNiriEvent(lineText) {
        if (!lineText || lineText.length === 0)
            return

        try {
            var event = JSON.parse(lineText)

            if (event.WorkspacesChanged) {
                var workspaces = event.WorkspacesChanged.workspaces
                for (var i = 0; i < workspaces.length; ++i) {
                    var ws = workspaces[i]
                    if (ws.is_focused) {
                        var n = workspaceNumber(ws.name)
                        if (n >= 0) {
                            workspaceIndex = n
                            workspaceName = ws.name
                        }
                    }
                }
            }

            if (event.WorkspaceActivated && event.WorkspaceActivated.focused) {
                // A later WorkspacesChanged carries the name; keep the current
                // display stable until that state arrives.
            }

            if (event.WindowsChanged) {
                var next = ({})
                var windows = event.WindowsChanged.windows
                for (var j = 0; j < windows.length; ++j) {
                    next[String(windows[j].id)] = windows[j]
                    if (windows[j].is_focused)
                        setFocusedWindow(windows[j])
                }
                windowsById = next
                if (windows.length === 0) {
                    activeTitle = "DESKTOP"
                    activeApp = "niri"
                }
            }

            if (event.WindowOpenedOrChanged) {
                var changed = event.WindowOpenedOrChanged.window
                var copy = ({})
                for (var key in windowsById)
                    copy[key] = windowsById[key]
                copy[String(changed.id)] = changed
                windowsById = copy
                if (changed.is_focused)
                    setFocusedWindow(changed)
            }

            if (event.WindowClosed) {
                var kept = ({})
                for (var k in windowsById)
                    if (k !== String(event.WindowClosed.id))
                        kept[k] = windowsById[k]
                windowsById = kept
            }

            if (event.WindowFocusChanged) {
                var id = event.WindowFocusChanged.id
                if (id === null) {
                    activeTitle = "DESKTOP"
                    activeApp = "niri"
                } else {
                    setFocusedWindow(windowsById[String(id)])
                }
            }
        } catch (error) {
            console.log("industrial: ignored niri event:", error)
        }
    }

    function run(command) {
        Quickshell.execDetached(["sh", "-lc", command])
    }

    SystemClock {
        id: clock
        precision: SystemClock.Seconds
    }

    Process {
        id: niriEvents
        running: true
        command: ["niri", "msg", "--json", "event-stream"]

        stdout: SplitParser {
            onRead: data => root.handleNiriEvent(data)
        }

        onRunningChanged: {
            if (!running)
                reconnect.start()
        }
    }

    Timer {
        id: reconnect
        interval: 1200
        repeat: false
        onTriggered: niriEvents.running = true
    }

    // Low-frequency status sampling only. Niri state itself is event-driven.
    Timer {
        interval: 3000
        repeat: true
        running: true
        triggeredOnStart: true
        onTriggered: {
            if (!volumeProbe.running)
                volumeProbe.running = true
            if (!netProbe.running)
                netProbe.running = true
        }
    }

    Process {
        id: volumeProbe
        command: ["sh", "-lc",
            "if command -v wpctl >/dev/null 2>&1; then " +
            "wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null | " +
            "awk '{ if ($0 ~ /MUTED/) { print \"MUTE\" } else { printf \"%d%%\\n\", $2 * 100 } }'; " +
            "else printf '%s\\n' '--'; fi"
        ]
        stdout: StdioCollector {
            onStreamFinished: root.volumeText = this.text.trim()
        }
    }

    Process {
        id: netProbe
        command: ["sh", "-lc",
            "dev=$(ip route 2>/dev/null | awk '/default/ {print $5; exit}'); " +
            "if [ -n \"$dev\" ]; then printf '%s\\n' \"$dev\"; else printf '%s\\n' '--'; fi"
        ]
        stdout: StdioCollector {
            onStreamFinished: root.netText = this.text.trim()
        }
    }

    Variants {
        model: Quickshell.screens

        delegate: PanelWindow {
            id: topPanel
            required property var modelData
            screen: modelData

            anchors {
                top: true
                left: true
                right: true
            }

            property bool expanded: topMouse.containsMouse
            implicitHeight: expanded ? 174 : 30
            exclusiveZone: 30
            color: root.bg
            aboveWindows: true

            Behavior on implicitHeight {
                NumberAnimation { duration: 135 }
            }

            Rectangle {
                anchors.fill: parent
                color: root.bg
                border.color: root.line
                border.width: 1
            }

            MouseArea {
                id: topMouse
                anchors.fill: parent
                hoverEnabled: true
                acceptedButtons: Qt.NoButton
            }

            Item {
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                }
                height: 30

                Text {
                    anchors {
                        left: parent.left
                        leftMargin: 18
                        verticalCenter: parent.verticalCenter
                    }
                    text: root.workspaceIndex + "/7"
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 13
                }

                Text {
                    anchors {
                        left: parent.left
                        leftMargin: 64
                        verticalCenter: parent.verticalCenter
                    }
                    text: "····························"
                    color: root.dim
                    font.family: "monospace"
                    font.pixelSize: 11
                }

                Rectangle {
                    anchors {
                        left: parent.left
                        leftMargin: 151
                        verticalCenter: parent.verticalCenter
                    }
                    width: 3
                    height: 3
                    color: root.orange
                }

                Text {
                    anchors.centerIn: parent
                    text: Qt.formatDateTime(clock.date, "HH:mm")
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 17
                    font.letterSpacing: 2
                }

                Rectangle {
                    anchors.centerIn: parent
                    width: 1
                    height: 22
                    color: root.orange
                    opacity: 0.42
                }

                Text {
                    anchors {
                        right: parent.right
                        rightMargin: 18
                        verticalCenter: parent.verticalCenter
                    }
                    text: "VOL " + root.volumeText
                        + "    BAT "
                        + (UPower.displayDevice.ready ? Math.round(UPower.displayDevice.percentage) + "%" : "--")
                        + "    NET " + root.netText
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 11
                }
            }

            Rectangle {
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                    topMargin: 29
                }
                height: 1
                color: root.line
            }

            RowLayout {
                visible: topPanel.expanded
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                    topMargin: 46
                    leftMargin: 22
                    rightMargin: 22
                }
                spacing: 1

                Repeater {
                    model: [
                        ["AUDIO", root.volumeText, "DEFAULT SINK"],
                        ["BATTERY",
                         UPower.displayDevice.ready ? Math.round(UPower.displayDevice.percentage) + "%" : "--",
                         UPower.onBattery ? "DISCHARGING" : "AC / CHARGING"],
                        ["NETWORK", root.netText, "ACTIVE LINK"],
                        ["WORKSPACE", root.workspaceName.toUpperCase(), root.workspaceIndex + "/7"],
                        ["CONTEXT", root.activeApp.toUpperCase(), root.activeTitle]
                    ]

                    delegate: Rectangle {
                        required property var modelData
                        Layout.fillWidth: true
                        Layout.preferredHeight: 105
                        color: root.bg2
                        border.color: root.line
                        border.width: 1

                        Column {
                            anchors {
                                fill: parent
                                margins: 13
                            }
                            spacing: 10

                            Text {
                                text: modelData[0]
                                color: root.dim
                                font.family: "monospace"
                                font.pixelSize: 10
                            }
                            Text {
                                text: modelData[1]
                                color: root.orange
                                font.family: "monospace"
                                font.pixelSize: 16
                                elide: Text.ElideRight
                                width: parent.width
                            }
                            Text {
                                text: modelData[2]
                                color: root.text
                                opacity: 0.76
                                font.family: "monospace"
                                font.pixelSize: 10
                                elide: Text.ElideRight
                                width: parent.width
                            }
                        }
                    }
                }
            }
        }
    }

    Variants {
        model: Quickshell.screens

        delegate: PanelWindow {
            id: leftPanel
            required property var modelData
            screen: modelData

            anchors {
                left: true
                top: true
                bottom: true
            }

            property bool expanded: leftMouse.containsMouse
            implicitWidth: expanded ? 172 : 3
            exclusiveZone: 0
            color: "transparent"
            aboveWindows: true

            Behavior on implicitWidth {
                NumberAnimation { duration: 135 }
            }

            Rectangle {
                anchors.fill: parent
                color: leftPanel.expanded ? root.bg : "transparent"
                border.color: leftPanel.expanded ? root.line : "transparent"
                border.width: 1
            }

            MouseArea {
                id: leftMouse
                anchors.fill: parent
                hoverEnabled: true
                acceptedButtons: Qt.NoButton
            }

            Column {
                visible: leftPanel.expanded
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                    topMargin: 58
                    leftMargin: 12
                    rightMargin: 12
                }
                spacing: 3

                Text {
                    text: "WORKSPACES   " + root.workspaceIndex + "/7"
                    color: root.dim
                    font.family: "monospace"
                    font.pixelSize: 10
                    height: 28
                }

                Repeater {
                    model: root.workspaceNames

                    delegate: Rectangle {
                        required property string modelData
                        required property int index
                        width: 146
                        height: 34
                        color: index === root.workspaceIndex ? "#151313" : "transparent"
                        border.color: index === root.workspaceIndex ? root.orange : "transparent"
                        border.width: index === root.workspaceIndex ? 1 : 0

                        Text {
                            anchors {
                                left: parent.left
                                leftMargin: 10
                                verticalCenter: parent.verticalCenter
                            }
                            text: index + "  " + modelData.toUpperCase()
                            color: index === root.workspaceIndex ? root.orange : root.text
                            font.family: "monospace"
                            font.pixelSize: 11
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: root.run("niri msg action focus-workspace " + modelData)
                        }
                    }
                }
            }
        }
    }

    Variants {
        model: Quickshell.screens

        delegate: PanelWindow {
            id: rightPanel
            required property var modelData
            screen: modelData

            anchors {
                right: true
                top: true
                bottom: true
            }

            property bool expanded: rightMouse.containsMouse
            implicitWidth: expanded ? 286 : 3
            exclusiveZone: 0
            color: "transparent"
            aboveWindows: true

            Behavior on implicitWidth {
                NumberAnimation { duration: 135 }
            }

            Rectangle {
                anchors.fill: parent
                color: rightPanel.expanded ? root.bg : "transparent"
                border.color: rightPanel.expanded ? root.line : "transparent"
                border.width: 1
            }

            MouseArea {
                id: rightMouse
                anchors.fill: parent
                hoverEnabled: true
                acceptedButtons: Qt.NoButton
            }

            Column {
                visible: rightPanel.expanded
                anchors {
                    fill: parent
                    margins: 18
                    topMargin: 58
                }
                spacing: 12

                Text {
                    text: "CONTEXT / " + root.workspaceName.toUpperCase()
                    color: root.orange
                    font.family: "monospace"
                    font.pixelSize: 11
                }

                Rectangle {
                    width: parent.width
                    height: 1
                    color: root.line
                }

                Text {
                    text: root.activeApp
                    color: root.dim
                    font.family: "monospace"
                    font.pixelSize: 10
                    width: parent.width
                    elide: Text.ElideRight
                }

                Text {
                    text: root.activeTitle
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 15
                    wrapMode: Text.Wrap
                    width: parent.width
                }

                Item { width: 1; height: 18 }

                Text {
                    text: "SYSTEM"
                    color: root.dim
                    font.family: "monospace"
                    font.pixelSize: 10
                }

                Text {
                    text: "audio     " + root.volumeText
                        + "\nbattery   "
                        + (UPower.displayDevice.ready ? Math.round(UPower.displayDevice.percentage) + "%" : "--")
                        + "\nnetwork   " + root.netText
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 11
                    lineHeight: 1.55
                }

                Rectangle {
                    width: parent.width
                    height: 1
                    color: root.line
                }

                Text {
                    text: "The context panel is intentionally\nquiet in v1. App-specific controls\ncan be added after the base session\nis proven stable on the T440."
                    color: root.dim
                    font.family: "monospace"
                    font.pixelSize: 10
                    lineHeight: 1.35
                }
            }
        }
    }

    Variants {
        model: Quickshell.screens

        delegate: PanelWindow {
            id: bottomPanel
            required property var modelData
            screen: modelData

            anchors {
                left: true
                right: true
                bottom: true
            }

            property bool expanded: bottomMouse.containsMouse
            implicitHeight: expanded ? 142 : 3
            exclusiveZone: 0
            color: "transparent"
            aboveWindows: true

            Behavior on implicitHeight {
                NumberAnimation { duration: 135 }
            }

            Rectangle {
                anchors.fill: parent
                color: bottomPanel.expanded ? root.bg : "transparent"
                border.color: bottomPanel.expanded ? root.line : "transparent"
                border.width: 1
            }

            MouseArea {
                id: bottomMouse
                anchors.fill: parent
                hoverEnabled: true
                acceptedButtons: Qt.NoButton
            }

            ColumnLayout {
                visible: bottomPanel.expanded
                anchors {
                    fill: parent
                    margins: 18
                }
                spacing: 10

                Rectangle {
                    Layout.fillWidth: true
                    Layout.preferredHeight: 36
                    color: root.bg2
                    border.color: root.line
                    border.width: 1

                    Text {
                        anchors {
                            left: parent.left
                            leftMargin: 14
                            verticalCenter: parent.verticalCenter
                        }
                        text: "⌕  Super+D  /  type to launch"
                        color: root.dim
                        font.family: "monospace"
                        font.pixelSize: 11
                    }

                    MouseArea {
                        anchors.fill: parent
                        onClicked: root.run("fuzzel")
                    }
                }

                RowLayout {
                    Layout.fillWidth: true
                    spacing: 1

                    Repeater {
                        model: [
                            ["TERM", "foot"],
                            ["FILES", "foot -e yazi"],
                            ["WEB", "qutebrowser"],
                            ["MONITOR", "foot -e btop"],
                            ["APPS", "fuzzel"],
                            ["OVERVIEW", "niri msg action toggle-overview"]
                        ]

                        delegate: Rectangle {
                            required property var modelData
                            Layout.fillWidth: true
                            Layout.preferredHeight: 58
                            color: root.bg2
                            border.color: root.line
                            border.width: 1

                            Text {
                                anchors.centerIn: parent
                                text: modelData[0]
                                color: root.text
                                font.family: "monospace"
                                font.pixelSize: 11
                            }

                            MouseArea {
                                anchors.fill: parent
                                onClicked: root.run(modelData[1])
                            }
                        }
                    }
                }
            }
        }
    }
}

# NixOS Industrial T440

A dark, minimal NixOS + Niri environment for the ThinkPad T440.

This repository deliberately **does not replace your machine-specific NixOS configuration**. It overlays the Industrial desktop on top of the configuration already installed at `/etc/nixos/configuration.nix`.

That means this repo does **not** invent:

- disk UUIDs
- boot loader settings
- users/passwords
- `hardware-configuration.nix`
- network setup
- `system.stateVersion`

## First test — safe path

Keep any older local experiment as a backup, then clone this repo cleanly:

```bash
cd ~
mv nixos-industrial-t440 nixos-industrial-t440-codex-backup
git clone https://github.com/pcpdarius22-jpg/nixos-industrial-t440.git
cd nixos-industrial-t440
```

Activate a **temporary running generation**:

```bash
bash scripts/test
```

The script uses `nixos-rebuild test`, not `switch`.

If the rebuild succeeds, validate the Niri config:

```bash
bash scripts/validate
```

Then, from the TTY, start the NixOS-installed session:

```bash
industrial-niri-session
```

Do **not** use the old `preview.sh`. This repo does not need a temporary `nix shell` compositor.

If the graphical session fails badly, reboot. Because the first step used `nixos-rebuild test`, that test generation is not made the default boot generation.

## Make it permanent

Only after you have actually used the graphical session and want to keep it:

```bash
bash scripts/apply
```

That uses `nixos-rebuild switch` with this overlay.

For later rebuilds, keep using this repository's scripts unless/until the Industrial module is deliberately merged into `/etc/nixos`.

## Live editing

The live files remain in the Git checkout:

- `niri/config.kdl`
- `quickshell/shell.qml`

Niri reloads its configuration when it changes. Quickshell watches its config and reloads it.

So the intended later workflow is:

1. boot into the working Niri session
2. open Foot
3. edit files in this repo (manually or with Codex)
4. save
5. inspect the result on the actual T440
6. repeat

A full NixOS rebuild is only needed when changing the **installed package/system module**, not for every UI spacing/color edit.

## Core bindings

| Binding | Action |
|---|---|
| `Super+T` | Foot |
| `Super+D` | Fuzzel |
| `Super+O` | Niri overview |
| `Super+Q` | Close window |
| `Super+R` | Reload repo Niri config |
| `Super+1..7` | Focus named workspace |
| `Super+Shift+1..7` | Move column to named workspace |
| `Super+H/J/K/L` or arrows | Navigate |
| `Super+Ctrl+H/J/K/L` | Move windows/columns |
| `Super+Shift+E` | Exit Niri |

## Edge UI

Persistent:
- thin top instrumentation bar
- `0/7` workspace position
- centered clock
- quiet audio, battery and network indicators

Hover:
- top edge → system overview
- left edge → workspace rail
- right edge → context panel
- bottom edge → launcher strip

## Recovery

The TTY is a recovery path, not the intended development environment.

If a graphical experiment misbehaves:

1. try `Super+Shift+E`
2. try another TTY with `Ctrl+Alt+F3`
3. reboot if necessary

Do not run a second temporary Niri/Mesa stack from `nix shell` on the real TTY.

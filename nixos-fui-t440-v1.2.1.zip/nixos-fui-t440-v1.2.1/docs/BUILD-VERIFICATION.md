# FUI v1.2 build verification record

This record separates source/static verification from checks that can only be
performed by the actual NixOS generation and the 1600×900 ThinkPad panel.

## Pinned software facts

The flake pins nixpkgs to:

`70cc4559b10a6062b05ff1af17e0add065ccaed9`

At that revision the configuration targets:

- Niri 26.04.
- Quickshell 0.3.0.
- Foot 1.27.0.
- Ardour 9.7 (`ardour9` is the package main program).
- NixOS Niri module session/systemd/portal integration.
- NixOS Fontconfig `defaultFonts` support.

## Source checks completed before packaging

- Project-owned Python parsed successfully.
- Every project shell script passed `bash -n`.
- Foot INI structural checks include the previous cursor-color regression.
- Every QML file passed brace/parenthesis/bracket structural checks.
- Niri KDL structural/safety checks and duplicate-bind detection passed.
- Exact image dimensions passed: reference/wallpaper 1600×900; city crop 548×325.
- Reference layout coordinate-anchor regressions passed.
- Launcher defaults closed; command-mode IPC and keyboard navigation checks passed.
- IP subprocess caching regression check passed.
- Multi-battery aggregation still refuses to mix energy and charge units.
- MPRIS progress/unit checks, swap meter and whole-disk detection checks passed.
- Deterministic Fontconfig declarations, toolkit/cursor fallbacks and guaranteed
  Ardour dependency checks passed.
- Reactive wallpaper source is checked for conditional data-driven motion, real workspace-node actions, and explicit absence of ShaderEffect/particle/video wallpaper paths.
- Interactive wallpaper uses static Qt Quick Shapes for routes and small conditional item animations rather than a continuously repainted full-screen Canvas.
- Guarded startup checks require TTY preflight, live Niri output verification,
  Quickshell IPC readiness and a failure diagnostic path.
- Project source is covered by `SOURCE-MANIFEST.sha256`; `host-base/` and the
  generated `flake.lock` are intentionally excluded because installation
  replaces/generates them.

## What the installer proves on the laptop before graphics

`install.sh`:

1. replaces the empty/ignored `host-base/` with a copy of the current
   `/etc/nixos` (the root-level placeholder exists only for clear pre-install
   evaluation errors);
2. locks the exact flake input;
3. runs source-manifest + regression checks;
4. builds the pinned core-config check (`niri validate`, `foot -C`);
5. evaluates the complete NixOS system derivation;
6. activates only `nixos-rebuild test`;
7. repeats installed Niri/Foot checks;
8. runs `fui-preflight` against installed executables, real Fontconfig and DRM
   mode advertisement.

## What `fui-session` / `fui-bootstrap` prove live

Before entering Niri, `fui-session` reruns the preflight.

Inside Niri, `fui-runtime-check`:

- reads real Niri output JSON;
- requires the internal target to be 1600×900 logical pixels at scale 1;
- rechecks all expected font-family resolutions;
- verifies shell image assets, the three installed reactive-wallpaper QML components and the installed Foot config;
- records NetworkManager, PipeWire/WirePlumber and battery-source status as
  live checks/warnings.

Then `fui-bootstrap` launches Quickshell and requires its IPC endpoint to answer
before any staged home windows are opened. On success it records the exact
`/run/current-system` target in `~/.local/state/fui/runtime-ok`.

`scripts/apply` accepts that marker only when it matches the still-active test
generation, in addition to the explicit `APPLY` confirmation.

## What still requires human acceptance on the physical T440

Static/source checks cannot prove the final rasterized pixels, real GPU/DRM
behavior, input feel, suspend/resume, speaker/microphone behavior, Bluetooth,
network roaming, third-party application rendering or sustained performance.
Those items remain in `TEST-CHECKLIST.md`.

The goal is to make software/configuration mistakes fail early and recoverably,
not to rename an untested generation “perfect.”

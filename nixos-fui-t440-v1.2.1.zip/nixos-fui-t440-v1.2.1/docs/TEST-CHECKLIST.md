# Real ThinkPad acceptance checklist — v1.2

Do **not** run `scripts/apply` until these pass on the laptop itself.

## Preflight / recovery

- [ ] `fui-preflight` resolves JetBrains Mono, Noto Sans, Noto Serif and Noto Color Emoji correctly.
- [ ] It detects/accepts the internal 1600×900 DRM mode.
- [ ] `fui-session` starts from a spare TTY without login-shell recursion.
- [ ] Niri runtime check reports 1600×900 logical, scale 1.
- [ ] Quickshell IPC reaches ready state; `~/.local/state/fui/runtime-ok` is created.
- [ ] Killing Quickshell does not kill Niri; `Super+Shift+D` restarts the shell.
- [ ] `Super+Alt+D` opens Fuzzel with Quickshell dead.
- [ ] `Super+T` opens Foot with Quickshell dead.
- [ ] `Super+Shift+Q` and backup `Super+Shift+E` return cleanly to TTY.
- [ ] Reboot after a test generation returns to the previous permanent generation.

## Exact 1600×900 visual target

- [ ] Wallpaper, top strip and left/right rails appear; launcher starts closed.
- [ ] `Super+D` opens the bottom command surface in the reference position.
- [ ] Top strip is 36px high and unclipped.
- [ ] Left rail is 98px wide and all command buttons fit.
- [ ] Terminal outer frame begins at ~`136,158`, size ~`475×382`.
- [ ] Real Foot content fills the terminal frame beneath its drawn header without grid-snap gaps.
- [ ] Notes outer frame begins at ~`136,560`, size ~`350×195`.
- [ ] Now Playing card begins at ~`673,181`.
- [ ] City feed begins at ~`650,369`, size ~`603×388`.
- [ ] Right SYSTEM frame is ~`x=1358..1585`, `y=105..708`.
- [ ] Separate QUOTE frame is ~`x=1358..1585`, `y=721..857`.
- [ ] Bottom command surface begins at ~`x=272`, size ~`1056×121` when open.
- [ ] No unexpected CSD/titlebars, rounded corners, blur or compositor shadows.
- [ ] JetBrains Mono weight/spacing visually matches the reference at 1600×900.
- [ ] Take a 1600×900 screenshot and compare directly with `docs/reference-1600x900.png`.

## Reactive wallpaper interaction

- [ ] At idle, the underlying wallpaper image remains correctly aligned; the new grid/routes/nodes stay subtle and do not displace the base image.
- [ ] Moving the pointer over empty wallpaper creates only subtle grid/network parallax and the small cursor lens.
- [ ] Dragging empty wallpaper moves the network field within a limited range and it eases back on release.
- [ ] Hovering MAIN/DEV/MEDIA/READ/MISC signal nodes reveals them; clicking each selects the matching real workspace.
- [ ] Clicking the NET node opens the network control.
- [ ] Route dots animate only while real network activity is present.
- [ ] MPRIS playback produces the restrained MEDIA resonance; stopping playback removes it.
- [ ] `Super+Shift+W` freezes wallpaper motion without breaking the shell or apps.
- [ ] Settings can toggle wallpaper interaction; disabling it stops wallpaper hover/click/drag behavior.
- [ ] With motion enabled, `qs` does not sustain abnormal CPU/GPU load on the T440.

## Launcher and shell interaction

- [ ] `Super+D` toggles the launcher and `Escape` closes it.
- [ ] Left/Right and Tab move the highlighted launcher mode; Enter executes it.
- [ ] Installed application names produce real desktop-entry results.
- [ ] `Super+R` opens `>` command mode without the input being reset.
- [ ] Left rail buttons open terminal/files/browser/music/reader/settings.
- [ ] Workspace tabs are clickable and match the active workspace.

## Input / workspaces

- [ ] Keyboard layout is correct.
- [ ] Touchpad tap-to-click works.
- [ ] TrackPoint works.
- [ ] `Super+Left/Right` changes workspaces.
- [ ] `Super+1..5` selects MAIN/DEV/MEDIA/READ/MISC.
- [ ] `Super+Ctrl+1..5` moves a window to the intended workspace.
- [ ] Volume/mute/microphone/brightness hardware keys work.

## Daily-driver functions

- [ ] NetworkManager works and live interface/IP/rates populate.
- [ ] Bluetooth manager connects a device.
- [ ] PipeWire output/input works; `wpctl`, Pavucontrol and qpwgraph work.
- [ ] qutebrowser launches; Firefox fallback launches.
- [ ] Yazi, Neovim, Zathura/Foliate and MPV launch.
- [ ] **Ardour 9 launches from `Super+M`** (or REAPER if the optional package is preferred/available).
- [ ] An X11/legacy application launches through xwayland-satellite.
- [ ] MPRIS title/artist/progress/length update while media is playing.
- [ ] `Super+L` locks and unlocks successfully.
- [ ] Suspend/resume restores display, input, audio and network.

## Performance

- [ ] Idle shell stays responsive for at least 10 minutes.
- [ ] `qs` and `fui-status` do not sustain abnormal CPU use.
- [ ] No continuing memory growth in `qs` or `fui-status`.
- [ ] Network telemetry does not spawn `ip` every second (spot-check with `ps`/`btop` if desired).
- [ ] Browser + Ardour remain practical with the shell running.

## Permanent-switch guard

- [ ] `cat ~/.local/state/fui/runtime-ok` matches `readlink -f /run/current-system`.
- [ ] `bash scripts/apply` refuses if the runtime marker is removed or belongs to another generation.
- [ ] Only after all of the above, type `APPLY` when prompted.

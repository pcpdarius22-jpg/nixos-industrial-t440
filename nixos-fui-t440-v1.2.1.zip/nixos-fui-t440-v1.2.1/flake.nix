{
  description = "Personal FUI shell v1.2.1 for a ThinkPad T440 — NixOS 26.05 + Niri + Quickshell";

  inputs.nixpkgs.url = "github:NixOS/nixpkgs/70cc4559b10a6062b05ff1af17e0add065ccaed9";

  outputs = { self, nixpkgs }:
    let
      system = "x86_64-linux";
      pkgs = import nixpkgs {
        inherit system;
        config.allowUnfree = true;
      };
    in {
      nixosConfigurations.thinkpad = nixpkgs.lib.nixosSystem {
        inherit system;
        modules = [
          (if builtins.pathExists ./host-base/configuration.nix
           then ./host-base/configuration.nix
           else ./host-base-placeholder.nix)
          ./modules/fui.nix
        ];
      };

      # Parse the exact shipped compositor/terminal configs with the exact
      # pinned binaries *before* a test generation is allowed to activate.
      # This catches Niri KDL/Foot INI API drift in the Nix build sandbox.
      checks.${system}.core-configs = pkgs.runCommand "fui-core-configs-valid" {
        nativeBuildInputs = [ pkgs.niri pkgs.foot ];
      } ''
        export HOME="$TMPDIR/home"
        export XDG_RUNTIME_DIR="$TMPDIR/runtime"
        mkdir -p "$HOME" "$XDG_RUNTIME_DIR"
        chmod 700 "$XDG_RUNTIME_DIR"

        NIRI_CONFIG=${./niri/config.kdl} niri validate
        foot -C -c ${./config/foot.ini}
        touch "$out"
      '';
    };
}

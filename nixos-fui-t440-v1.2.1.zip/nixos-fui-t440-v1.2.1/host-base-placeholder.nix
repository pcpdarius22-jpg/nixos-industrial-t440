{ ... }:
throw ''
  FUI host-base is intentionally not bundled.

  Run: bash install.sh

  The installer copies your real /etc/nixos into host-base before evaluating
  the full NixOS configuration, so this package never guesses your boot,
  hardware, user, power, networking, or audio setup.
''

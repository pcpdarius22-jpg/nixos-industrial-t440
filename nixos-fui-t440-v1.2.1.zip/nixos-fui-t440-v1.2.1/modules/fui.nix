{ config, lib, pkgs, ... }:

let
  runtimeDir = ../scripts/runtime;

  mkApp = { name, script, runtimeInputs ? [ ] }:
    pkgs.writeShellApplication {
      inherit name runtimeInputs;
      # Several launchers intentionally pass single-quoted programs to an
      # inner bash/sh process. SC2016 would incorrectly ask the outer shell to
      # expand those variables; keep every other ShellCheck diagnostic active.
      excludeShellChecks = [ "SC2016" ];
      text = builtins.readFile (runtimeDir + "/${script}");
    };

  fuiStatus = pkgs.writeShellApplication {
    name = "fui-status";
    runtimeInputs = [ pkgs.python3 pkgs.niri pkgs.iproute2 pkgs.playerctl pkgs.pciutils ];
    text = ''
      exec python3 ${../scripts/fui-status.py}
    '';
  };

  fuiPreflight = mkApp {
    name = "fui-preflight";
    script = "fui-preflight.sh";
    runtimeInputs = [
      pkgs.niri pkgs.foot pkgs.quickshell pkgs.fuzzel pkgs.xwayland-satellite
      pkgs.fontconfig pkgs.gnugrep pkgs.coreutils pkgs.findutils pkgs.networkmanager
      pkgs.wireplumber pkgs.brightnessctl pkgs.playerctl pkgs.ardour
    ];
  };
  fuiRuntimeCheck = mkApp {
    name = "fui-runtime-check";
    script = "fui-runtime-check.sh";
    runtimeInputs = [ pkgs.niri pkgs.python3 pkgs.fontconfig pkgs.coreutils pkgs.gnugrep pkgs.networkmanager pkgs.wireplumber pkgs.foot ];
  };
  fuiBootstrap = mkApp {
    name = "fui-bootstrap";
    script = "fui-bootstrap.sh";
    runtimeInputs = [
      pkgs.niri pkgs.foot pkgs.quickshell pkgs.systemd pkgs.procps pkgs.coreutils pkgs.bash
      fuiRuntimeCheck fuiShell fuiNotify fuiPolkit fuiIdle fuiHomeLayout
    ];
  };
  fuiSession = mkApp {
    name = "fui-session";
    script = "fui-session.sh";
    runtimeInputs = [ pkgs.niri pkgs.foot pkgs.systemd pkgs.procps pkgs.gnugrep pkgs.bash pkgs.dbus fuiPreflight ];
  };
  fuiShell = mkApp {
    name = "fui-shell";
    script = "fui-shell.sh";
    runtimeInputs = [ pkgs.quickshell pkgs.procps ];
  };
  fuiShellctl = mkApp {
    name = "fui-shellctl";
    script = "fui-shellctl.sh";
    runtimeInputs = [ pkgs.quickshell ];
  };
  fuiNotify = mkApp {
    name = "fui-notify";
    script = "fui-notify.sh";
    runtimeInputs = [ pkgs.mako pkgs.systemd pkgs.procps ];
  };
  fuiPolkit = mkApp {
    name = "fui-polkit";
    script = "fui-polkit.sh";
    runtimeInputs = [ pkgs.polkit_gnome pkgs.procps ];
  };
  fuiIdle = mkApp {
    name = "fui-idle";
    script = "fui-idle.sh";
    runtimeInputs = [ pkgs.swayidle pkgs.niri ];
  };
  fuiLock = mkApp {
    name = "fui-lock";
    script = "fui-lock.sh";
    runtimeInputs = [ pkgs.swaylock ];
  };
  fuiHomeLayout = mkApp {
    name = "fui-home-layout";
    script = "fui-home-layout.sh";
    runtimeInputs = [ pkgs.coreutils pkgs.quickshell fuiHomeTerminal fuiNotes ];
  };
  fuiHomeInfo = mkApp {
    name = "fui-home-info";
    script = "fui-home-info.sh";
    runtimeInputs = [ pkgs.coreutils pkgs.gawk pkgs.gnused pkgs.procps ];
  };
  fuiHomeTerminal = mkApp {
    name = "fui-home-terminal";
    script = "fui-home-terminal.sh";
    runtimeInputs = [ pkgs.foot fuiHomeInfo ];
  };
  fuiTerminal = mkApp {
    name = "fui-terminal";
    script = "fui-terminal.sh";
    runtimeInputs = [ pkgs.foot ];
  };
  fuiNotes = mkApp {
    name = "fui-notes";
    script = "fui-notes.sh";
    runtimeInputs = [ pkgs.foot pkgs.neovim pkgs.coreutils ];
  };
  fuiFiles = mkApp {
    name = "fui-files";
    script = "fui-files.sh";
    runtimeInputs = [ pkgs.foot pkgs.yazi ];
  };
  fuiBrowser = mkApp {
    name = "fui-browser";
    script = "fui-browser.sh";
    runtimeInputs = [ pkgs.qutebrowser pkgs.firefox ];
  };
  fuiMusic = mkApp {
    name = "fui-music";
    script = "fui-music.sh";
    # Ardour is a guaranteed dependency. REAPER is an optional preference when
    # the pinned nixpkgs revision exposes it and unfree packages are allowed.
    runtimeInputs = [ pkgs.ardour ] ++ lib.optionals (pkgs ? reaper) [ pkgs.reaper ];
  };
  fuiReader = mkApp {
    name = "fui-reader";
    script = "fui-reader.sh";
    runtimeInputs = lib.optionals (pkgs ? foliate) [ pkgs.foliate ] ++ [ pkgs.zathura ];
  };
  fuiFallbackLauncher = mkApp {
    name = "fui-fallback-launcher";
    script = "fui-fallback-launcher.sh";
    runtimeInputs = [ pkgs.fuzzel ];
  };
  fuiFindFiles = mkApp {
    name = "fui-find-files";
    script = "fui-find-files.sh";
    runtimeInputs = [ pkgs.fd pkgs.fzf pkgs.foot pkgs.neovim ];
  };
  fuiGrepFiles = mkApp {
    name = "fui-grep-files";
    script = "fui-grep-files.sh";
    runtimeInputs = [ pkgs.ripgrep pkgs.fzf pkgs.foot pkgs.neovim ];
  };
  fuiRecentFiles = mkApp {
    name = "fui-recent-files";
    script = "fui-recent-files.sh";
    runtimeInputs = [ pkgs.findutils pkgs.coreutils pkgs.fzf pkgs.foot pkgs.neovim ];
  };
  fuiNetwork = mkApp {
    name = "fui-network";
    script = "fui-network.sh";
    runtimeInputs = [ pkgs.foot pkgs.networkmanager pkgs.iproute2 pkgs.coreutils ];
  };
  fuiSettings = mkApp {
    name = "fui-settings";
    script = "fui-settings.sh";
    runtimeInputs = [
      pkgs.fuzzel
      pkgs.pavucontrol
      pkgs.networkmanagerapplet
      pkgs.blueman
      pkgs.btop
      pkgs.foot
      pkgs.brightnessctl
      fuiShellctl
    ];
  };
  fuiPowerMenu = mkApp {
    name = "fui-power-menu";
    script = "fui-power-menu.sh";
    runtimeInputs = [ pkgs.fuzzel pkgs.systemd fuiLock ];
  };

  wrappers = [
    fuiStatus fuiPreflight fuiRuntimeCheck fuiBootstrap fuiSession fuiShell fuiShellctl fuiNotify fuiPolkit fuiIdle fuiLock
    fuiHomeLayout fuiHomeInfo fuiHomeTerminal fuiTerminal fuiNotes fuiFiles fuiBrowser
    fuiMusic fuiReader fuiFallbackLauncher fuiFindFiles fuiGrepFiles fuiRecentFiles fuiNetwork fuiSettings
    fuiPowerMenu
  ];

  coreApps = with pkgs; [
    quickshell
    foot
    ardour
    fontconfig
    adwaita-icon-theme
    fuzzel
    xwayland-satellite
    mako
    swaylock
    swayidle
    wl-clipboard
    grim
    slurp
    brightnessctl
    playerctl
    jq
    iproute2
    networkmanagerapplet
    blueman
    pavucontrol
    qpwgraph
    wireplumber
    qutebrowser
    firefox
    yazi
    neovim
    zathura
    mpv
    imv
    git
    gh
    fastfetch
    btop
    ripgrep
    fd
    fzf
    curl
    wget
    zip
    unzip
    python3
    polkit_gnome
  ];

  optionalApps =
    lib.optionals (pkgs ? foliate) [ pkgs.foliate ]
    ++ lib.optionals (pkgs ? reaper) [ pkgs.reaper ];
in
{
  # This module deliberately overlays the machine's existing /etc/nixos.
  # Hardware, boot, user, networking, power management and audio remain owned
  # by host-base/configuration.nix.
  programs.niri = {
    enable = true;
    useNautilus = false;
  };

  # A host that already enables Sway otherwise conflicts with Niri's portal
  # selection. This affects only this test generation; the saved host config is
  # untouched and rebooting after `nixos-rebuild test` returns to the default.
  programs.sway.enable = lib.mkForce false;
  xdg.portal.wlr.enable = lib.mkForce false;

  security.polkit.enable = true;
  # swaylock authenticates through a named PAM service; do not rely on Sway's
  # NixOS module because this overlay explicitly disables Sway.
  security.pam.services.swaylock = { };

  nixpkgs.config.allowUnfree = lib.mkForce true;

  # Fonts are part of the NixOS generation, never downloaded into ~/.local.
  # The shell uses the real Fontconfig family name "JetBrains Mono". Noto is
  # installed as deterministic language/symbol/emoji fallback.
  fonts.packages = [
    pkgs.jetbrains-mono
    pkgs.noto-fonts
    pkgs.noto-fonts-color-emoji
  ];
  fonts.fontconfig = {
    defaultFonts = {
      monospace = [ "JetBrains Mono" "Noto Sans Mono" ];
      sansSerif = [ "Noto Sans" ];
      serif = [ "Noto Serif" ];
      emoji = [ "Noto Color Emoji" ];
    };
    antialias = true;
    hinting = {
      enable = true;
      style = "slight";
    };
  };

  # Keep toolkit defaults deterministic without forcing an exotic theme engine.
  # Adwaita is shipped as a real package and is a safe fallback for apps that
  # are not custom-themed by the FUI itself.
  environment.sessionVariables = {
    GTK_THEME = "Adwaita:dark";
    XCURSOR_THEME = "Adwaita";
    XCURSOR_SIZE = "20";
  };

  # brightnessctl ships udev permissions used by the ThinkPad brightness keys.
  services.udev.packages = [ pkgs.brightnessctl ];

  environment.systemPackages = coreApps ++ optionalApps ++ wrappers;

  environment.etc = {
    "xdg/quickshell/fui".source = ../quickshell/fui;
    "fui-shell/niri/config.kdl".source = ../niri/config.kdl;
    "fui-shell/foot.ini".source = ../config/foot.ini;
    "fui-shell/fuzzel.ini".source = ../config/fuzzel.ini;
    "fui-shell/mako.conf".source = ../config/mako.conf;
    "fui-shell/swaylock.conf".source = ../config/swaylock.conf;
    "fui-shell/qutebrowser.py".source = ../config/qutebrowser.py;
    "fui-shell/nvim.lua".source = ../config/nvim.lua;
  };
}

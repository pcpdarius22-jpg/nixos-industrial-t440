#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ "${EUID}" -eq 0 ]; then
  echo "Run this installer as your normal user, not as root." >&2
  exit 2
fi
if [ ! -r /etc/nixos/configuration.nix ]; then
  echo "FUI: /etc/nixos/configuration.nix was not found; refusing to guess your host configuration." >&2
  exit 2
fi

export NIX_CONFIG="${NIX_CONFIG:-}
experimental-features = nix-command flakes"

echo "==> FUI / SAFE TEST INSTALL"
echo "    project: $ROOT"
echo "    mode: nixos-rebuild test (NOT permanent)"
echo

sudo -v
stamp="$(date +%Y%m%d-%H%M%S)"
state_root="${XDG_STATE_HOME:-$HOME/.local/state}/fui"
backup_root="$state_root/backups"
mkdir -p "$backup_root"
chmod 700 "$state_root" "$backup_root" 2>/dev/null || true

# Keep backups OUTSIDE the flake source. A path: flake snapshots its source
# tree, so storing old /etc/nixos copies below $ROOT would needlessly copy them
# into the Nix store on every evaluation/build.
if [ -d "$ROOT/backups" ]; then
  mv "$ROOT/backups" "$backup_root/legacy-project-backups-$stamp"
fi
if [ -d "$ROOT/host-base" ] && [ -e "$ROOT/host-base/configuration.nix" ]; then
  # A previous install already captured a host base. Preserve it outside the
  # path-flake source before replacing it with the machine's current config.
  mv "$ROOT/host-base" "$backup_root/host-base-$stamp"
else
  # The distributed source contains only host-base/.keep. The clear-error stub
  # lives at project root so Git can ignore the real host configuration later.
  rm -rf "$ROOT/host-base"
fi

tmp="$(mktemp -d "$ROOT/.host-base.XXXXXX")"
cleanup() { rm -rf "$tmp"; }
trap cleanup EXIT
# Preserve symlinks rather than blindly dereferencing every link below
# /etc/nixos (a stray `result` symlink can otherwise copy a whole Nix closure).
sudo cp -a /etc/nixos/. "$tmp/"
sudo chown -R "$(id -u):$(id -g)" "$tmp"
# Build products and VCS metadata are never configuration inputs for this
# overlay and only bloat path-flake snapshots.
rm -rf "$tmp/.git" "$tmp/result"
# Materialize symlinked *files* (common when /etc/nixos points pieces at a
# dotfiles repo) without recursively following arbitrary symlinked directories.
# Relative imports then remain usable inside the self-contained host-base when
# those linked files live under /etc/nixos. Directory links are left untouched
# and the pure Nix evaluation below will fail safely if they are not usable.
while IFS= read -r -d '' link; do
  target="$(readlink -f "$link" 2>/dev/null || true)"
  if [ -n "$target" ] && [ -f "$target" ]; then
    cp --dereference --preserve=mode,timestamps -- "$target" "$link.materialized"
    rm -f -- "$link"
    mv -- "$link.materialized" "$link"
  fi
done < <(find "$tmp" -type l -print0)
mv "$tmp" "$ROOT/host-base"
trap - EXIT

echo "==> Copied your current /etc/nixos as the host base."

echo "==> Locking the exact flake inputs..."
nix flake lock "path:$ROOT"

echo "==> Running local regression checks..."
bash "$ROOT/scripts/check"

echo "==> Validating Niri + Foot with the exact pinned binaries BEFORE activation..."
nix build --no-link "path:$ROOT#checks.x86_64-linux.core-configs"
echo "    pinned core config validation: OK"

echo "==> Evaluating the complete NixOS configuration before activation..."
nix eval --raw "path:$ROOT#nixosConfigurations.thinkpad.config.system.build.toplevel.drvPath" >/dev/null
echo "    evaluation: OK"

echo "==> Building and activating a NON-PERSISTENT test generation..."
rm -f "$state_root/runtime-ok"
sudo env NIX_CONFIG="experimental-features = nix-command flakes" nixos-rebuild test --flake "path:$ROOT#thinkpad"

echo "==> Validating the exact installed Niri and Foot configs..."
NIRI_CONFIG=/etc/fui-shell/niri/config.kdl niri validate
foot -C -c /etc/fui-shell/foot.ini

echo "==> Running installed dependency/font/hardware preflight..."
fui-preflight

echo
echo "TEST GENERATION IS ACTIVE. It is not the boot default."
echo "From a spare TTY, start it with:  fui-session"
echo "Exit Niri with:                   Super+Shift+E"
echo "Fallback launcher:                Super+Alt+D"
echo "If the graphical test is bad:     reboot (returns to your previous boot default)"
echo
echo "Do NOT run scripts/apply until the hardware checklist passes."

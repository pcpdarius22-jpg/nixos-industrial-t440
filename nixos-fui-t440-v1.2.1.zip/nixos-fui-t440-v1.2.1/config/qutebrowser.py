# Intentionally small: only stable visual settings. Keep site compatibility first.
config.load_autoconfig()
c.colors.webpage.preferred_color_scheme = "dark"
c.colors.webpage.darkmode.enabled = True
c.tabs.position = "top"
c.tabs.show = "multiple"
c.statusbar.show = "in-mode"
c.scrolling.smooth = False
c.content.autoplay = False

vim.opt.number = false
vim.opt.relativenumber = false
vim.opt.wrap = true
vim.opt.linebreak = true
vim.opt.signcolumn = "no"
vim.opt.laststatus = 0
vim.opt.showmode = true
vim.opt.ruler = false
vim.opt.showcmd = false
vim.opt.cmdheight = 1
vim.opt.termguicolors = true
vim.opt.cursorline = false
vim.opt.fillchars = { eob = " " }
vim.cmd("syntax enable")
vim.api.nvim_set_hl(0, "Normal", { fg = "#9ca7ac", bg = "#05090b" })
vim.api.nvim_set_hl(0, "NormalNC", { fg = "#7c888d", bg = "#05090b" })
vim.api.nvim_set_hl(0, "EndOfBuffer", { fg = "#05090b", bg = "#05090b" })
vim.api.nvim_set_hl(0, "Title", { fg = "#c98d42", bg = "#05090b" })
vim.api.nvim_set_hl(0, "markdownH1", { fg = "#c8cdd0", bold = true })
vim.api.nvim_set_hl(0, "NonText", { fg = "#26343a", bg = "#05090b" })

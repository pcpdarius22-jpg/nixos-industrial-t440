#!/usr/bin/env python3
"""One low-overhead status stream for the FUI shell.

Prints one JSON object per second. It is deliberately tolerant: missing sensors,
battery, playerctl, or Niri IPC become empty values instead of killing the shell.
Slow-changing local-IP discovery is cached instead of spawning ip every tick.
"""
from __future__ import annotations

import json
import os
import pathlib
import shutil
import subprocess
import threading
import time
from typing import Any

STATE: dict[str, Any] = {
    "workspace": "MAIN",
    "workspaces": ["MAIN", "DEV", "MEDIA", "READ", "MISC"],
}
LOCK = threading.Lock()


def read_text(path: str, default: str = "") -> str:
    try:
        return pathlib.Path(path).read_text(errors="replace").strip()
    except OSError:
        return default


def cpu_snapshot() -> tuple[int, int]:
    try:
        fields = pathlib.Path("/proc/stat").read_text().splitlines()[0].split()[1:]
        nums = [int(x) for x in fields]
        idle = nums[3] + (nums[4] if len(nums) > 4 else 0)
        total = sum(nums)
        return idle, total
    except Exception:
        return 0, 0


def mem_info() -> tuple[int, int, int, int]:
    vals: dict[str, int] = {}
    try:
        for line in pathlib.Path("/proc/meminfo").read_text().splitlines():
            k, v = line.split(":", 1)
            vals[k] = int(v.strip().split()[0]) * 1024
    except Exception:
        return 0, 0, 0, 0
    total = vals.get("MemTotal", 0)
    avail = vals.get("MemAvailable", vals.get("MemFree", 0))
    swap_total = vals.get("SwapTotal", 0)
    swap_free = vals.get("SwapFree", 0)
    return max(0, total - avail), total, max(0, swap_total - swap_free), swap_total


def human_bytes(n: float) -> str:
    for unit in ("B", "K", "M", "G", "T"):
        if abs(n) < 1024.0 or unit == "T":
            if unit in ("B", "K"):
                return f"{n:.0f}{unit}"
            return f"{n:.1f}{unit}"
        n /= 1024.0
    return "0B"


def disk_info() -> tuple[int, int]:
    try:
        d = shutil.disk_usage("/")
        return d.used, d.total
    except OSError:
        return 0, 0


def battery() -> tuple[int | None, str]:
    """Return aggregate percentage/status across all installed batteries.

    ThinkPad T440 machines can expose both an internal and removable battery.
    BAT0 alone is therefore not enough.  We only sum values when every battery
    exposes the *same* kernel power_supply measurement family (energy_* or
    charge_*); those families have different units and must never be mixed.
    If the batteries do not share one family, fall back to dimensionless per-
    battery percentages instead of inventing a physically invalid total.
    """
    roots = sorted(pathlib.Path("/sys/class/power_supply").glob("BAT*"))
    if not roots:
        return None, "AC"

    statuses: list[str] = []
    capacities: list[int] = []
    ratios: list[float] = []
    family_values: dict[str, list[tuple[float, float]]] = {
        "energy": [],
        "charge": [],
    }

    for root in roots:
        status = read_text(str(root / "status"), "Unknown")
        statuses.append(status)

        cap_text = read_text(str(root / "capacity"))
        try:
            capacities.append(max(0, min(100, int(cap_text))))
        except ValueError:
            pass

        # Record each family independently.  Do not add energy (typically µWh)
        # to charge (typically µAh): the numerical units are not comparable.
        best_ratio: float | None = None
        for prefix in ("energy", "charge"):
            now_text = read_text(str(root / f"{prefix}_now"))
            full_text = read_text(str(root / f"{prefix}_full"))
            if not now_text or not full_text:
                continue
            try:
                now_v, full_v = float(now_text), float(full_text)
            except ValueError:
                continue
            if full_v <= 0:
                continue
            family_values[prefix].append((now_v, full_v))
            if best_ratio is None:
                best_ratio = max(0.0, min(1.0, now_v / full_v))

        if best_ratio is not None:
            ratios.append(best_ratio)

    # Prefer a capacity-weighted aggregate only when one measurement family is
    # available for *all* batteries.  Otherwise use the average of kernel
    # capacity percentages (or same-battery ratios) without mixing units.
    cap: int | None = None
    for prefix in ("energy", "charge"):
        values = family_values[prefix]
        if len(values) == len(roots):
            total_now = sum(v[0] for v in values)
            total_full = sum(v[1] for v in values)
            if total_full > 0:
                cap = round(max(0.0, min(1.0, total_now / total_full)) * 100)
                break

    if cap is None and len(capacities) == len(roots):
        cap = round(sum(capacities) / len(capacities))
    elif cap is None and ratios:
        cap = round(sum(ratios) / len(ratios) * 100)
    elif cap is None and capacities:
        cap = round(sum(capacities) / len(capacities))

    lower = [s.lower() for s in statuses]
    if any(s == "charging" for s in lower):
        combined = "Charging"
    elif any(s == "discharging" for s in lower):
        combined = "Discharging"
    elif lower and all(s == "full" for s in lower):
        combined = "Full"
    elif any(s == "not charging" for s in lower):
        combined = "Not charging"
    else:
        combined = next((s for s in statuses if s and s != "Unknown"), "Unknown")
    return cap, combined


def temperature() -> float | None:
    candidates: list[float] = []
    for path in pathlib.Path("/sys/class/thermal").glob("thermal_zone*/temp"):
        try:
            val = float(path.read_text().strip())
            if val > 1000:
                val /= 1000.0
            if 5 <= val <= 120:
                candidates.append(val)
        except Exception:
            pass
    return max(candidates) if candidates else None


def default_iface() -> str:
    """Return the kernel's current IPv4 default-route interface without spawning."""
    try:
        for line in pathlib.Path("/proc/net/route").read_text().splitlines()[1:]:
            fields = line.split()
            if len(fields) < 4 or fields[1] != "00000000":
                continue
            # RTF_UP (0x1) and RTF_GATEWAY (0x2) identify a usable default route.
            flags = int(fields[3], 16)
            if flags & 0x1:
                return fields[0]
    except Exception:
        pass
    return ""


def net_snapshot() -> tuple[str, int, int]:
    """Read counters for the active/default interface, falling back safely."""
    preferred = default_iface()
    entries: dict[str, tuple[int, int]] = {}
    try:
        lines = pathlib.Path("/proc/net/dev").read_text().splitlines()[2:]
        for line in lines:
            iface, stats = line.split(":", 1)
            iface = iface.strip()
            if iface == "lo":
                continue
            parts = stats.split()
            entries[iface] = (int(parts[0]), int(parts[8]))
    except Exception:
        return "", 0, 0

    if preferred in entries:
        rx, tx = entries[preferred]
        return preferred, rx, tx

    # Prefer a link that is currently up; cumulative byte counts from an old,
    # disconnected interface must not steal the status panel.
    for iface, (rx, tx) in entries.items():
        if read_text(f"/sys/class/net/{iface}/operstate") == "up":
            return iface, rx, tx

    if entries:
        iface, (rx, tx) = max(entries.items(), key=lambda item: item[1][0] + item[1][1])
        return iface, rx, tx
    return "", 0, 0


def local_ip(iface: str) -> str:
    if not iface:
        return "offline"
    try:
        out = subprocess.check_output(
            ["ip", "-4", "-o", "addr", "show", "dev", iface],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=0.4,
        )
        for token in out.split():
            if "/" in token and token[0].isdigit():
                return token.split("/", 1)[0]
    except Exception:
        pass
    return "offline"


def machine_info() -> dict[str, str]:
    """Collect slow-changing hardware labels once at status-process startup."""
    model = read_text("/sys/class/dmi/id/product_name", "ThinkPad")
    cpu = "CPU"
    try:
        for line in pathlib.Path("/proc/cpuinfo").read_text(errors="replace").splitlines():
            if line.lower().startswith("model name"):
                cpu = line.split(":", 1)[1].strip()
                cpu = cpu.replace("Intel(R) Core(TM)", "Intel").replace(" CPU", "")
                break
    except Exception:
        pass

    gpu = "Graphics"
    network = "Network adapter"
    if shutil.which("lspci"):
        try:
            pci = subprocess.check_output(
                ["lspci"], text=True, stderr=subprocess.DEVNULL, timeout=1.0
            ).splitlines()
            gpu_line = next(
                (line for line in pci if "VGA compatible controller:" in line or "3D controller:" in line),
                "",
            )
            net_line = next((line for line in pci if "Network controller:" in line), "")
            if not net_line:
                net_line = next((line for line in pci if "Ethernet controller:" in line), "")

            def pci_label(line: str, fallback: str) -> str:
                if not line or ": " not in line:
                    return fallback
                label = line.split(": ", 1)[1]
                return label.rsplit(" (rev ", 1)[0]

            gpu = pci_label(gpu_line, gpu)
            network = pci_label(net_line, network)
        except Exception:
            pass

    disk = "System disk"
    for block in sorted(pathlib.Path("/sys/class/block").glob("*")):
        name = block.name
        if name.startswith(("loop", "zram", "ram", "dm-")) or (block / "partition").exists():
            continue
        model_text = read_text(str(block / "device/model")) or read_text(str(block / "device/name"))
        sectors = read_text(str(block / "size"), "0")
        try:
            size_text = human_bytes(int(sectors) * 512)
        except ValueError:
            size_text = ""
        disk = " ".join(part for part in (model_text.strip(), size_text) if part) or name
        break

    kernel = os.uname().release
    return {
        "model": model,
        "cpu_model": cpu,
        "gpu_model": gpu,
        "net_model": network,
        "disk_model": disk,
        "kernel": kernel,
    }


def player_info() -> dict[str, Any]:
    empty = {"playing": False, "title": "NO ACTIVE SIGNAL", "artist": "", "position": "", "length": "", "progress": 0.0}
    if not shutil.which("playerctl"):
        return empty
    try:
        status = subprocess.check_output(
            ["playerctl", "status"],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=0.4,
        ).strip()
        # Unit Separator is extremely unlikely to occur in normal metadata and
        # avoids ambiguous parsing without relying on a shell.
        fmt = "{{title}}\x1f{{artist}}\x1f{{position}}\x1f{{mpris:length}}"
        out = subprocess.check_output(
            ["playerctl", "metadata", "--format", fmt],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=0.5,
        ).strip()
        parts = out.split("\x1f")
        if len(parts) < 4:
            return empty
        title, artist, pos, length = parts[:4]

        def clock_us(raw: str) -> str:
            try:
                us = int(float(raw))
                sec = max(0, us // 1_000_000)
                return f"{sec//60}:{sec%60:02d}"
            except Exception:
                return ""

        # Playerctl template variable `position` and MPRIS `mpris:length` are
        # both microseconds. Convert both through the same path.
        try:
            pos_us = max(0.0, float(pos))
            len_us = max(0.0, float(length))
            progress = 0.0 if len_us <= 0 else min(1.0, pos_us / len_us)
        except Exception:
            progress = 0.0

        return {
            "playing": status.lower() == "playing",
            "title": title or "UNTITLED",
            "artist": artist,
            "position": clock_us(pos),
            "length": clock_us(length),
            "progress": round(progress, 4),
        }
    except Exception:
        return empty


def update_workspaces_initial() -> None:
    try:
        out = subprocess.check_output(["niri", "msg", "--json", "workspaces"], text=True, timeout=1.0)
        items = json.loads(out)
        names = [x.get("name") for x in items if x.get("name")]
        focused = next((x.get("name") for x in items if x.get("is_focused") and x.get("name")), None)
        with LOCK:
            if names:
                STATE["workspaces"] = names
            if focused:
                STATE["workspace"] = focused
    except Exception:
        pass


def niri_events() -> None:
    update_workspaces_initial()
    while True:
        try:
            proc = subprocess.Popen(
                ["niri", "msg", "--json", "event-stream"],
                stdout=subprocess.PIPE,
                stderr=subprocess.DEVNULL,
                text=True,
                bufsize=1,
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                try:
                    event = json.loads(line)
                except json.JSONDecodeError:
                    continue
                changed = event.get("WorkspacesChanged")
                if isinstance(changed, dict):
                    items = changed.get("workspaces", [])
                    names = [x.get("name") for x in items if x.get("name")]
                    focused = next((x.get("name") for x in items if x.get("is_focused") and x.get("name")), None)
                    with LOCK:
                        if names:
                            STATE["workspaces"] = names
                        if focused:
                            STATE["workspace"] = focused
                activated = event.get("WorkspaceActivated")
                if isinstance(activated, dict) and activated.get("focused", True):
                    # Some niri versions provide id only. Refresh once to map it safely.
                    update_workspaces_initial()
            proc.wait(timeout=1)
        except Exception:
            time.sleep(1.0)


def main() -> None:
    threading.Thread(target=niri_events, daemon=True).start()
    machine = machine_info()
    idle0, total0 = cpu_snapshot()
    iface0, rx0, tx0 = net_snapshot()
    last_t = time.monotonic()
    player = player_info()
    next_player = time.monotonic() + 2.0
    cached_ip = local_ip(iface0)
    next_ip = time.monotonic() + 10.0

    while True:
        start = time.monotonic()
        idle1, total1 = cpu_snapshot()
        dtot = total1 - total0
        didle = idle1 - idle0
        cpu = 0.0 if dtot <= 0 else 100.0 * (1.0 - didle / dtot)
        idle0, total0 = idle1, total1

        mem_used, mem_total, swap_used, swap_total = mem_info()
        disk_used, disk_total = disk_info()
        cap, batt_status = battery()
        temp = temperature()

        iface, rx, tx = net_snapshot()
        now = time.monotonic()
        elapsed = max(0.2, now - last_t)
        iface_changed = iface != iface0
        if iface_changed:
            rx_rate = tx_rate = 0.0
        else:
            rx_rate = max(0, rx - rx0) / elapsed
            tx_rate = max(0, tx - tx0) / elapsed
        iface0, rx0, tx0, last_t = iface, rx, tx, now

        if now >= next_player:
            player = player_info()
            next_player = now + 2.0

        # Address assignment changes far less often than byte counters. Avoid a
        # fresh `ip` subprocess every second; refresh immediately on interface
        # changes and otherwise at a ten-second cadence.
        if iface_changed or now >= next_ip:
            cached_ip = local_ip(iface)
            next_ip = now + 10.0

        with LOCK:
            ws = STATE.get("workspace", "MAIN")
            names = list(STATE.get("workspaces", []))

        payload: dict[str, Any] = {
            **machine,
            "cpu": round(cpu, 1),
            "mem_used": human_bytes(mem_used),
            "mem_total": human_bytes(mem_total),
            "mem_pct": round((mem_used / mem_total * 100.0) if mem_total else 0, 1),
            "swap_used": human_bytes(swap_used),
            "swap_total": human_bytes(swap_total),
            "swap_pct": round((swap_used / swap_total * 100.0) if swap_total else 0, 1),
            "disk_used": human_bytes(disk_used),
            "disk_total": human_bytes(disk_total),
            "disk_pct": round((disk_used / disk_total * 100.0) if disk_total else 0, 1),
            "temp": None if temp is None else round(temp, 1),
            "battery": cap,
            "battery_status": batt_status,
            "iface": iface or "offline",
            "ip": cached_ip,
            "rx": human_bytes(rx_rate) + "/s",
            "tx": human_bytes(tx_rate) + "/s",
            "workspace": ws,
            "workspaces": names,
            "player": player,
            "time": time.strftime("%H:%M"),
            "seconds": time.strftime("%S"),
            "date": time.strftime("%A %d %B %Y").upper(),
        }
        try:
            print(json.dumps(payload, separators=(",", ":")), flush=True)
        except BrokenPipeError:
            return
        spent = time.monotonic() - start
        time.sleep(max(0.05, 1.0 - spent))


if __name__ == "__main__":
    main()

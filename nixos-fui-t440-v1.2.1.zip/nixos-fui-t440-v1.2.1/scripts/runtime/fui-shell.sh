set -euo pipefail
# Keep one named shell instance. This is also the recovery entry point bound to
# Super+Shift+D if the shell UI itself has to be restarted.
pkill -f '[q]s -c fui' 2>/dev/null || true
exec qs -c fui

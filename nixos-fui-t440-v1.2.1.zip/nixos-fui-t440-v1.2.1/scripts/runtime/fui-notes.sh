set -euo pipefail
mkdir -p "$HOME/Notes"
file="$HOME/Notes/FUI-NOTES.md"
if [ ! -e "$file" ]; then
  printf '# NOTES\n\n' > "$file"
fi
exec foot -c /etc/fui-shell/foot.ini --app-id fui-notes --title NOTES \
  nvim -u /etc/fui-shell/nvim.lua "$file"

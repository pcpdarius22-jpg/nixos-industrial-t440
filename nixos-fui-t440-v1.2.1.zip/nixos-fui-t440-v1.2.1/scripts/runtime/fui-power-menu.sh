set -euo pipefail
choice="$(printf '%s\n' 'LOCK' 'SUSPEND' 'REBOOT' 'POWER OFF' | fuzzel --dmenu --config /etc/fui-shell/fuzzel.ini --prompt='POWER > ')" || exit 0
case "$choice" in
  LOCK) exec fui-lock ;;
  SUSPEND) systemctl suspend ;;
  REBOOT|'POWER OFF')
    confirm="$(printf '%s\n' 'CANCEL' "CONFIRM $choice" | fuzzel --dmenu --config /etc/fui-shell/fuzzel.ini --prompt='CONFIRM > ')" || exit 0
    [ "$confirm" = "CONFIRM $choice" ] || exit 0
    if [ "$choice" = REBOOT ]; then systemctl reboot; else systemctl poweroff; fi
    ;;
esac

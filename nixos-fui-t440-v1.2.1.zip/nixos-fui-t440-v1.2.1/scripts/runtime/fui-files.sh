set -euo pipefail
exec foot -c /etc/fui-shell/foot.ini --app-id fui-files --title FILES yazi "${1:-$HOME}"

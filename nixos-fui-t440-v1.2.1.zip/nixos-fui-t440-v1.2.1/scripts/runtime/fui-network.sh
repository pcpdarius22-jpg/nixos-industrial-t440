set -euo pipefail
exec foot -c /etc/fui-shell/foot.ini --app-id fui-network --title NETWORK sh -c '
  clear
  printf "NETWORK / LIVE\\n\\n"
  nmcli -f DEVICE,TYPE,STATE,CONNECTION device status 2>/dev/null || true
  printf "\\nADDRESSES\\n"
  ip -brief -4 addr 2>/dev/null || true
  printf "\\nROUTES\\n"
  ip route 2>/dev/null | head -n 12 || true
  printf "\\nPress Enter to close."
  read -r _
'

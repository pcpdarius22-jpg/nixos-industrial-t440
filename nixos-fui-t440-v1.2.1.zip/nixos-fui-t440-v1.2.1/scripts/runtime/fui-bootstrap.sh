set -euo pipefail

state_dir="${XDG_STATE_HOME:-$HOME/.local/state}/fui"
log="$state_dir/runtime-check.log"
mkdir -p "$state_dir"
: > "$log"

fail_ui() {
  local message="$1"
  printf '%s\n' "$message" >> "$log"
  # Keep Niri itself alive and usable. Open a plain Foot diagnostic instead of
  # mapping a half-broken shell. Super+T and Super+Alt+D remain compositor binds.
  foot -c /etc/fui-shell/foot.ini --app-id fui-diagnostic --title 'FUI CHECK FAILED' \
    bash -lc 'printf "FUI did not start because the runtime verification failed.\n\n"; cat "$1"; printf "\nNiri is still running. Use Super+T for a terminal or Super+Shift+E to exit.\n\nPress Enter to close..."; read -r _' bash "$log" \
    >/dev/null 2>&1 &
  exit 1
}

if ! fui-runtime-check >>"$log" 2>&1; then
  fail_ui 'core runtime check failed'
fi

# Start the custom shell only after exact output/font checks pass.
fui-shell >>"$log" 2>&1 &

ready=0
for _ in $(seq 1 80); do
  if qs -c fui ipc call shell ping >/dev/null 2>&1; then
    ready=1
    break
  fi
  sleep 0.10
done
if [ "$ready" -ne 1 ]; then
  pkill -f '[q]s -c fui' 2>/dev/null || true
  fail_ui 'Quickshell started but its FUI IPC endpoint never became ready'
fi
printf '[OK]   Quickshell IPC ready\n' >> "$log"
# Tie the successful visual/runtime gate to the exact active test generation.
readlink -f /run/current-system > "$state_dir/runtime-ok"

# Only now start secondary desktop helpers. Failure of one helper must not kill
# the compositor or shell, so each is independent.
fui-notify >>"$log" 2>&1 &
fui-polkit >>"$log" 2>&1 &
fui-idle >>"$log" 2>&1 &
fui-home-layout >>"$log" 2>&1 &

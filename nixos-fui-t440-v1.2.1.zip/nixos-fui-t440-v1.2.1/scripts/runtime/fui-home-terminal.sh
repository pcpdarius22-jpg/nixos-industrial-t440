set -euo pipefail
exec foot -c /etc/fui-shell/foot.ini \
  --app-id fui-home-terminal \
  --title TERMINAL \
  fui-home-info

set -euo pipefail
exec foot -c /etc/fui-shell/foot.ini --app-id fui-terminal --title TERMINAL

set -euo pipefail
if [ "$#" -lt 1 ]; then
  echo "usage: fui-shellctl <toggleLauncher|openLauncher|openCommand|closeLauncher|toggleWallpaperMotion|toggleWallpaperInteraction|wallpaperStatus>" >&2
  exit 2
fi
exec qs -c fui ipc call shell "$1"

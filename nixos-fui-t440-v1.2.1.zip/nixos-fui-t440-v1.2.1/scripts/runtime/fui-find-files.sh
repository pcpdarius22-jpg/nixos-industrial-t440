set -euo pipefail
selection="$({ fd --type f --hidden --exclude .git . "$HOME" 2>/dev/null || true; } | fzf --height=100% --reverse --border=none --prompt='FILE > ')"
[ -n "$selection" ] || exit 0
exec foot -c /etc/fui-shell/foot.ini --app-id fui-editor --title EDITOR nvim "$selection"

set -euo pipefail

model="$(cat /sys/class/dmi/id/product_name 2>/dev/null || printf 'ThinkPad')"
cpu="$(awk -F: 'tolower($1) ~ /model name/ {gsub(/^[ \t]+/,"",$2); print $2; exit}' /proc/cpuinfo 2>/dev/null || true)"
mem="$(awk '/MemTotal/ {printf "%.0f MiB", $2/1024}' /proc/meminfo 2>/dev/null || true)"
kernel="$(uname -r)"
uptime_text="$(uptime -p 2>/dev/null | sed 's/^up //' || true)"
shell_path="${SHELL:-/bin/sh}"

printf '\033[38;2;201;141;66muser@fui\033[0m\n'
printf 'os  >  home\n\n'
printf '        /\\                 user@fui\n'
printf '    ___/  \\___             --------\n'
printf '   /  /\\  /\\  \\            OS: FUI 1.0\n'
printf '  /__/  \\/  \\__\\           Host: %s\n' "$model"
printf '  \\  \\  /\\  /  /           Kernel: %s\n' "$kernel"
printf '   \\__\\/  \\/__/            Uptime: %s\n' "${uptime_text:-unknown}"
printf '      / /\\ \\               Shell: %s\n' "${shell_path##*/}"
printf '     /_/  \\_\\              Resolution: 1600x900\n'
printf '                          WM: niri\n'
printf '                          Terminal: foot\n'
printf '                          CPU: %s\n' "${cpu:-Intel Haswell}"
printf '                          Memory: %s\n\n' "${mem:-unknown}"
printf '\033[38;2;98;145;150m■\033[0m \033[38;2;201;141;66m■\033[0m □ ■ □ ■ □\n\n'

exec "$shell_path" -i

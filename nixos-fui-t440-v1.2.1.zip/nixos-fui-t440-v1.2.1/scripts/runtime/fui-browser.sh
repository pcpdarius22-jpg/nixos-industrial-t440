set -euo pipefail
if command -v qutebrowser >/dev/null 2>&1; then
  exec qutebrowser --config-py /etc/fui-shell/qutebrowser.py
fi
exec firefox

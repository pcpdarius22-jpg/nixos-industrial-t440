set -euo pipefail
exec swayidle -w \
  timeout 900 'fui-lock' \
  timeout 960 'niri msg action power-off-monitors' \
  before-sleep 'fui-lock'

set -euo pipefail
exec swaylock -f -C /etc/fui-shell/swaylock.conf

set -euo pipefail
if [ "${1:-}" != "--inside" ]; then
  exec foot -c /etc/fui-shell/foot.ini --app-id fui-search --title 'FIND IN FILES' fui-grep-files --inside
fi
printf 'FIND IN FILES\n\nTEXT > '
IFS= read -r query
[ -n "$query" ] || exit 0
selection="$({ rg --vimgrep --hidden --glob '!.git/**' -- "$query" "$HOME" 2>/dev/null || true; } | fzf --height=100% --reverse --border=none --prompt='MATCH > ')"
[ -n "$selection" ] || exit 0
file="${selection%%:*}"
rest="${selection#*:}"
line="${rest%%:*}"
if [ ! -f "$file" ]; then
  printf '\nCould not resolve selected file. Press Enter to close.'
  IFS= read -r _
  exit 1
fi
exec nvim "+${line}" "$file"

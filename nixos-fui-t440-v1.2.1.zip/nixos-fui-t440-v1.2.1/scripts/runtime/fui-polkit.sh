set -euo pipefail
pkill -f '[p]olkit-gnome-authentication-agent-1' 2>/dev/null || true
exec polkit-gnome-authentication-agent-1

set -euo pipefail
# A previous desktop may have left Dunst running as a user service. Stop that
# process for this session so exactly one implementation owns
# org.freedesktop.Notifications. Nothing is masked or disabled permanently.
systemctl --user stop dunst.service >/dev/null 2>&1 || true
pkill -x dunst 2>/dev/null || true
pkill -x mako 2>/dev/null || true
exec mako -c /etc/fui-shell/mako.conf

set -euo pipefail
exec fuzzel --config /etc/fui-shell/fuzzel.ini

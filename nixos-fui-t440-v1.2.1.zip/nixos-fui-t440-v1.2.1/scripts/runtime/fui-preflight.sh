set -euo pipefail

# TTY-side checks that must pass before the compositor starts.  These are kept
# intentionally conservative: hard failures are things that would produce a
# broken/incorrect FUI session; hardware services that may legitimately wake
# only after login are warnings.

fail=0
warn=0
ok()   { printf '[OK]   %s\n' "$*"; }
warnf(){ printf '[WARN] %s\n' "$*" >&2; warn=$((warn + 1)); }
failf(){ printf '[FAIL] %s\n' "$*" >&2; fail=$((fail + 1)); }

printf 'FUI preflight\n=============\n'

for cmd in niri foot qs fuzzel xwayland-satellite fc-match fc-list brightnessctl playerctl ardour9; do
  if command -v "$cmd" >/dev/null 2>&1; then
    ok "$cmd"
  else
    # Ardour's executable is major-versioned in current nixpkgs. Keep a safe
    # fallback for a future package rename without weakening the dependency.
    if [ "$cmd" = ardour9 ] && command -v ardour >/dev/null 2>&1; then
      ok "ardour (fallback executable name)"
    else
      failf "required executable missing: $cmd"
    fi
  fi
done

if [ -r /etc/fui-shell/niri/config.kdl ]; then
  if NIRI_CONFIG=/etc/fui-shell/niri/config.kdl niri validate >/dev/null; then
    ok 'Niri configuration parses'
  else
    failf 'Niri configuration is invalid'
  fi
else
  failf '/etc/fui-shell/niri/config.kdl is missing'
fi

if [ -r /etc/fui-shell/foot.ini ]; then
  if foot -C -c /etc/fui-shell/foot.ini >/dev/null 2>&1; then
    ok 'Foot configuration parses'
  else
    failf 'Foot configuration is invalid'
  fi
else
  failf '/etc/fui-shell/foot.ini is missing'
fi

check_font() {
  local requested="$1" expected="$2" actual
  actual="$(fc-match -f '%{family}\n' "$requested" 2>/dev/null | head -n1 || true)"
  if printf '%s' "$actual" | grep -Fqi -- "$expected"; then
    ok "font ${expected} -> ${actual}"
  else
    failf "font ${expected} did not resolve correctly (got: ${actual:-nothing})"
  fi
}
check_font 'JetBrains Mono' 'JetBrains Mono'
check_font 'Noto Sans' 'Noto Sans'
check_font 'Noto Serif' 'Noto Serif'
check_font 'Noto Color Emoji' 'Noto Color Emoji'

# The exact visual target is 1600x900.  Verify that an internal DRM connector
# advertises the mode before entering Niri. Connector naming differs across
# kernels, so absence of a detectable eDP path is a warning, not a guess.
found_edp=0
found_mode=0
for modes in /sys/class/drm/card*-eDP-*/modes; do
  [ -r "$modes" ] || continue
  found_edp=1
  if grep -Fxq '1600x900' "$modes"; then
    found_mode=1
    ok "1600x900 advertised by ${modes%/modes}"
    break
  fi
done
if [ "$found_edp" -eq 1 ] && [ "$found_mode" -eq 0 ]; then
  failf 'internal display does not advertise 1600x900; refusing an inexact 1:1 session'
elif [ "$found_edp" -eq 0 ]; then
  warnf 'could not identify an eDP connector in sysfs; runtime output check will decide'
fi

if command -v nmcli >/dev/null 2>&1 && nmcli -t -f STATE general 2>/dev/null | grep -Eq '^(connected|connecting|disconnected|asleep)'; then
  ok 'NetworkManager is running'
else
  warnf 'NetworkManager is not reporting running yet'
fi

if command -v wpctl >/dev/null 2>&1 && wpctl status >/dev/null 2>&1; then
  ok 'PipeWire/WirePlumber responds'
else
  warnf 'PipeWire/WirePlumber is not responding on this TTY yet'
fi

if compgen -G '/sys/class/power_supply/BAT*' >/dev/null; then
  ok 'battery telemetry source present'
else
  warnf 'no BAT* power_supply found; battery widget will show AC/unknown'
fi

printf '\n'
if [ "$fail" -ne 0 ]; then
  printf 'FUI preflight failed: %d hard failure(s), %d warning(s).\n' "$fail" "$warn" >&2
  exit 1
fi
printf 'FUI preflight passed with %d warning(s).\n' "$warn"

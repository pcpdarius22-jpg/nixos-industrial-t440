set -euo pipefail
if [ -n "${WAYLAND_DISPLAY:-}" ]; then
  echo "FUI: a Wayland session is already active (${WAYLAND_DISPLAY})." >&2
  echo "Run fui-session from a real TTY, not from inside another desktop." >&2
  exit 2
fi
if [ ! -t 0 ]; then
  echo "FUI: fui-session must be launched interactively from a TTY." >&2
  exit 2
fi
cfg=/etc/fui-shell/niri/config.kdl
foot_cfg=/etc/fui-shell/foot.ini
if [ ! -r "$cfg" ] || [ ! -r "$foot_cfg" ]; then
  echo "FUI: installed configuration is missing. Run the project's test installer first." >&2
  exit 2
fi
export NIRI_CONFIG="$cfg"
# `nixos-rebuild test` can be activated from a login shell that predates this
# generation, so export the visual defaults explicitly for this test session as
# well as declaring them in NixOS.
export GTK_THEME="Adwaita:dark"
export XCURSOR_THEME="Adwaita"
export XCURSOR_SIZE="20"
# Run the complete TTY-side verifier before entering graphics. It includes the
# exact Niri/Foot parse checks, font resolution, required executables, and the
# internal-panel mode availability check.
fui-preflight
# NixOS uses systemd user-session integration for portals and graphical-session.target.
# The pinned niri 26.04 `niri-session` helper normally re-enters the user's login
# shell first; `-l` is its own sentinel meaning that step has already happened.
# Using it here therefore gets the proper systemd/portal lifecycle WITHOUT touching
# .bash_profile or repeating the login-shell recursion that broke the old prototype.
unset DISPLAY || true
cleanup_session_env() {
  systemctl --user unset-environment NIRI_CONFIG >/dev/null 2>&1 || true
}
trap cleanup_session_env EXIT
niri-session -l

set -euo pipefail
if [ "${1:-}" != "--inside" ]; then
  exec foot -c /etc/fui-shell/foot.ini --app-id fui-recent --title 'RECENT FILES' fui-recent-files --inside
fi
selection="$({
  find "$HOME" -type f -not -path '*/.git/*' -printf '%T@\t%p\n' 2>/dev/null \
    | sort -rn \
    | head -n 500 \
    | cut -f2-
} | fzf --height=100% --reverse --border=none --prompt='RECENT > ')"
[ -n "$selection" ] || exit 0
exec nvim "$selection"

set -euo pipefail

# Must run inside Niri. Validate the live output geometry rather than trusting
# the connector name or assuming that the configured mode was accepted.
json=''
for _ in $(seq 1 50); do
  if json="$(niri msg --json outputs 2>/dev/null)" && [ -n "$json" ]; then
    break
  fi
  sleep 0.10
done

if [ -z "$json" ]; then
  echo 'FUI runtime check: Niri IPC never became ready.' >&2
  exit 1
fi

printf '%s' "$json" | python3 -c '
import json, sys, math
outputs=json.load(sys.stdin)
if not isinstance(outputs, dict) or not outputs:
    raise SystemExit("FUI runtime check: no connected outputs reported")

# Prefer the internal panel. If the kernel uses a nonstandard connector name,
# use the first enabled output and still require the exact 1600x900 logical
# canvas for the reference composition.
items=list(outputs.items())
name, out = next(((n,o) for n,o in items if n.startswith("eDP-")), items[0])
logical=out.get("logical") or {}
w=int(logical.get("width", 0) or 0)
h=int(logical.get("height", 0) or 0)
scale=float(logical.get("scale", 0) or 0)
if (w,h)!=(1600,900) or not math.isclose(scale,1.0,rel_tol=0,abs_tol=0.001):
    raise SystemExit(f"FUI runtime check: {name} is {w}x{h} logical at scale {scale}; exact target is 1600x900 at 1.0")
print(f"[OK]   live output {name}: {w}x{h} logical, scale {scale:g}")
'

for family in 'JetBrains Mono' 'Noto Sans' 'Noto Serif' 'Noto Color Emoji'; do
  actual="$(fc-match -f '%{family}\n' "$family" 2>/dev/null | head -n1 || true)"
  if ! printf '%s' "$actual" | grep -Fqi -- "$family"; then
    echo "FUI runtime check: font '$family' resolved as '${actual:-nothing}'." >&2
    exit 1
  fi
done

echo '[OK]   runtime font resolution'

for asset in \
  /etc/xdg/quickshell/fui/assets/wallpaper-1600x900.png \
  /etc/xdg/quickshell/fui/assets/city-feed-reference.png; do
  [ -r "$asset" ] || { echo "FUI runtime check: missing shell asset $asset" >&2; exit 1; }
done
echo '[OK]   wallpaper/city assets readable'

for component in \
  /etc/xdg/quickshell/fui/ReactiveWallpaper.qml \
  /etc/xdg/quickshell/fui/SignalNode.qml \
  /etc/xdg/quickshell/fui/RoutePulse.qml; do
  [ -r "$component" ] || { echo "FUI runtime check: missing reactive wallpaper component $component" >&2; exit 1; }
done
echo '[OK]   reactive wallpaper components readable'

if foot -C -c /etc/fui-shell/foot.ini >/dev/null 2>&1; then
  echo '[OK]   live Foot config parse'
else
  echo 'FUI runtime check: Foot config failed to parse after activation.' >&2
  exit 1
fi

if nmcli -t -f STATE general >/dev/null 2>&1; then
  echo '[OK]   NetworkManager responds'
else
  echo '[WARN] NetworkManager is not responding; shell can still start offline.' >&2
fi
if wpctl status >/dev/null 2>&1; then
  echo '[OK]   PipeWire/WirePlumber responds'
else
  echo '[WARN] PipeWire/WirePlumber is not responding yet; audio controls may be unavailable.' >&2
fi
if compgen -G '/sys/class/power_supply/BAT*' >/dev/null; then
  echo '[OK]   battery telemetry source present'
else
  echo '[WARN] no BAT* power_supply found; battery widget will show AC/unknown.' >&2
fi

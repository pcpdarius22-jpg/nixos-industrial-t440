set -euo pipefail
for app in reaper ardour9 ardour8 ardour7 ardour; do
  if command -v "$app" >/dev/null 2>&1; then
    exec "$app"
  fi
done
echo "FUI: no music workstation executable was found." >&2
exit 1

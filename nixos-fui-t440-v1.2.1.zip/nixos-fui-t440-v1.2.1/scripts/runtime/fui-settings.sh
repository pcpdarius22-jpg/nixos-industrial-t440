set -euo pipefail
choice="$(printf '%s\n' \
  'AUDIO / ROUTING' \
  'NETWORK / CONNECTIONS' \
  'BLUETOOTH' \
  'SYSTEM MONITOR' \
  'DISPLAY / BRIGHTNESS' \
  'WALLPAPER / MOTION' \
  'WALLPAPER / INTERACTION' \
  | fuzzel --dmenu --config /etc/fui-shell/fuzzel.ini --prompt='CONTROL > ')" || exit 0
case "$choice" in
  'AUDIO / ROUTING') exec pavucontrol ;;
  'NETWORK / CONNECTIONS') exec nm-connection-editor ;;
  'BLUETOOTH') exec blueman-manager ;;
  'SYSTEM MONITOR') exec foot -c /etc/fui-shell/foot.ini --app-id fui-monitor --title SYSTEM btop ;;
  'DISPLAY / BRIGHTNESS') exec foot -c /etc/fui-shell/foot.ini --app-id fui-brightness --title DISPLAY sh -c 'brightnessctl; printf "\nUse the ThinkPad brightness keys. Press Enter to close."; read -r _' ;;
  'WALLPAPER / MOTION') fui-shellctl toggleWallpaperMotion >/dev/null ;;
  'WALLPAPER / INTERACTION') fui-shellctl toggleWallpaperInteraction >/dev/null ;;
esac

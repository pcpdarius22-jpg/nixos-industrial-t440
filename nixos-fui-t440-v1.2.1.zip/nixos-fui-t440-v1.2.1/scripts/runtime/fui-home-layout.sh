set -euo pipefail
mkdir -p "$HOME/.config/fui" "$HOME/Notes" "$HOME/Pictures/Screenshots"
if [ -e "$HOME/.config/fui/no-home-windows" ]; then
  exit 0
fi

# Wait for the *actual* Quickshell IPC service instead of guessing a startup
# delay. That guarantees the top/left/right exclusive zones are mapped before
# Niri calculates the floating-window coordinates from its working area.
ready=0
for ((i = 0; i < 80; i++)); do
  if qs -c fui ipc call shell ping >/dev/null 2>&1; then
    ready=1
    break
  fi
  sleep 0.10
done
[ "$ready" -eq 1 ] || exit 0
sleep 0.20

fui-home-terminal >/dev/null 2>&1 &
sleep 0.20
fui-notes >/dev/null 2>&1 &

set -euo pipefail
if command -v foliate >/dev/null 2>&1; then exec foliate; fi
exec zathura

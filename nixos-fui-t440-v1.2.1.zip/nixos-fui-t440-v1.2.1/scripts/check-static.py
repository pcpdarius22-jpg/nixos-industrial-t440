#!/usr/bin/env python3
"""Dependency-free static regression checks for the FUI package."""
from __future__ import annotations

import ast
import configparser
import re
import struct
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []


def check(condition: bool, message: str) -> None:
    if not condition:
        ERRORS.append(message)


def png_size(path: Path) -> tuple[int, int]:
    with path.open("rb") as f:
        header = f.read(24)
    if len(header) < 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError("not a PNG with an IHDR header")
    return struct.unpack(">II", header[16:24])


def strip_qml(text: str) -> str:
    # Remove string literals before // comments. FUI labels intentionally contain
    # strings such as "CORE // HOME"; stripping comments first would truncate
    # those lines and make the lexical-balance test report false positives.
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r'"(?:\\.|[^"\\])*"', '""', text)
    text = re.sub(r"'(?:\\.|[^'\\])*'", "''", text)
    text = re.sub(r"//.*", "", text)
    return text


# Required project files.
required = [
    "flake.nix",
    "host-base-placeholder.nix",
    "modules/fui.nix",
    "niri/config.kdl",
    "config/foot.ini",
    "quickshell/fui/shell.qml",
    "quickshell/fui/DesktopSurface.qml",
    "quickshell/fui/ReactiveWallpaper.qml",
    "quickshell/fui/SignalNode.qml",
    "quickshell/fui/RoutePulse.qml",
    "quickshell/fui/TopMetric.qml",
    "quickshell/fui/TechGlyph.qml",
    "quickshell/fui/DeviceLine.qml",
    "quickshell/fui/assets/wallpaper-1600x900.png",
    "quickshell/fui/assets/city-feed-reference.png",
    "docs/reference-1600x900.png",
    "install.sh",
    "scripts/check",
    "scripts/test",
    "scripts/apply",
    "scripts/doctor",
    "scripts/verify-manifest",
    "scripts/runtime/fui-home-info.sh",
    "scripts/runtime/fui-shell.sh",
    "scripts/runtime/fui-preflight.sh",
    "scripts/runtime/fui-runtime-check.sh",
    "scripts/runtime/fui-bootstrap.sh",
]
for rel in required:
    check((ROOT / rel).exists(), f"missing required file: {rel}")

# Python syntax. Only validate project-owned Python: after install, host-base/
# is the user's existing NixOS tree and must never be linted as if it belonged
# to this package.
python_paths = [ROOT / "scripts/fui-status.py", ROOT / "scripts/check-static.py", ROOT / "config/qutebrowser.py"]
for path in python_paths:
    if not path.exists():
        continue
    try:
        ast.parse(path.read_text())
    except Exception as exc:
        ERRORS.append(f"{path.relative_to(ROOT)}: Python parse failed: {exc}")

# INI syntax. (mako/swaylock deliberately have non-INI syntax.)
for rel in ("config/foot.ini", "config/fuzzel.ini"):
    path = ROOT / rel
    if not path.exists():
        continue
    parser = configparser.ConfigParser(interpolation=None, strict=True)
    try:
        parser.read(path)
    except Exception as exc:
        ERRORS.append(f"{rel}: INI parse failed: {exc}")

# Foot regressions that caused the previous session failure.
foot = (ROOT / "config/foot.ini").read_text()
check("[colors-dark]" in foot, "foot: missing [colors-dark]")
check("\n[colors]\n" not in foot, "foot: deprecated [colors] section present")
check(
    re.search(r"^cursor=[0-9a-fA-F]{6} [0-9a-fA-F]{6}$", foot, re.M) is not None,
    "foot: cursor colors must be two RRGGBB values in [colors-dark]",
)
if "[cursor]" in foot:
    cursor_section = foot.split("[cursor]", 1)[1].split("[", 1)[0]
    check("color=" not in cursor_section, "foot: invalid color= inside [cursor]")

# QML lexical balance. Limit this to the package's shell; host-base may contain
# unrelated QML from the user's old setup. The installed Quickshell performs the
# real semantic load at runtime; this catches truncation and templating damage.
for path in (ROOT / "quickshell/fui").rglob("*.qml"):
    text = strip_qml(path.read_text())
    check(text.count("{") == text.count("}"), f"{path.relative_to(ROOT)}: unbalanced braces")
    check(text.count("(") == text.count(")"), f"{path.relative_to(ROOT)}: unbalanced parentheses")
    check(text.count("[") == text.count("]"), f"{path.relative_to(ROOT)}: unbalanced brackets")

# Niri KDL structure + known dangerous regressions.
kdl = (ROOT / "niri/config.kdl").read_text()
kdl_lex = re.sub(r"//.*", "", kdl)
check(kdl_lex.count("{") == kdl_lex.count("}"), "niri config: unbalanced braces")
check("niri-session" not in kdl, "niri config: must not recursively launch niri-session")
check("GDK_BACKEND" not in kdl, "niri config: must not globally force GDK_BACKEND")
check(not re.search(r"(^|\s)DISPLAY\s*=", kdl), "niri config: must not manually set DISPLAY")
check('spawn-at-startup "fui-bootstrap"' in kdl, "niri config: guarded bootstrap startup missing")
check('spawn-at-startup "fui-shell"' not in kdl, "niri config: shell must not bypass guarded bootstrap")
check('spawn-at-startup "fui-home-layout"' not in kdl, "niri config: home layout must not race the guarded bootstrap")
check('output "eDP-1"' in kdl and 'mode "1600x900"' in kdl and 'scale 1' in kdl, "niri config: exact 1600x900 eDP-1 target missing")
for workspace in ("MAIN", "DEV", "MEDIA", "READ", "MISC"):
    check(f'workspace "{workspace}"' in kdl, f"niri config: workspace {workspace} missing")
check('Mod+T allow-inhibiting=false { spawn "fui-terminal"; }' in kdl, "niri config: Super+T recovery terminal missing or client-inhibitable")
check('Mod+L allow-when-locked=true allow-inhibiting=false { spawn "fui-lock"; }' in kdl, "niri config: lock recovery bind must work while locked and ignore client inhibition")
check('Mod+Alt+D allow-inhibiting=false { spawn "fui-fallback-launcher"; }' in kdl, "niri config: fallback launcher missing or client-inhibitable")
check('Mod+Shift+D allow-inhibiting=false { spawn "fui-shell"; }' in kdl, "niri config: shell restart recovery bind missing or client-inhibitable")
check('Mod+Shift+E allow-inhibiting=false { quit skip-confirmation=true; }' in kdl, "niri config: emergency session exit bind missing")
check('Mod+Left { focus-workspace-up; }' in kdl, "niri config: Super+Left must be previous workspace")
check('Mod+Right { focus-workspace-down; }' in kdl, "niri config: Super+Right must be next workspace")
check('Mod+R { spawn "fui-shellctl" "openCommand"; }' in kdl, "niri config: Super+R command surface missing")
check('Mod+Shift+W allow-inhibiting=false { spawn "fui-shellctl" "toggleWallpaperMotion"; }' in kdl, "niri config: wallpaper motion toggle missing or client-inhibitable")
check('Mod+Shift+Q allow-inhibiting=false { quit; }' in kdl, "niri config: advertised logout chord missing")
check('Mod+Escape allow-inhibiting=false { toggle-keyboard-shortcuts-inhibit; }' in kdl, "niri config: shortcut-inhibition escape hatch missing")
check(kdl.count("tiled-state true") >= 2, "niri config: exact home Foot sizing must disable terminal grid snapping")
bind_block = kdl.split("binds {", 1)[1].split("\n}", 1)[0] if "binds {" in kdl else ""
keys = re.findall(r"^\s*([^/\s][^\s{]*)[^\n{]*\{", bind_block, re.M)
duplicates = sorted({key for key in keys if keys.count(key) > 1})
check(not duplicates, "niri config: duplicate bind(s): " + ", ".join(duplicates))

# Shell scripts: bash parses every script before packaging.
for path in [ROOT / "install.sh", *sorted((ROOT / "scripts").glob("*")), *sorted((ROOT / "scripts/runtime").glob("*.sh"))]:
    if not path.is_file() or path.suffix == ".py":
        continue
    result = subprocess.run(["bash", "-n", str(path)], text=True, capture_output=True)
    if result.returncode:
        ERRORS.append(f"{path.relative_to(ROOT)}: bash -n failed: {result.stderr.strip()}")

# Project-source safety checks. Intentionally exclude host-base (the user's old
# known-good NixOS may contain its own login policy) and documentation prose.
source_paths: list[Path] = []
for base in (ROOT / "modules", ROOT / "niri", ROOT / "quickshell", ROOT / "config", ROOT / "scripts"):
    if base.exists():
        source_paths.extend(
            p for p in base.rglob("*")
            if p.is_file()
            and p.suffix not in {".png", ".pyc"}
            and "__pycache__" not in p.parts
            and p.name != "check-static.py"
        )
source_paths += [ROOT / "flake.nix", ROOT / "install.sh"]
all_source = "\n".join(p.read_text(errors="ignore") for p in source_paths if p.exists())
check("environment.loginShellInit" not in all_source, "unsafe graphical loginShellInit regression found")
check("nix shell" not in all_source.lower(), "unsafe temporary nix-shell compositor workflow found")
session_script = (ROOT / "scripts/runtime/fui-session.sh").read_text()
check("niri-session -l" in session_script, "session: must use the pinned niri-session -l systemd path")
check("exec niri-session\n" not in session_script and "exec niri-session \"" not in session_script, "session: bare niri-session would re-enter the login shell")
check("unset-environment NIRI_CONFIG" in session_script, "session: NIRI_CONFIG must be removed from the user manager on exit")
check("exec niri --session" not in session_script, "session: direct niri --session would skip niri.service graphical-session lifecycle on NixOS")
check("fui-preflight" in session_script, "session: TTY preflight must gate compositor startup")
check('export GTK_THEME="Adwaita:dark"' in session_script and 'export XCURSOR_THEME="Adwaita"' in session_script, "session: test-generation visual environment exports missing")
preflight_script = (ROOT / "scripts/runtime/fui-preflight.sh").read_text()
runtime_check = (ROOT / "scripts/runtime/fui-runtime-check.sh").read_text()
bootstrap_script = (ROOT / "scripts/runtime/fui-bootstrap.sh").read_text()
check("1600x900" in preflight_script and "fc-match" in preflight_script, "preflight: exact panel/font verification missing")
check("niri msg --json outputs" in runtime_check and "1600x900" in runtime_check and "scale" in runtime_check, "runtime check: live output verification missing")
check("ReactiveWallpaper.qml" in runtime_check and "SignalNode.qml" in runtime_check and "RoutePulse.qml" in runtime_check, "runtime check: installed reactive QML verification missing")
check("fui-runtime-check" in bootstrap_script and "qs -c fui ipc call shell ping" in bootstrap_script, "bootstrap: runtime+Quickshell readiness gate missing")
check("FUI CHECK FAILED" in bootstrap_script and "Super+Shift+E" in bootstrap_script, "bootstrap: graphical recovery diagnostic missing")
check('readlink -f /run/current-system > "$state_dir/runtime-ok"' in bootstrap_script, "bootstrap: exact-generation success marker missing")
home_info = (ROOT / "scripts/runtime/fui-home-info.sh").read_text()
check('shell_path="${SHELL:-/bin/sh}"' in home_info, "home terminal: safe interactive-shell fallback missing")
home_terminal = (ROOT / "scripts/runtime/fui-home-terminal.sh").read_text()
check("fui-home-info" in home_terminal, "home terminal: helper invocation missing")
status_helper = (ROOT / "scripts/fui-status.py").read_text()
check('"position": clock_us(pos)' in status_helper, "status: player position must convert microseconds")
check("psec =" not in status_helper, "status: stale playerctl-seconds conversion regression found")
check("def default_iface()" in status_helper, "status: default-route network selection missing")
check("def battery()" in status_helper and "aggregate percentage/status across all installed batteries" in status_helper, "status: multi-battery aggregation missing")
check("family_values" in status_helper and "must never be mixed" in status_helper, "status: mixed energy/charge battery-unit regression found")
check('"swap_pct":' in status_helper, "status: swap percentage missing")
check('"progress": round(progress, 4)' in status_helper, "status: MPRIS progress ratio missing")
check('(block / "partition").exists()' in status_helper, "status: whole-disk detection must use sysfs partition marker")
check("next_ip = time.monotonic() + 10.0" in status_helper and '"ip": cached_ip' in status_helper, "status: local IP must be cached instead of spawning ip every second")
status_model = (ROOT / "quickshell/fui/StatusModel.qml").read_text()
check("Math.max(rateLevel(root.rx), rateLevel(root.tx))" in status_model, "status model: reactive network history must include RX and TX")
shell_qml = (ROOT / "quickshell/fui/shell.qml").read_text()
check("function openCommand(): void" in shell_qml, "shell IPC: openCommand missing")
check('root.requestLauncher(">")' in shell_qml, "shell IPC: command launcher must start with >")
shellctl = (ROOT / "scripts/runtime/fui-shellctl.sh").read_text()
check("openCommand" in shellctl, "shellctl: openCommand usage missing")
check("toggleWallpaperMotion" in shellctl and "toggleWallpaperInteraction" in shellctl, "shellctl: wallpaper control usage missing")
check('function ping(): string { return "ok" }' in shell_qml, "shell IPC: readiness ping missing")
check("property bool launcherOpen: false" in shell_qml, "launcher: must start closed for a clean desktop")
check("property bool wallpaperMotionEnabled: true" in shell_qml, "wallpaper: motion should default enabled")
check("property bool wallpaperInteractionEnabled: true" in shell_qml, "wallpaper: interaction should default enabled")
check("function toggleWallpaperMotion(): string" in shell_qml and "function toggleWallpaperInteraction(): string" in shell_qml, "shell IPC: wallpaper toggles missing")
home_layout = (ROOT / "scripts/runtime/fui-home-layout.sh").read_text()
check("qs -c fui ipc call shell ping" in home_layout, "home layout: shell readiness wait missing")
module_text = (ROOT / "modules/fui.nix").read_text()
check("security.pam.services.swaylock = { };" in module_text, "NixOS: swaylock PAM service missing")
check("pkgs.jetbrains-mono" in module_text and "pkgs.noto-fonts" in module_text, "NixOS: deterministic UI/fallback fonts missing")
check("fonts.fontconfig" in module_text and 'monospace = [ "JetBrains Mono"' in module_text and 'emoji = [ "Noto Color Emoji"' in module_text, "NixOS: explicit Fontconfig defaults missing")
check("runtimeInputs = [ pkgs.ardour ]" in module_text and "    ardour\n" in module_text, "NixOS: Ardour must be a guaranteed music dependency")
check('GTK_THEME = "Adwaita:dark"' in module_text and 'XCURSOR_THEME = "Adwaita"' in module_text, "NixOS: deterministic toolkit/cursor defaults missing")
check("fuiShellctl" in module_text.split("fuiSettings =", 1)[1].split("fuiPowerMenu", 1)[0], "NixOS: settings must have shellctl for wallpaper toggles")
settings_script = (ROOT / "scripts/runtime/fui-settings.sh").read_text()
check("WALLPAPER / MOTION" in settings_script and "WALLPAPER / INTERACTION" in settings_script, "settings: wallpaper controls missing")
notify_script = (ROOT / "scripts/runtime/fui-notify.sh").read_text()
check("systemctl --user stop dunst.service" in notify_script, "notifications: stale Dunst user service protection missing")

install = (ROOT / "install.sh").read_text() if (ROOT / "install.sh").exists() else ""
test_script = (ROOT / "scripts/test").read_text() if (ROOT / "scripts/test").exists() else ""
apply_script = (ROOT / "scripts/apply").read_text() if (ROOT / "scripts/apply").exists() else ""
check("nixos-rebuild switch" not in install, "installer must never switch permanently")
check('scripts/verify-manifest' in (ROOT / "scripts/check").read_text(), "integrity: scripts/check must verify SOURCE-MANIFEST.sha256")
check('backup_root="$state_root/backups"' in install and '$ROOT/backups' in install, "installer: external backup migration logic missing")
check('mv "$ROOT/host-base" "$backup_root/host-base-$stamp"' in install, "installer: previous host base must be preserved outside flake source")
check('sudo cp -a /etc/nixos/. "$tmp/"' in install and "cp -aL /etc/nixos" not in install, "installer: must not recursively dereference arbitrary /etc/nixos symlinks")
check('find "$tmp" -type l -print0' in install and "[ -f \"$target\" ]" in install, "installer: linked config files should be materialized without traversing linked directories")
check('nixos-rebuild test --flake "path:$ROOT#thinkpad"' in install, "installer must use a test generation via path: flake")
check('sudo env NIX_CONFIG="experimental-features = nix-command flakes"' in install, "installer: root rebuild must enable flake features independently of the old generation")
check('nix build --no-link "path:$ROOT#checks.x86_64-linux.core-configs"' in install, "installer must validate pinned Niri/Foot before activation")
check('host-base/.keep' in install and 'rm -rf "$ROOT/host-base"' in install, "installer: distributed empty host-base must be recognized")
check("fui-preflight" in install, "installer: installed preflight must run before graphical testing")
placeholder = (ROOT / "host-base-placeholder.nix").read_text() if (ROOT / "host-base-placeholder.nix").exists() else ""
check("FUI host-base is intentionally not bundled" in placeholder, "host-base: accidental pre-install evaluation must fail clearly")
flake_text = (ROOT / "flake.nix").read_text()
check("builtins.pathExists ./host-base/configuration.nix" in flake_text and "./host-base-placeholder.nix" in flake_text, "flake: host-base must fall back to the tracked clear-error stub")
check('checks.${system}.core-configs' in (ROOT / "flake.nix").read_text(), "flake: pinned core config check missing")
check('nixos-rebuild test --flake "path:$ROOT#thinkpad"' in test_script, "test script must use path: flake")
check("Type APPLY" in apply_script and "nixos-rebuild switch" in apply_script, "apply must require explicit APPLY confirmation")
check("runtime-ok" in apply_script and "readlink -f /run/current-system" in apply_script, "apply: live-tested generation marker gate missing")
check('[ ! -r "$ROOT/host-base/configuration.nix" ]' in test_script and '[ ! -r "$ROOT/host-base/configuration.nix" ]' in apply_script, "test/apply: missing real host-base must be rejected")

# Exact design canvas and texture sizes, checked without Pillow.
for rel, size in (
    ("quickshell/fui/assets/wallpaper-1600x900.png", (1600, 900)),
    ("docs/reference-1600x900.png", (1600, 900)),
    ("quickshell/fui/assets/city-feed-reference.png", (548, 325)),
):
    path = ROOT / rel
    if not path.exists():
        continue
    try:
        actual = png_size(path)
        check(actual == size, f"{rel}: expected {size[0]}x{size[1]}, got {actual[0]}x{actual[1]}")
    except Exception as exc:
        ERRORS.append(f"{rel}: PNG check failed: {exc}")

# The 1600x900 reference coordinates that define the home composition.
desktop = (ROOT / "quickshell/fui/DesktopSurface.qml").read_text()
reactive = (ROOT / "quickshell/fui/ReactiveWallpaper.qml").read_text()
signal_node = (ROOT / "quickshell/fui/SignalNode.qml").read_text()
route_pulse = (ROOT / "quickshell/fui/RoutePulse.qml").read_text()
check("ReactiveWallpaper {" in desktop, "wallpaper: DesktopSurface must use the reactive wallpaper component")
check("motionEnabled: root.controller.wallpaperMotionEnabled" in desktop and "interactionEnabled: root.controller.wallpaperInteractionEnabled" in desktop, "wallpaper: controller state is not wired into DesktopSurface")
check('source: Qt.resolvedUrl("assets/wallpaper-1600x900.png")' in reactive, "wallpaper: approved static baseline image missing")
check("import QtQuick.Shapes" in reactive and reactive.count("ShapePath {") >= 3, "wallpaper: lightweight Qt Quick Shapes network layer missing")
check("dragOffsetX" in reactive and "GRAB // FIELD" in reactive, "wallpaper: grab/drag interaction missing")
check("workspaceRequested(modelData.name)" in reactive and all(name in reactive for name in ("MAIN", "DEV", "MEDIA", "READ", "MISC")), "wallpaper: workspace signal nodes incomplete")
check("root.networkActive" in reactive and "root.mediaActive" in reactive and "batteryWarning" in reactive and "cpuHot" in reactive, "wallpaper: real system/media reactive inputs missing")
check("interval: 1300" in reactive and "pointerIdle.restart()" in reactive, "wallpaper: pointer activity must use a low-rate idle timer")
check("ShaderEffect" not in reactive and "ParticleSystem" not in reactive and "Video" not in reactive, "wallpaper: expensive shader/particle/video path must not ship")
check("Canvas" not in strip_qml(reactive), "wallpaper: full-screen reactive component must not use Canvas repaint loops")
check("NumberAnimation on pulsePhase" in signal_node and "running: root.active && root.motionEnabled" in signal_node, "wallpaper: active-node pulse must be conditional")
check("running: root.running && root.motionEnabled" in route_pulse, "wallpaper: route pulse animation must be conditional")
check(desktop.count("DeviceLine {") >= 8, "right rail: hardware icons must use deterministic vector DeviceLine components")
for component in ("PanelFrame.qml", "CityMap.qml", "MetricBar.qml", "WorkspaceTab.qml", "DockButton.qml"):
    text = (ROOT / "quickshell/fui" / component).read_text()
    check("uiScale" in text, f"scaling: {component} must inherit output scale")
check("root.uiScale * root.uiScale" not in (ROOT / "quickshell/fui/CityMap.qml").read_text(), "scaling: accidental double scaling found in CityMap")
tech_glyph = (ROOT / "quickshell/fui/TechGlyph.qml").read_text()
check("Canvas" in tech_glyph and 'kind === "battery"' in tech_glyph, "vector glyph component incomplete")
notes_script = (ROOT / "scripts/runtime/fui-notes.sh").read_text()
check("No one is coming" not in notes_script and "The Pragmatic Programmer" not in notes_script, "notes: mock-up placeholder content must not ship")
for fragment in (
    "x: 136 * root.s; y: 158 * root.s",
    "width: 475 * root.s; height: 382 * root.s",
    "x: 136 * root.s; y: 560 * root.s",
    "width: 350 * root.s; height: 195 * root.s",
    "x: 673 * root.s; y: 181 * root.s",
    "x: 650 * root.s; y: 369 * root.s",
    "margins.left: Math.round(272 * root.s)",
    "margins.top: Math.round(105 * root.s)",
    "margins.right: Math.round(15 * root.s)",
    "width: parent.width; height: 603 * root.s",
    "x: 0; y: 616 * root.s",
    "width: parent.width; height: 136 * root.s",
    "x: 0; y: 153 * root.s; width: parent.width; height: 26 * root.s",
    "x: 0; y: 276 * root.s; width: parent.width; height: 27 * root.s",
    "x: 0; y: 458 * root.s; width: parent.width; height: 27 * root.s",
    'text: "SUPER + R         RUN COMMAND"',
    'text: "SUPER + SHIFT + W WALLPAPER FX"',
):
    check(fragment in desktop, f"reference-layout regression: {fragment}")
check("function onLauncherRequested(initialText)" in desktop, "launcher: IPC request handler missing")
check("readonly property var findModeModel" in desktop, "launcher: find-mode model missing")
check("property int findModeIndex: 0" in desktop, "launcher: keyboard find-mode selection missing")
check("root.status.playerProgress" in desktop, "now playing: progress bar must use live MPRIS progress")
check("level: root.status.swapPct" in desktop, "right rail: swap meter must use real swap percentage")
check("!entry.noDisplay" in desktop, "launcher: hidden desktop entries must be filtered")
check("event.key === Qt.Key_Tab" in desktop, "launcher: Tab navigation missing")
check("root.runFind(root.findModeModel[launcher.findModeIndex].action)" in desktop, "launcher: Enter must execute selected find mode")
check('launcherInput.text = "find"' not in desktop.split("onVisibleChanged:", 1)[-1], "launcher: visibility must not overwrite command mode")

# Do not package generated Python bytecode: it can carry stale strings and is
# useless on the target system.
owned_cache_roots = [ROOT / "scripts", ROOT / "config", ROOT / "quickshell"]
pycache_files = [
    p for base in owned_cache_roots for p in base.rglob("*")
    if p.is_file() and (p.suffix == ".pyc" or "__pycache__" in p.parts)
]
check(not pycache_files, "packaging: generated Python bytecode present: " + ", ".join(str(p.relative_to(ROOT)) for p in pycache_files))

if ERRORS:
    print("STATIC CHECK FAILED")
    for error in ERRORS:
        print(" -", error)
    sys.exit(1)

print("STATIC CHECK OK")
print("Python/INI/Bash syntax, QML/KDL structure, 1600x900 assets, layout anchors, reactive-wallpaper safety, and known regressions passed.")

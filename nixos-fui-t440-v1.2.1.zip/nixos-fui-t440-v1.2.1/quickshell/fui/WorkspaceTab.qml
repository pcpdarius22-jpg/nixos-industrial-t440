import QtQuick

Item {
    id: root
    property string number: "01"
    property string label: "MAIN"
    property bool active: false
    property real uiScale: 1
    signal clicked()

    implicitWidth: 96 * uiScale
    implicitHeight: 36 * uiScale

    Rectangle { anchors.fill: parent; color: root.active ? "#10171a" : "transparent" }
    Rectangle { visible: root.active; anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom; height: Math.max(1, root.uiScale); color: "#849398" }
    Text {
        anchors.centerIn: parent
        text: root.number + "  " + root.label
        color: root.active ? "#d7dcde" : "#59666c"
        font.family: "JetBrains Mono"
        font.pixelSize: 8 * root.uiScale
        font.letterSpacing: 0.6 * root.uiScale
    }
    MouseArea {
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}

import QtQuick
import Quickshell
import Quickshell.Io
import Quickshell.Wayland

Scope {
    id: root
    required property var screen
    required property var status
    required property var controller

    readonly property real s: Math.max(0.65, Math.min(screen.width / 1600.0, screen.height / 900.0))
    readonly property color bg: "#05090b"
    readonly property color panel: "#070c0f"
    readonly property color panel2: "#080e11"
    readonly property color line: "#26343a"
    readonly property color fg: "#c8cdd0"
    readonly property color dim: "#5f6c72"
    readonly property color dim2: "#39474d"
    readonly property color cyan: "#66979a"
    readonly property color amber: "#c98d42"
    readonly property string fontFamily: "JetBrains Mono"

    property var workspaceModel: [
        { number: "01", name: "MAIN" },
        { number: "02", name: "DEV" },
        { number: "03", name: "MEDIA" },
        { number: "04", name: "READ" },
        { number: "05", name: "MISC" }
    ]

    readonly property var findModeModel: [
        { label:"FILE SEARCH", sub:"Search for files", action:"files" },
        { label:"FIND IN FILES", sub:"Search file contents", action:"grep" },
        { label:"RECENT FILES", sub:"Show recently used files", action:"recent" },
        { label:"FIND APPLICATIONS", sub:"Search installed apps", action:"apps" },
        { label:"NETWORK SCAN", sub:"Scan network status", action:"network" },
        { label:"MIND MAP", sub:"Visualize your thoughts", action:"mind" }
    ]

    function exec(args) { Quickshell.execDetached(args) }

    function workspaceNumber(name) {
        for (var i = 0; i < workspaceModel.length; ++i) {
            if (workspaceModel[i].name === name) return workspaceModel[i].number
        }
        return "01"
    }

    function runDock(action) {
        if (action === "terminal") exec(["fui-terminal"])
        else if (action === "files") exec(["fui-files"])
        else if (action === "browser") exec(["fui-browser"])
        else if (action === "music") exec(["fui-music"])
        else if (action === "reader") exec(["fui-reader"])
        else if (action === "settings") exec(["fui-settings"])
    }

    function runFind(action) {
        controller.launcherOpen = false
        if (action === "files") exec(["fui-files"])
        else if (action === "grep") exec(["fui-grep-files"])
        else if (action === "recent") exec(["fui-recent-files"])
        else if (action === "apps") {
            controller.launcherOpen = true
            launcherInput.text = ""
            launcherInput.forceActiveFocus()
        }
        else if (action === "network") exec(["fui-network"])
        else if (action === "mind") exec(["fui-notes"])
    }

    Connections {
        target: root.controller
        function onLauncherRequested(initialText) {
            launcherInput.text = initialText
            launcherInput.forceActiveFocus()
        }
    }

    // ------------------------------------------------------------------
    // BACKGROUND / HOME DASHBOARD — below application windows.
    PanelWindow {
        id: backgroundWindow
        screen: root.screen
        anchors { top: true; bottom: true; left: true; right: true }
        exclusionMode: ExclusionMode.Ignore
        color: root.bg
        focusable: false
        WlrLayershell.layer: WlrLayer.Background
        WlrLayershell.namespace: "fui-background"

        ReactiveWallpaper {
            anchors.fill: parent
            status: root.status
            fontFamily: root.fontFamily
            uiScale: root.s
            motionEnabled: root.controller.wallpaperMotionEnabled
            interactionEnabled: root.controller.wallpaperInteractionEnabled
            cyan: root.cyan
            amber: root.amber
            onWorkspaceRequested: function(name) {
                root.exec(["niri", "msg", "action", "focus-workspace", name])
            }
            onActionRequested: function(action) {
                if (action === "network") root.exec(["fui-network"])
            }
        }

        Item {
            id: stage
            width: 1600 * root.s
            height: 900 * root.s
            anchors.centerIn: parent

            // sparse boot/system signature at upper left, like the reference.
            Text {
                x: 124 * root.s; y: 68 * root.s
                text: "SYSTEM ONLINE.\nFUI SHELL / 01\n" + (root.status.kernel ? "KERNEL " + root.status.kernel : "")
                color: "#57666c"
                font.family: root.fontFamily
                font.pixelSize: 8 * root.s
                font.letterSpacing: 0.7 * root.s
                lineHeight: 1.18
            }

            // large clock/date.
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                y: 61 * root.s
                text: root.status.timeText
                color: "#e0e4e5"
                font.family: root.fontFamily
                font.pixelSize: 43 * root.s
                font.weight: Font.Light
                font.letterSpacing: 4 * root.s
            }
            Text {
                x: parent.width / 2 + 73 * root.s; y: 79 * root.s
                text: root.status.seconds
                color: "#aab3b7"
                font.family: root.fontFamily
                font.pixelSize: 16 * root.s
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                y: 121 * root.s
                text: root.status.dateText
                color: "#7a878c"
                font.family: root.fontFamily
                font.pixelSize: 9 * root.s
                font.letterSpacing: 1.6 * root.s
            }

            // Outer frames for the two *real* Foot windows. They stay in the
            // shell background while Niri places the actual terminal/editor
            // precisely in the content area below the 28px header.
            PanelFrame {
                x: 136 * root.s; y: 158 * root.s
                width: 475 * root.s; height: 382 * root.s
                title: "TERMINAL"
                panelColor: root.panel
                borderColor: root.line
                foreground: root.fg
                dim: root.dim
                fontFamily: root.fontFamily
                uiScale: root.s
            }
            PanelFrame {
                x: 136 * root.s; y: 560 * root.s
                width: 350 * root.s; height: 195 * root.s
                title: "NOTES.md"
                panelColor: root.panel
                borderColor: root.line
                foreground: root.fg
                dim: root.dim
                fontFamily: root.fontFamily
                uiScale: root.s
            }

            // NOW PLAYING card.
            PanelFrame {
                x: 673 * root.s; y: 181 * root.s
                width: 296 * root.s; height: 166 * root.s
                title: "NOW PLAYING"
                panelColor: "#070c0f"
                borderColor: root.line
                foreground: root.fg
                dim: root.dim
                fontFamily: root.fontFamily
                uiScale: root.s

                Rectangle {
                    x: 16 * root.s; y: 45 * root.s
                    width: 58 * root.s; height: 58 * root.s
                    color: "#0c171b"
                    border.width: 1; border.color: root.line
                    Canvas {
                        anchors.fill: parent
                        onPaint: {
                            var c=getContext("2d"); c.clearRect(0,0,width,height)
                            c.strokeStyle="#5f8e92"; c.lineWidth=1
                            for(var i=7;i<width;i+=9){ c.beginPath(); c.moveTo(i,height-7); c.lineTo(width/2,7); c.stroke() }
                        }
                    }
                }
                Text {
                    x: 88 * root.s; y: 49 * root.s
                    width: 190 * root.s
                    text: root.status.track
                    elide: Text.ElideRight
                    color: root.fg
                    font.family: root.fontFamily
                    font.pixelSize: 10 * root.s
                }
                Text {
                    x: 88 * root.s; y: 69 * root.s
                    width: 190 * root.s
                    text: root.status.artist || "LOCAL / MPRIS"
                    elide: Text.ElideRight
                    color: root.dim
                    font.family: root.fontFamily
                    font.pixelSize: 8 * root.s
                }
                Rectangle {
                    x: 16 * root.s; y: 118 * root.s
                    width: 270 * root.s; height: 1
                    color: root.line
                    Rectangle { width: parent.width * Math.max(0, Math.min(1, root.status.playerProgress)); height: 1; color: root.fg }
                }
                Row {
                    x: 77 * root.s; y: 134 * root.s; spacing: 28 * root.s
                    Text { text: "|<"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 11 * root.s; MouseArea { anchors.fill: parent; onClicked: root.exec(["playerctl","previous"]) } }
                    Text { text: root.status.playing ? "||" : ">"; color: root.fg; font.family: root.fontFamily; font.pixelSize: 11 * root.s; MouseArea { anchors.fill: parent; onClicked: root.exec(["playerctl","play-pause"]) } }
                    Text { text: ">|"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 11 * root.s; MouseArea { anchors.fill: parent; onClicked: root.exec(["playerctl","next"]) } }
                }
                Text {
                    anchors.right: parent.right; anchors.rightMargin: 14 * root.s; y: 136 * root.s
                    text: (root.status.position || "--:--") + " / " + (root.status.length || "--:--")
                    color: root.dim
                    font.family: root.fontFamily
                    font.pixelSize: 7 * root.s
                }
            }

            CityMap {
                x: 650 * root.s; y: 369 * root.s
                width: 603 * root.s; height: 388 * root.s
                status: root.status
                fontFamily: root.fontFamily
                uiScale: root.s
            }

            // little technical marks floating in empty space.
            Rectangle { x: 1026 * root.s; y: 93 * root.s; width: 28 * root.s; height: 1; color: "#24343a" }
            Rectangle { x: 1040 * root.s; y: 79 * root.s; width: 1; height: 28 * root.s; color: "#24343a" }
            Text { x: 1062 * root.s; y: 83 * root.s; text: ">"; color: "#3e5057"; font.family: root.fontFamily; font.pixelSize: 11 * root.s }
        }
    }

    // ------------------------------------------------------------------
    // TOP SYSTEM STRIP — exact 36 px on the 1600x900 target.
    PanelWindow {
        id: topBar
        screen: root.screen
        anchors { top: true; left: true; right: true }
        implicitHeight: Math.round(36 * root.s)
        exclusiveZone: Math.round(36 * root.s)
        color: root.bg
        WlrLayershell.layer: WlrLayer.Top
        WlrLayershell.namespace: "fui-top"

        Rectangle { anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom; height: 1; color: root.line }

        Text {
            x: 12 * root.s; anchors.verticalCenter: parent.verticalCenter
            text: "‹  " + root.workspaceNumber(root.status.workspace) + " WORKSPACE"
            color: root.fg
            font.family: root.fontFamily
            font.pixelSize: 8 * root.s
            font.letterSpacing: 0.7 * root.s
        }

        Row {
            x: 326 * root.s; height: parent.height; spacing: 0
            Repeater {
                model: root.workspaceModel
                WorkspaceTab {
                    width: 60 * root.s; height: topBar.height
                    number: modelData.number
                    label: modelData.name
                    active: root.status.workspace === modelData.name
                    uiScale: root.s
                    onClicked: root.exec(["niri","msg","action","focus-workspace",modelData.name])
                }
            }
        }

        Row {
            anchors.right: parent.right; anchors.rightMargin: 8 * root.s
            y: 0; height: parent.height
            spacing: 8 * root.s
            TopMetric { width: 94 * root.s; height: topBar.height; uiScale: root.s; kind: "cpu"; value: Math.round(root.status.cpu) + "%"; level: root.status.cpu }
            TopMetric { width: 94 * root.s; height: topBar.height; uiScale: root.s; kind: "memory"; value: root.status.memUsed; level: root.status.memPct }
            TopMetric { width: 94 * root.s; height: topBar.height; uiScale: root.s; kind: "battery"; value: root.status.battery < 0 ? "AC" : root.status.battery + "%"; level: root.status.battery < 0 ? 100 : root.status.battery; foreground: root.status.battery >= 0 && root.status.battery < 20 ? root.amber : root.fg }
            Item {
                width: 34 * root.s; height: topBar.height
                Canvas {
                    id: powerIcon
                    anchors.centerIn: parent
                    width: 17 * root.s; height: 17 * root.s
                    onPaint: {
                        var c=getContext("2d"); c.clearRect(0,0,width,height)
                        c.strokeStyle=root.fg; c.lineWidth=Math.max(1,root.s); c.lineCap="square"
                        var ss=root.s
                        c.beginPath(); c.arc(8.5*ss,9*ss,6*ss,-0.75*Math.PI,0.75*Math.PI); c.stroke()
                        c.beginPath(); c.moveTo(8.5*ss,1*ss); c.lineTo(8.5*ss,8*ss); c.stroke()
                    }
                }
                MouseArea { anchors.fill: parent; cursorShape: Qt.PointingHandCursor; onClicked: root.exec(["fui-power-menu"]) }
            }
        }
    }

    // ------------------------------------------------------------------
    // LEFT COMMAND / APP RAIL.
    PanelWindow {
        id: leftDock
        screen: root.screen
        anchors { top: true; bottom: true; left: true }
        margins.top: Math.round(36 * root.s)
        implicitWidth: Math.round(98 * root.s)
        exclusiveZone: Math.round(98 * root.s)
        color: root.bg
        WlrLayershell.layer: WlrLayer.Top
        WlrLayershell.namespace: "fui-left"

        Rectangle { anchors.right: parent.right; width: 1; height: parent.height; color: root.line }

        Item {
            x: 0; y: 16 * root.s; width: parent.width; height: 90 * root.s
            Canvas {
                anchors.horizontalCenter: parent.horizontalCenter
                y: 5 * root.s; width: 50 * root.s; height: 50 * root.s
                onPaint: {
                    var c=getContext("2d"); c.clearRect(0,0,width,height)
                    c.strokeStyle="#bdc5c8"; c.lineWidth=1.4
                    var cx=width/2,cy=height/2,r=19*root.s
                    c.beginPath()
                    for(var i=0;i<6;i++){ var a=Math.PI/3*i-Math.PI/6; var x=cx+r*Math.cos(a),y=cy+r*Math.sin(a); if(i===0)c.moveTo(x,y); else c.lineTo(x,y) }
                    c.closePath(); c.stroke()
                    c.strokeStyle="#5e8f93"
                    c.beginPath(); c.moveTo(cx-7*root.s,cy+8*root.s); c.lineTo(cx-7*root.s,cy-7*root.s); c.lineTo(cx+1*root.s,cy-1*root.s); c.lineTo(cx+8*root.s,cy-9*root.s); c.stroke()
                }
            }
        }

        Column {
            x: 0; y: 111 * root.s; width: parent.width; spacing: 0
            DockButton { width: leftDock.width; height: 82 * root.s; uiScale: root.s; kind: "terminal"; label: "TERMINAL"; active: root.status.workspace === "DEV"; onClicked: root.runDock("terminal") }
            DockButton { width: leftDock.width; height: 82 * root.s; uiScale: root.s; kind: "files"; label: "FILES"; onClicked: root.runDock("files") }
            DockButton { width: leftDock.width; height: 82 * root.s; uiScale: root.s; kind: "browser"; label: "BROWSER"; onClicked: root.runDock("browser") }
            DockButton { width: leftDock.width; height: 82 * root.s; uiScale: root.s; kind: "music"; label: "MUSIC"; active: root.status.workspace === "MEDIA"; onClicked: root.runDock("music") }
            DockButton { width: leftDock.width; height: 82 * root.s; uiScale: root.s; kind: "reader"; label: "READER"; active: root.status.workspace === "READ"; onClicked: root.runDock("reader") }
            DockButton { width: leftDock.width; height: 82 * root.s; uiScale: root.s; kind: "settings"; label: "SETTINGS"; onClicked: root.runDock("settings") }
        }

        Column {
            anchors.left: parent.left; anchors.leftMargin: 14 * root.s
            anchors.bottom: parent.bottom; anchors.bottomMargin: 28 * root.s
            spacing: 7 * root.s
            Text { text: "LAN"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: root.status.ip; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: "RX " + root.status.rx; color: root.cyan; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: "TX " + root.status.tx; color: root.amber; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
        }
    }

    // ------------------------------------------------------------------
    // RIGHT LIVE STATUS / DEVICE RAIL.
    PanelWindow {
        id: rightRail
        screen: root.screen
        anchors { top: true; bottom: true; right: true }
        margins.top: Math.round(105 * root.s)
        margins.right: Math.round(15 * root.s)
        margins.bottom: Math.round(43 * root.s)
        implicitWidth: Math.round(227 * root.s)
        exclusiveZone: Math.round(242 * root.s)
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Top
        WlrLayershell.namespace: "fui-right"

        // Match the approved reference exactly on 1600×900: the live SYSTEM
        // frame is y=105..708 and the separate QUOTE frame is y=721..857.
        Rectangle {
            id: rightMainFrame
            x: 0; y: 0
            width: parent.width; height: 603 * root.s
            color: root.panel
            border.width: 1; border.color: root.line
        }
        Rectangle {
            id: quoteFrame
            x: 0; y: 616 * root.s
            width: parent.width; height: 136 * root.s
            color: "#060b0e"
            border.width: 1; border.color: root.line
        }

        Text { x: 13 * root.s; y: 12 * root.s; text: "SYSTEM"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 8 * root.s; font.letterSpacing: 0.8 * root.s }
        Text { anchors.right: parent.right; anchors.rightMargin: 12 * root.s; y: 12 * root.s; text: "×"; color: root.dim2; font.family: root.fontFamily; font.pixelSize: 9 * root.s }

        Column {
            x: 13 * root.s; y: 38 * root.s; width: parent.width - 26 * root.s; spacing: 3 * root.s
            MetricBar { width: parent.width; uiScale: root.s; label: "CPU"; value: Math.round(root.status.cpu)+"%"; level: root.status.cpu; accent: root.cyan }
            MetricBar { width: parent.width; uiScale: root.s; label: "RAM"; value: root.status.memUsed+" / "+root.status.memTotal; level: root.status.memPct; accent: root.cyan }
            MetricBar { width: parent.width; uiScale: root.s; label: "SWAP"; value: root.status.swapUsed+" / "+root.status.swapTotal; level: root.status.swapPct; accent: root.cyan }
            MetricBar { width: parent.width; uiScale: root.s; label: "DISK"; value: root.status.diskUsed+" / "+root.status.diskTotal; level: root.status.diskPct; accent: root.amber }
            MetricBar {
                width: parent.width
                uiScale: root.s
                label: "TEMP"
                value: root.status.temp === "--" ? "--" : root.status.temp + "°C"
                level: root.status.temp === "--" ? 0 : Math.min(100, Number(root.status.temp))
                accent: root.status.temp !== "--" && Number(root.status.temp) > 75 ? root.amber : root.cyan
            }
        }

        Rectangle { x: 0; y: 153 * root.s; width: parent.width; height: 26 * root.s; color: "#080e11" }
        Rectangle { x: 0; y: 153 * root.s; width: parent.width; height: 1; color: root.line }
        Rectangle { x: 0; y: 178 * root.s; width: parent.width; height: 1; color: root.line }
        Text { x: 13 * root.s; y: 162 * root.s; text: "NETWORK"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 8 * root.s; font.letterSpacing: 0.8 * root.s }
        Text { x: 13 * root.s; y: 191 * root.s; text: root.status.iface.toUpperCase(); color: root.fg; font.family: root.fontFamily; font.pixelSize: 8 * root.s }
        Text { anchors.right: parent.right; anchors.rightMargin: 13 * root.s; y: 191 * root.s; text: root.status.ip; color: root.dim; font.family: root.fontFamily; font.pixelSize: 8 * root.s }
        LineGraph { x: 13 * root.s; y: 216 * root.s; width: parent.width - 26 * root.s; height: 30 * root.s; values: root.status.netHistory; lineColor: root.cyan }
        Text { x: 59 * root.s; y: 254 * root.s; text: "↑ " + root.status.tx; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
        Text { anchors.right: parent.right; anchors.rightMargin: 26 * root.s; y: 254 * root.s; text: "↓ " + root.status.rx; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }

        Rectangle { x: 0; y: 276 * root.s; width: parent.width; height: 27 * root.s; color: "#080e11" }
        Rectangle { x: 0; y: 276 * root.s; width: parent.width; height: 1; color: root.line }
        Rectangle { x: 0; y: 302 * root.s; width: parent.width; height: 1; color: root.line }
        Text { x: 13 * root.s; y: 286 * root.s; text: "DEVICES"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 8 * root.s; font.letterSpacing: 0.8 * root.s }
        Column {
            x: 13 * root.s; y: 313 * root.s; width: parent.width - 26 * root.s; spacing: 6 * root.s
            DeviceLine { width: parent.width; kind: "laptop"; text: root.status.model; color: root.fg; fontFamily: root.fontFamily; scaleFactor: root.s }
            DeviceLine { width: parent.width; kind: "cpu"; text: root.status.cpuModel; color: root.dim; fontFamily: root.fontFamily; scaleFactor: root.s }
            DeviceLine { width: parent.width; kind: "gpu"; text: root.status.gpuModel; color: root.dim; fontFamily: root.fontFamily; scaleFactor: root.s }
            DeviceLine { width: parent.width; kind: "memory"; text: "MEMORY  " + root.status.memTotal; color: root.dim; fontFamily: root.fontFamily; scaleFactor: root.s }
            DeviceLine { width: parent.width; kind: "disk"; text: root.status.diskModel; color: root.dim; fontFamily: root.fontFamily; scaleFactor: root.s }
            DeviceLine { width: parent.width; kind: "network"; text: root.status.netModel; color: root.dim; fontFamily: root.fontFamily; scaleFactor: root.s }
            DeviceLine { width: parent.width; kind: "link"; text: root.status.iface + "  /  " + root.status.ip; color: root.dim; fontFamily: root.fontFamily; scaleFactor: root.s }
            DeviceLine { width: parent.width; kind: "battery"; text: "BATTERY  " + (root.status.battery < 0 ? "AC" : root.status.battery + "%  " + root.status.batteryStatus.toUpperCase()); color: root.status.battery >= 0 && root.status.battery < 20 ? root.amber : root.dim; fontFamily: root.fontFamily; scaleFactor: root.s }
        }

        Rectangle { x: 0; y: 458 * root.s; width: parent.width; height: 27 * root.s; color: "#080e11" }
        Rectangle { x: 0; y: 458 * root.s; width: parent.width; height: 1; color: root.line }
        Rectangle { x: 0; y: 484 * root.s; width: parent.width; height: 1; color: root.line }
        Text { x: 13 * root.s; y: 468 * root.s; text: "SHORTCUTS"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 8 * root.s; font.letterSpacing: 0.8 * root.s }
        Column {
            x: 13 * root.s; y: 498 * root.s; spacing: 7 * root.s
            Text { text: "SUPER + D         LAUNCHER"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: "SUPER + Q         CLOSE WINDOW"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: "SUPER + LEFT      PREV WORKSPACE"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: "SUPER + RIGHT     NEXT WORKSPACE"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: "SUPER + SHIFT + Q LOGOUT"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: "SUPER + R         RUN COMMAND"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
            Text { text: "SUPER + SHIFT + W WALLPAPER FX"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
        }

        Text { x: 10 * root.s; y: 624 * root.s; text: "QUOTE"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
        Text {
            x: 22 * root.s; y: 650 * root.s; width: parent.width - 44 * root.s
            text: "THE QUIETER YOU BECOME,\nTHE MORE YOU ARE ABLE\nTO HEAR."
            color: root.fg
            font.family: root.fontFamily
            font.pixelSize: 8 * root.s
            lineHeight: 1.35
        }
        Text { x: 22 * root.s; y: 716 * root.s; text: "— RUMI"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.s }

        MouseArea {
            x: 0; y: 153 * root.s; width: parent.width; height: 123 * root.s
            onClicked: root.exec(["fui-network"])
        }
    }

    // ------------------------------------------------------------------
    // BOTTOM COMMAND SURFACE. Normal sessions start clean/closed; Super+D opens
    // the same command surface shown in the approved reference, Escape closes it.
    PanelWindow {
        id: launcher
        screen: root.screen
        visible: root.controller.launcherOpen
        anchors { bottom: true; left: true; right: true }
        margins.left: Math.round(272 * root.s)
        margins.right: Math.round(272 * root.s)
        margins.bottom: 0
        implicitHeight: Math.round(121 * root.s)
        exclusionMode: ExclusionMode.Ignore
        focusable: true
        color: root.panel
        WlrLayershell.layer: WlrLayer.Top
        WlrLayershell.namespace: "fui-launcher"

        property int findModeIndex: 0

        Rectangle { anchors.fill: parent; color: root.panel; border.width: 1; border.color: root.line }

        Rectangle {
            x: 12 * root.s; y: 12 * root.s; width: 37 * root.s; height: 34 * root.s
            color: "#081013"; border.width: 1; border.color: root.line
            Text { anchors.centerIn: parent; text: ">"; color: root.cyan; font.family: root.fontFamily; font.pixelSize: 12 * root.s }
        }
        TextInput {
            id: launcherInput
            x: 58 * root.s; y: 12 * root.s
            width: parent.width - 72 * root.s; height: 34 * root.s
            color: root.fg
            selectionColor: root.cyan
            selectedTextColor: root.bg
            font.family: root.fontFamily
            font.pixelSize: 9 * root.s
            verticalAlignment: TextInput.AlignVCenter
            text: "find"
            clip: true
            onTextChanged: {
                if (appList.currentIndex >= appList.count) appList.currentIndex = Math.max(0, appList.count - 1)
                if (text.trim().toLowerCase() === "find") launcher.findModeIndex = 0
            }
            Keys.onPressed: function(event) {
                if (event.key === Qt.Key_Escape) {
                    root.controller.launcherOpen = false
                    event.accepted = true
                } else if (findModes.visible && event.key === Qt.Key_Left) {
                    launcher.findModeIndex = Math.max(0, launcher.findModeIndex - 1)
                    event.accepted = true
                } else if (findModes.visible && event.key === Qt.Key_Right) {
                    launcher.findModeIndex = Math.min(root.findModeModel.length - 1, launcher.findModeIndex + 1)
                    event.accepted = true
                } else if (findModes.visible && event.key === Qt.Key_Tab) {
                    launcher.findModeIndex = (launcher.findModeIndex + 1) % root.findModeModel.length
                    event.accepted = true
                } else if (appList.visible && event.key === Qt.Key_Left) {
                    appList.currentIndex = Math.max(0, appList.currentIndex - 1)
                    event.accepted = true
                } else if (appList.visible && (event.key === Qt.Key_Right || event.key === Qt.Key_Tab)) {
                    appList.currentIndex = Math.min(appList.count - 1, appList.currentIndex + 1)
                    event.accepted = true
                } else if ((event.key === Qt.Key_Return || event.key === Qt.Key_Enter)) {
                    var q = text.trim()
                    if (q.length > 1 && q.charAt(0) === ">") {
                        root.controller.launcherOpen = false
                        root.exec(["sh","-lc",q.slice(1)])
                    } else if (findModes.visible && root.findModeModel.length > 0) {
                        root.runFind(root.findModeModel[launcher.findModeIndex].action)
                    } else if (appList.visible && appList.count > 0 && appList.currentItem) {
                        appList.currentItem.entry.execute()
                        root.controller.launcherOpen = false
                    }
                    event.accepted = true
                }
            }
        }
        Rectangle { x: 49 * root.s; y: 12 * root.s; width: 1; height: 34 * root.s; color: root.line }
        Rectangle { x: 0; y: 54 * root.s; width: parent.width; height: 1; color: root.line }

        Row {
            id: findModes
            visible: launcherInput.text.trim().toLowerCase() === "find"
            x: 12 * root.s; y: 62 * root.s
            spacing: 4 * root.s
            Repeater {
                model: root.findModeModel
                Rectangle {
                    width: (launcher.width - 44 * root.s) / 6
                    height: 42 * root.s
                    color: index === launcher.findModeIndex ? "#111b1f" : (modeMouse.containsMouse ? "#10191d" : "#080e11")
                    border.width: 1; border.color: index === launcher.findModeIndex ? root.cyan : root.line
                    Text { x: 8 * root.s; y: 7 * root.s; text: modelData.label; color: root.fg; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
                    Text { x: 8 * root.s; y: 23 * root.s; text: modelData.sub; color: root.dim; font.family: root.fontFamily; font.pixelSize: 6 * root.s }
                    MouseArea { id: modeMouse; anchors.fill: parent; hoverEnabled: true; onClicked: root.runFind(modelData.action) }
                }
            }
        }

        ScriptModel {
            id: filteredApps
            values: {
                var q = launcherInput.text.trim().toLowerCase()
                if (q === "find" || q.charAt(0) === ">") return []
                var visibleApps = DesktopEntries.applications.values.filter(function(entry) { return !entry.noDisplay })
                if (!q) return visibleApps.slice(0, 6)
                return visibleApps.filter(function(entry) {
                    return String(entry.name || "").toLowerCase().indexOf(q) >= 0 || String(entry.genericName || "").toLowerCase().indexOf(q) >= 0
                }).slice(0, 6)
            }
        }

        ListView {
            id: appList
            visible: filteredApps.values.length > 0
            x: 12 * root.s; y: 62 * root.s
            width: parent.width - 24 * root.s; height: 42 * root.s
            orientation: ListView.Horizontal
            spacing: 4 * root.s
            clip: true
            model: filteredApps
            currentIndex: 0
            delegate: Rectangle {
                required property var modelData
                property var entry: modelData
                width: (appList.width - 20 * root.s) / Math.max(1, Math.min(6, appList.count))
                height: 42 * root.s
                color: ListView.isCurrentItem ? "#111b1f" : (appMouse.containsMouse ? "#0d1519" : "#080e11")
                border.width: 1; border.color: ListView.isCurrentItem ? root.cyan : root.line
                Text { x: 8 * root.s; y: 7 * root.s; width: parent.width - 16 * root.s; elide: Text.ElideRight; text: entry.name.toUpperCase(); color: root.fg; font.family: root.fontFamily; font.pixelSize: 7 * root.s }
                Text { x: 8 * root.s; y: 23 * root.s; width: parent.width - 16 * root.s; elide: Text.ElideRight; text: (entry.genericName || "APPLICATION").toUpperCase(); color: root.dim; font.family: root.fontFamily; font.pixelSize: 6 * root.s }
                MouseArea { id: appMouse; anchors.fill: parent; hoverEnabled: true; onClicked: { entry.execute(); root.controller.launcherOpen = false } }
            }
        }

        Text {
            anchors.right: parent.right; anchors.rightMargin: 12 * root.s; anchors.bottom: parent.bottom; anchors.bottomMargin: 4 * root.s
            text: "ENTER  OK     TAB  NEXT     ← →  SELECT     ESC  CLOSE     >  SHELL COMMAND"
            color: root.dim2
            font.family: root.fontFamily
            font.pixelSize: 6 * root.s
        }

        onVisibleChanged: {
            if (visible) launcherInput.forceActiveFocus()
        }
    }
}

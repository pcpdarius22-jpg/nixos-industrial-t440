import QtQuick
import QtQuick.Shapes

Item {
    id: root

    property var status
    property string fontFamily: "JetBrains Mono"
    property real uiScale: 1
    property bool motionEnabled: true
    property bool interactionEnabled: true
    property color cyan: "#66979a"
    property color amber: "#c98d42"
    property color dim: "#46565c"
    signal workspaceRequested(string name)
    signal actionRequested(string action)

    clip: true

    readonly property string workspace: root.status ? root.status.workspace : "MAIN"
    readonly property real netLevel: root.status && root.status.netHistory && root.status.netHistory.length
        ? Number(root.status.netHistory[root.status.netHistory.length - 1]) : 0
    readonly property bool networkActive: root.status && root.status.iface !== "offline" && root.netLevel > 0.15
    readonly property bool mediaActive: root.status && root.status.playing
    readonly property bool batteryWarning: root.status && root.status.battery >= 0
        && root.status.battery <= 15 && String(root.status.batteryStatus).toLowerCase().indexOf("discharg") >= 0
    readonly property bool cpuHot: root.status && Number(root.status.cpu) >= 75
    readonly property color workspaceAccent: root.workspace === "MEDIA" ? root.amber
        : (root.workspace === "READ" ? "#839095" : root.cyan)

    property real pointerX: width / 2
    property real pointerY: height / 2
    property bool pointerActive: false
    property real dragOffsetX: 0
    property real dragOffsetY: 0
    property real dragStartX: 0
    property real dragStartY: 0
    onInteractionEnabledChanged: {
        if (!root.interactionEnabled) {
            root.pointerActive = false
            root.dragOffsetX = 0
            root.dragOffsetY = 0
        }
    }
    Behavior on dragOffsetX { enabled: !pointerTracker.pressed; NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
    Behavior on dragOffsetY { enabled: !pointerTracker.pressed; NumberAnimation { duration: 240; easing.type: Easing.OutCubic } }
    readonly property real pointerDX: root.pointerActive && root.motionEnabled && root.width > 0
        ? (root.pointerX / root.width - 0.5) : 0
    readonly property real pointerDY: root.pointerActive && root.motionEnabled && root.height > 0
        ? (root.pointerY / root.height - 0.5) : 0

    // The approved static wallpaper remains the exact underlying image; the reactive field is drawn above it.
    Image {
        anchors.fill: parent
        source: Qt.resolvedUrl("assets/wallpaper-1600x900.png")
        fillMode: Image.PreserveAspectCrop
        smooth: true
    }

    // Passive pointer tracking. It only runs while the pointer is on empty
    // wallpaper; app windows and the top/side shell surfaces remain above this
    // background-layer window and keep their normal input behavior.
    MouseArea {
        id: pointerTracker
        anchors.fill: parent
        enabled: root.interactionEnabled
        hoverEnabled: true
        acceptedButtons: Qt.LeftButton
        onEntered: root.pointerActive = true
        onExited: {
            root.pointerActive = false
            root.dragOffsetX = 0
            root.dragOffsetY = 0
        }
        onPressed: function(mouse) {
            root.dragStartX = mouse.x - root.dragOffsetX
            root.dragStartY = mouse.y - root.dragOffsetY
            root.pointerActive = true
        }
        onReleased: {
            root.dragOffsetX = 0
            root.dragOffsetY = 0
        }
        onCanceled: {
            root.dragOffsetX = 0
            root.dragOffsetY = 0
        }
        onPositionChanged: function(mouse) {
            root.pointerX = mouse.x
            root.pointerY = mouse.y
            root.pointerActive = true
            if (pointerTracker.pressed && root.motionEnabled) {
                root.dragOffsetX = Math.max(-48 * root.uiScale, Math.min(48 * root.uiScale, mouse.x - root.dragStartX))
                root.dragOffsetY = Math.max(-30 * root.uiScale, Math.min(30 * root.uiScale, mouse.y - root.dragStartY))
            }
            pointerIdle.restart()
        }
        onClicked: function(mouse) {
            // Blank wallpaper clicks are intentionally inert. Interactive
            // signal nodes are later siblings and receive their own clicks.
            mouse.accepted = false
        }
        propagateComposedEvents: true
    }

    Timer {
        id: pointerIdle
        interval: 1300
        repeat: false
        onTriggered: { if (!pointerTracker.pressed) root.pointerActive = false }
    }

    // Two extremely cheap parallax planes: no blur, shader, particle system or
    // high-frequency full-screen Canvas repaint is used on the Haswell iGPU.
    Item {
        id: farGrid
        width: parent.width
        height: parent.height
        x: root.pointerDX * -5 * root.uiScale + root.dragOffsetX * 0.22
        y: root.pointerDY * -3 * root.uiScale + root.dragOffsetY * 0.22
        opacity: root.workspace === "READ" ? 0.10 : 0.16
        Behavior on x { enabled: root.motionEnabled; SmoothedAnimation { velocity: 90 } }
        Behavior on y { enabled: root.motionEnabled; SmoothedAnimation { velocity: 90 } }

        Repeater {
            model: 12
            Rectangle {
                x: (index + 1) * farGrid.width / 13
                y: 54 * root.uiScale
                width: Math.max(1, root.uiScale)
                height: farGrid.height - 108 * root.uiScale
                color: index % 3 === 0 ? "#24383d" : "#17282d"
                opacity: index % 3 === 0 ? 0.28 : 0.16
            }
        }
        Repeater {
            model: 7
            Rectangle {
                x: 100 * root.uiScale
                y: (index + 1) * farGrid.height / 8
                width: farGrid.width - 200 * root.uiScale
                height: Math.max(1, root.uiScale)
                color: "#1c3035"
                opacity: 0.14
            }
        }
    }

    Item {
        id: networkPlane
        width: parent.width
        height: parent.height
        x: root.pointerDX * 7 * root.uiScale + root.dragOffsetX
        y: root.pointerDY * 4 * root.uiScale + root.dragOffsetY
        Behavior on x { enabled: root.motionEnabled; SmoothedAnimation { velocity: 110 } }
        Behavior on y { enabled: root.motionEnabled; SmoothedAnimation { velocity: 110 } }

        Shape {
            anchors.fill: parent
            opacity: 0.19 + Math.min(0.13, root.netLevel / 220)

            ShapePath {
                strokeColor: root.workspaceAccent
                strokeWidth: Math.max(1, root.uiScale)
                fillColor: "transparent"
                startX: networkPlane.width * 0.39; startY: networkPlane.height * 0.135
                PathLine { x: networkPlane.width * 0.68; y: networkPlane.height * 0.16 }
                PathLine { x: networkPlane.width * 0.76; y: networkPlane.height * 0.35 }
            }
            ShapePath {
                strokeColor: "#5d7379"
                strokeWidth: Math.max(1, root.uiScale)
                fillColor: "transparent"
                startX: networkPlane.width * 0.39; startY: networkPlane.height * 0.135
                PathLine { x: networkPlane.width * 0.33; y: networkPlane.height * 0.70 }
                PathLine { x: networkPlane.width * 0.34; y: networkPlane.height * 0.87 }
            }
            ShapePath {
                strokeColor: root.amber
                strokeWidth: Math.max(1, root.uiScale)
                fillColor: "transparent"
                startX: networkPlane.width * 0.33; startY: networkPlane.height * 0.70
                PathLine { x: networkPlane.width * 0.64; y: networkPlane.height * 0.87 }
                PathLine { x: networkPlane.width * 0.76; y: networkPlane.height * 0.35 }
            }
        }

        // Data-flow dots run only when there is real network activity.
        RoutePulse {
            anchors.fill: parent
            fromX: 0.39; fromY: 0.135; toX: 0.68; toY: 0.16
            accent: root.cyan; running: root.networkActive; motionEnabled: root.motionEnabled
            duration: 3400; uiScale: root.uiScale
        }
        RoutePulse {
            anchors.fill: parent
            fromX: 0.68; fromY: 0.16; toX: 0.76; toY: 0.35
            accent: root.cyan; running: root.networkActive; motionEnabled: root.motionEnabled
            duration: 4100; uiScale: root.uiScale
        }
        RoutePulse {
            anchors.fill: parent
            fromX: 0.33; fromY: 0.70; toX: 0.64; toY: 0.87
            accent: root.amber; running: root.networkActive; motionEnabled: root.motionEnabled
            duration: 4700; uiScale: root.uiScale
        }

        Repeater {
            model: [
                { name: "MAIN",  x: 0.39, y: 0.135, code: "CORE // HOME" },
                { name: "DEV",   x: 0.68, y: 0.16, code: "BUILD // TERM" },
                { name: "MEDIA", x: 0.76, y: 0.35, code: "SIGNAL // AUDIO" },
                { name: "READ",  x: 0.33, y: 0.70, code: "ARCHIVE // READ" },
                { name: "MISC",  x: 0.34, y: 0.87, code: "AUX // SYSTEM" }
            ]
            delegate: SignalNode {
                required property var modelData
                width: 126 * root.uiScale
                height: 48 * root.uiScale
                x: networkPlane.width * modelData.x - 12 * root.uiScale
                y: networkPlane.height * modelData.y - 24 * root.uiScale
                label: modelData.name
                sublabel: modelData.code
                accent: modelData.name === "MEDIA" ? root.amber : root.cyan
                active: root.workspace === modelData.name
                motionEnabled: root.motionEnabled
                interactionEnabled: root.interactionEnabled
                uiScale: root.uiScale
                fontFamily: root.fontFamily
                onActivated: root.workspaceRequested(modelData.name)
            }
        }

        SignalNode {
            width: 146 * root.uiScale
            height: 48 * root.uiScale
            x: networkPlane.width * 0.64
            y: networkPlane.height * 0.87
            label: "NET"
            sublabel: root.status ? (root.status.rx + " // " + root.status.tx) : "OFFLINE"
            accent: root.cyan
            active: root.networkActive
            motionEnabled: root.motionEnabled
            interactionEnabled: root.interactionEnabled
            uiScale: root.uiScale
            fontFamily: root.fontFamily
            onActivated: root.actionRequested("network")
        }
    }

    // MEDIA becomes subtly audio-reactive. Only two small outlined rings animate
    // and only while a real MPRIS player is in Playing state.
    Item {
        id: mediaResonance
        x: root.width * 0.735
        y: root.height * 0.305
        width: 78 * root.uiScale
        height: width
        visible: root.mediaActive
        opacity: root.workspace === "MEDIA" ? 0.60 : 0.26
        property real phase: 0
        NumberAnimation on phase {
            from: 0
            to: 1
            duration: 1900
            loops: Animation.Infinite
            running: mediaResonance.visible && root.motionEnabled
        }
        Repeater {
            model: 2
            Rectangle {
                anchors.centerIn: parent
                width: (19 + (mediaResonance.phase + index * 0.32) % 1 * 48) * root.uiScale
                height: width
                radius: width / 2
                color: "transparent"
                border.width: Math.max(1, root.uiScale)
                border.color: root.amber
                opacity: 0.34 * (1 - ((mediaResonance.phase + index * 0.32) % 1))
            }
        }
    }

    // CPU and battery state affect only tiny instrument marks, never the whole
    // wallpaper, so system stress does not become a distracting light show.
    Rectangle {
        x: root.width * 0.63
        y: root.height * 0.125
        width: 22 * root.uiScale
        height: width
        radius: width / 2
        color: "transparent"
        border.width: Math.max(1, root.uiScale)
        border.color: root.cpuHot ? root.amber : root.workspaceAccent
        opacity: root.cpuHot ? 0.64 : 0.18
    }

    Text {
        visible: root.batteryWarning
        anchors.right: parent.right
        anchors.rightMargin: 266 * root.uiScale
        y: 62 * root.uiScale
        text: "PWR LOW // " + (root.status ? root.status.battery : "--") + "%"
        color: root.amber
        font.family: root.fontFamily
        font.pixelSize: 7 * root.uiScale
        font.letterSpacing: 0.65 * root.uiScale
        opacity: 0.88
    }

    // Cursor lens: a passive spatial cue, not a fake desktop cursor. It fades
    // after pointer idle and never animates when interaction mode is disabled.
    Item {
        x: root.pointerX - width / 2
        y: root.pointerY - height / 2
        width: 46 * root.uiScale
        height: width
        visible: root.interactionEnabled
        opacity: root.pointerActive ? 0.42 : 0
        Behavior on opacity { NumberAnimation { duration: 160 } }

        Rectangle {
            anchors.centerIn: parent
            width: 28 * root.uiScale
            height: width
            radius: width / 2
            color: "transparent"
            border.width: Math.max(1, root.uiScale)
            border.color: root.workspaceAccent
        }
        Rectangle { anchors.horizontalCenter: parent.horizontalCenter; y: 0; width: Math.max(1, root.uiScale); height: 12 * root.uiScale; color: root.workspaceAccent }
        Rectangle { anchors.horizontalCenter: parent.horizontalCenter; anchors.bottom: parent.bottom; width: Math.max(1, root.uiScale); height: 12 * root.uiScale; color: root.workspaceAccent }
        Rectangle { anchors.verticalCenter: parent.verticalCenter; x: 0; width: 12 * root.uiScale; height: Math.max(1, root.uiScale); color: root.workspaceAccent }
        Rectangle { anchors.verticalCenter: parent.verticalCenter; anchors.right: parent.right; width: 12 * root.uiScale; height: Math.max(1, root.uiScale); color: root.workspaceAccent }
    }

    Text {
        visible: root.interactionEnabled && pointerTracker.pressed
        x: root.pointerX + 29 * root.uiScale
        y: root.pointerY + 21 * root.uiScale
        text: "GRAB // FIELD"
        color: root.workspaceAccent
        font.family: root.fontFamily
        font.pixelSize: 6 * root.uiScale
        font.letterSpacing: 0.55 * root.uiScale
        opacity: 0.72
    }

    // Tiny state signature makes the wallpaper's behavior legible without a
    // full dashboard. MAIN/DEV/MEDIA/READ/MISC alter this label and the active
    // node while the rest of the shell stays visually coherent.
    Text {
        anchors.right: parent.right
        anchors.rightMargin: 270 * root.uiScale
        anchors.bottom: parent.bottom
        anchors.bottomMargin: 27 * root.uiScale
        text: "FIELD // " + root.workspace + "   " + (root.networkActive ? "LINK ACTIVE" : "LINK IDLE")
        color: root.dim
        font.family: root.fontFamily
        font.pixelSize: 6 * root.uiScale
        font.letterSpacing: 0.55 * root.uiScale
        opacity: 0.62
    }
}

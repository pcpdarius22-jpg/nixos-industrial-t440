import QtQuick

Item {
    id: root
    property string kind: "terminal"
    property string label: "TERMINAL"
    property bool active: false
    property real uiScale: 1
    signal clicked()

    width: parent ? parent.width : 96
    height: 82 * uiScale

    Rectangle {
        anchors.fill: parent
        color: mouse.containsMouse ? "#0b1317" : "transparent"
        border.width: 0
    }
    Rectangle {
        visible: root.active
        x: 0; y: 16 * root.uiScale; width: Math.max(2, 2 * root.uiScale); height: 50 * root.uiScale
        color: "#68999c"
    }

    Canvas {
        id: glyph
        anchors.horizontalCenter: parent.horizontalCenter
        y: 17 * root.uiScale; width: 26 * root.uiScale; height: 26 * root.uiScale
        onPaint: {
            var c = getContext("2d")
            c.clearRect(0, 0, width, height)
            c.strokeStyle = root.active ? "#d9dfe1" : "#a6b0b4"
            c.fillStyle = c.strokeStyle
            c.lineWidth = 1.4
            c.lineCap = "square"
            c.lineJoin = "miter"
            c.save(); c.scale(root.uiScale, root.uiScale)
            if (root.kind === "terminal") {
                c.beginPath(); c.moveTo(5,7); c.lineTo(10,12); c.lineTo(5,17); c.moveTo(13,18); c.lineTo(20,18); c.stroke()
            } else if (root.kind === "files") {
                c.beginPath(); c.moveTo(4,8); c.lineTo(10,8); c.lineTo(12,11); c.lineTo(22,11); c.lineTo(22,20); c.lineTo(4,20); c.closePath(); c.stroke()
            } else if (root.kind === "browser") {
                c.beginPath(); c.arc(13,13,8,0,Math.PI*2); c.moveTo(5,13); c.lineTo(21,13); c.moveTo(13,5); c.bezierCurveTo(9,8,9,18,13,21); c.moveTo(13,5); c.bezierCurveTo(17,8,17,18,13,21); c.stroke()
            } else if (root.kind === "music") {
                c.beginPath(); c.moveTo(11,7); c.lineTo(20,5); c.lineTo(20,16); c.moveTo(11,7); c.lineTo(11,18); c.stroke();
                c.beginPath(); c.arc(8,19,3,0,Math.PI*2); c.arc(17,17,3,0,Math.PI*2); c.stroke()
            } else if (root.kind === "reader") {
                c.strokeRect(5,5,16,18); c.beginPath(); c.moveTo(13,5); c.lineTo(13,23); c.moveTo(8,9); c.lineTo(11,9); c.moveTo(15,9); c.lineTo(18,9); c.stroke()
            } else {
                c.beginPath(); c.arc(13,13,5,0,Math.PI*2); c.stroke()
                for (var i=0;i<8;i++) { var a=i*Math.PI/4; c.beginPath(); c.moveTo(13+7*Math.cos(a),13+7*Math.sin(a)); c.lineTo(13+10*Math.cos(a),13+10*Math.sin(a)); c.stroke() }
                c.beginPath(); c.arc(13,13,1.5,0,Math.PI*2); c.fill()
            }
            c.restore()
        }
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        Connections { target: root; function onActiveChanged() { glyph.requestPaint() } }
    }

    Text {
        anchors.horizontalCenter: parent.horizontalCenter
        y: 48 * root.uiScale
        text: root.label
        color: root.active ? "#c8cdd0" : "#66737a"
        font.family: "JetBrains Mono"
        font.pixelSize: 8 * root.uiScale
        font.letterSpacing: 0.8 * root.uiScale
    }
    MouseArea {
        id: mouse
        anchors.fill: parent
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.clicked()
    }
}

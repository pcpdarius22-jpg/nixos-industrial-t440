import QtQuick

Item {
    id: root
    property string kind: "cpu"
    property string value: "--"
    property real level: 0
    property color foreground: "#c8cdd0"
    property color dim: "#617077"
    property color line: "#7c898e"
    property string fontFamily: "JetBrains Mono"
    property real uiScale: 1

    implicitWidth: 94 * uiScale
    implicitHeight: 36 * uiScale

    Canvas {
        id: icon
        x: 0; y: 9 * root.uiScale
        width: 16 * root.uiScale; height: 16 * root.uiScale
        onPaint: {
            var c = getContext("2d")
            c.clearRect(0, 0, width, height)
            c.strokeStyle = root.foreground
            c.fillStyle = root.foreground
            c.lineWidth = Math.max(1, root.uiScale)
            var s = root.uiScale
            if (root.kind === "battery") {
                c.strokeRect(1*s, 4*s, 12*s, 8*s)
                c.fillRect(13*s, 6*s, 2*s, 4*s)
                c.fillRect(3*s, 6*s, 7*s * Math.max(0, Math.min(1, root.level/100)), 4*s)
            } else if (root.kind === "memory") {
                c.strokeRect(2*s, 4*s, 12*s, 8*s)
                c.beginPath(); c.moveTo(5*s, 4*s); c.lineTo(5*s, 12*s); c.moveTo(11*s, 4*s); c.lineTo(11*s, 12*s); c.stroke()
                c.fillRect(4*s, 14*s, 2*s, 1*s); c.fillRect(10*s, 14*s, 2*s, 1*s)
            } else {
                c.strokeRect(5*s, 5*s, 6*s, 6*s)
                for (var i=0; i<3; ++i) {
                    var p=(4+i*4)*s
                    c.beginPath(); c.moveTo(p, 1*s); c.lineTo(p, 4*s); c.moveTo(p, 12*s); c.lineTo(p, 15*s); c.moveTo(1*s, p); c.lineTo(4*s, p); c.moveTo(12*s, p); c.lineTo(15*s, p); c.stroke()
                }
            }
        }
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()
        Connections { target: root; function onLevelChanged() { icon.requestPaint() } }
    }

    Text {
        x: 24 * root.uiScale
        anchors.verticalCenter: parent.verticalCenter
        anchors.verticalCenterOffset: -2 * root.uiScale
        text: root.value
        color: root.foreground
        font.family: root.fontFamily
        font.pixelSize: 8 * root.uiScale
        font.letterSpacing: 0.5 * root.uiScale
    }
    Rectangle {
        x: 24 * root.uiScale; y: 26 * root.uiScale
        width: 43 * root.uiScale; height: 1
        color: root.dim
        Rectangle {
            width: parent.width * Math.max(0.08, Math.min(1, root.level / 100))
            height: 1
            color: root.line
        }
    }
}

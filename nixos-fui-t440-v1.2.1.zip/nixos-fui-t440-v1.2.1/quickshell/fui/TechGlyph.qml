import QtQuick

Canvas {
    id: root
    property string kind: "node"
    property color stroke: "#5f6c72"
    property real lineWidth: 1
    implicitWidth: 10
    implicitHeight: 10

    onKindChanged: requestPaint()
    onStrokeChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        var c = getContext("2d")
        c.clearRect(0, 0, width, height)
        c.strokeStyle = root.stroke
        c.fillStyle = root.stroke
        c.lineWidth = root.lineWidth
        c.lineCap = "square"
        c.lineJoin = "miter"
        var w = width, h = height
        var x0 = w * 0.14, x1 = w * 0.86, y0 = h * 0.14, y1 = h * 0.86

        function box(ax, ay, bx, by) { c.strokeRect(ax, ay, bx-ax, by-ay) }
        function line(ax, ay, bx, by) { c.beginPath(); c.moveTo(ax, ay); c.lineTo(bx, by); c.stroke() }

        if (kind === "laptop") {
            box(x0, y0, x1, h*0.68); line(w*0.06, h*0.82, w*0.94, h*0.82); line(w*0.25,h*0.68,w*0.18,h*0.82); line(w*0.75,h*0.68,w*0.82,h*0.82)
        } else if (kind === "cpu") {
            box(w*0.26,h*0.26,w*0.74,h*0.74); box(w*0.38,h*0.38,w*0.62,h*0.62)
            for (var i=0;i<3;i++) { var p=h*(0.30+i*0.20); line(w*0.10,p,w*0.26,p); line(w*0.74,p,w*0.90,p); line(p,h*0.10,p,h*0.26); line(p,h*0.74,p,h*0.90) }
        } else if (kind === "gpu") {
            box(w*0.10,h*0.23,w*0.90,h*0.77); c.beginPath(); c.arc(w*0.42,h*0.50,w*0.16,0,Math.PI*2); c.stroke(); line(w*0.66,h*0.38,w*0.82,h*0.38); line(w*0.66,h*0.52,w*0.82,h*0.52); line(w*0.66,h*0.66,w*0.82,h*0.66)
        } else if (kind === "memory") {
            box(w*0.12,h*0.28,w*0.88,h*0.72); for (var j=0;j<4;j++) box(w*(0.20+j*0.16),h*0.38,w*(0.29+j*0.16),h*0.61); for (var k=0;k<5;k++) line(w*(0.20+k*0.14),h*0.72,w*(0.20+k*0.14),h*0.86)
        } else if (kind === "disk") {
            box(w*0.18,h*0.12,w*0.82,h*0.88); c.beginPath(); c.arc(w*0.50,h*0.46,w*0.20,0,Math.PI*2); c.stroke(); c.beginPath(); c.arc(w*0.50,h*0.46,w*0.05,0,Math.PI*2); c.stroke(); line(w*0.50,h*0.46,w*0.70,h*0.66)
        } else if (kind === "network") {
            c.beginPath(); c.arc(w*0.50,h*0.74,w*0.05,0,Math.PI*2); c.fill(); c.beginPath(); c.arc(w*0.50,h*0.72,w*0.22,Math.PI*1.15,Math.PI*1.85); c.stroke(); c.beginPath(); c.arc(w*0.50,h*0.72,w*0.38,Math.PI*1.15,Math.PI*1.85); c.stroke()
        } else if (kind === "link") {
            c.beginPath(); c.arc(w*0.34,h*0.50,w*0.20,0,Math.PI*2); c.stroke(); c.beginPath(); c.arc(w*0.66,h*0.50,w*0.20,0,Math.PI*2); c.stroke(); line(w*0.42,h*0.50,w*0.58,h*0.50)
        } else if (kind === "battery") {
            box(w*0.16,h*0.20,w*0.78,h*0.80); box(w*0.78,h*0.39,w*0.90,h*0.61); line(w*0.28,h*0.50,w*0.66,h*0.50)
        } else {
            c.beginPath(); c.arc(w*0.50,h*0.50,w*0.30,0,Math.PI*2); c.stroke(); c.beginPath(); c.arc(w*0.50,h*0.50,w*0.06,0,Math.PI*2); c.fill()
        }
    }
}

import QtQuick

Canvas {
    id: root
    property var values: []
    property color lineColor: "#6a989c"
    property color gridColor: "#172328"

    onValuesChanged: requestPaint()
    onWidthChanged: requestPaint()
    onHeightChanged: requestPaint()

    onPaint: {
        var ctx = getContext("2d")
        ctx.clearRect(0, 0, width, height)
        ctx.strokeStyle = gridColor
        ctx.lineWidth = 1
        for (var gy = 0; gy <= 2; ++gy) {
            var yy = Math.round(gy * height / 2) + 0.5
            ctx.beginPath(); ctx.moveTo(0, yy); ctx.lineTo(width, yy); ctx.stroke()
        }
        if (!values || values.length < 2) return
        ctx.strokeStyle = lineColor
        ctx.lineWidth = 1
        ctx.beginPath()
        for (var i = 0; i < values.length; ++i) {
            var x = i * width / Math.max(1, values.length - 1)
            var v = Math.max(0, Math.min(100, Number(values[i])))
            var y = height - (v / 100) * height
            if (i === 0) ctx.moveTo(x, y)
            else ctx.lineTo(x, y)
        }
        ctx.stroke()
    }
}

import QtQuick
import Quickshell

Rectangle {
    id: root
    property var status
    property string fontFamily: "JetBrains Mono"
    property color fg: "#9ba7ac"
    property color dim: "#4f5d63"
    property color cyan: "#60979b"
    property color amber: "#c98d42"
    property real uiScale: 1

    color: "#050a0c"
    border.width: 1
    border.color: "#26343a"

    Text {
        x: 12 * root.uiScale; y: 10 * root.uiScale
        text: "CITY FEED — SATELLITE VIEW"
        color: root.dim
        font.family: root.fontFamily
        font.pixelSize: 8 * root.uiScale
        font.letterSpacing: 0.7 * root.uiScale
    }
    Text {
        anchors.right: parent.right; anchors.rightMargin: 12 * root.uiScale; y: 10 * root.uiScale
        text: "> LIVE"
        color: root.cyan
        font.family: root.fontFamily
        font.pixelSize: 8 * root.uiScale
    }
    Rectangle { x: 0; y: 30 * root.uiScale; width: parent.width; height: Math.max(1, root.uiScale); color: "#26343a" }

    // The central city texture is cut directly from the approved 1600×900
    // concept, while the surrounding controls/status remain live QML.
    Rectangle {
        x: 52 * root.uiScale; y: 31 * root.uiScale
        width: parent.width - 53 * root.uiScale
        height: parent.height - 64 * root.uiScale
        color: "#05090b"
        clip: true
        Image {
            anchors.fill: parent
            source: Qt.resolvedUrl("assets/city-feed-reference.png")
            fillMode: Image.PreserveAspectCrop
            smooth: true
        }
        Rectangle { anchors.fill: parent; color: "#1505090b" }
    }

    // Compact tool rail from the reference. Icons are deliberately symbolic
    // so no icon-theme package is required.
    Rectangle {
        x: 0; y: 31 * root.uiScale; width: 52 * root.uiScale; height: parent.height - 64 * root.uiScale
        color: "#060b0e"
        border.width: 0
        Column {
            anchors.horizontalCenter: parent.horizontalCenter
            y: 10 * root.uiScale
            spacing: 17 * root.uiScale
            Repeater {
                model: ["⌖", "◎", "▣", "◈", "↻", "+", "−"]
                Rectangle {
                    width: 28 * root.uiScale; height: 28 * root.uiScale
                    color: toolMouse.containsMouse ? "#10191d" : "transparent"
                    border.width: index === 0 ? 1 : 0
                    border.color: root.dim
                    Text { anchors.centerIn: parent; text: modelData; color: index === 0 ? root.fg : root.dim; font.family: root.fontFamily; font.pixelSize: 10 * root.uiScale }
                    MouseArea { id: toolMouse; anchors.fill: parent; hoverEnabled: true; onClicked: Quickshell.execDetached(["fui-network"]) }
                }
            }
        }
    }

    // Node labels and route annotations are already part of the approved crop.

    Rectangle { x: 0; anchors.bottom: parent.bottom; width: parent.width; height: 33 * root.uiScale; color: "#060b0e"; border.width: 0 }
    Rectangle { x: 0; anchors.bottom: parent.bottom; anchors.bottomMargin: 32 * root.uiScale; width: parent.width; height: Math.max(1, root.uiScale); color: "#26343a" }
    Row {
        x: 12 * root.uiScale; anchors.bottom: parent.bottom; anchors.bottomMargin: 10 * root.uiScale; spacing: 30 * root.uiScale
        Text { text: "LAT  LOCAL"; color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.uiScale }
        Text { text: "IF  " + (root.status ? root.status.iface : "offline"); color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.uiScale }
        Text { text: "IP  " + (root.status ? root.status.ip : "offline"); color: root.dim; font.family: root.fontFamily; font.pixelSize: 7 * root.uiScale }
        Text { text: "RX  " + (root.status ? root.status.rx : "0K/s"); color: root.cyan; font.family: root.fontFamily; font.pixelSize: 7 * root.uiScale }
    }

    MouseArea {
        x: 52 * root.uiScale; y: 31 * root.uiScale; width: parent.width - 53 * root.uiScale; height: parent.height - 64 * root.uiScale
        onDoubleClicked: Quickshell.execDetached(["fui-network"])
    }
}

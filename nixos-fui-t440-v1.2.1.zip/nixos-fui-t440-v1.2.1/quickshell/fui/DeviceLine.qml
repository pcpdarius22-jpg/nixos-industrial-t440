import QtQuick

Item {
    id: root
    property string kind: "node"
    property string text: ""
    property color color: "#5f6c72"
    property string fontFamily: "JetBrains Mono"
    property real scaleFactor: 1

    implicitHeight: 10 * scaleFactor

    TechGlyph {
        x: 0
        y: 1 * root.scaleFactor
        width: 9 * root.scaleFactor
        height: 9 * root.scaleFactor
        kind: root.kind
        stroke: root.color
        lineWidth: Math.max(0.8, root.scaleFactor)
    }
    Text {
        x: 15 * root.scaleFactor
        y: 0
        width: parent.width - x
        elide: Text.ElideRight
        text: root.text
        color: root.color
        font.family: root.fontFamily
        font.pixelSize: 7 * root.scaleFactor
    }
}

import QtQuick

Rectangle {
    id: root
    property string title: "PANEL"
    property color panelColor: "#070c0f"
    property color borderColor: "#27343a"
    property color foreground: "#c8cdd0"
    property color dim: "#66737a"
    property string fontFamily: "JetBrains Mono"
    property bool showHeader: true
    property real uiScale: 1

    color: panelColor
    border.width: 1
    border.color: borderColor
    radius: 0

    Rectangle {
        visible: root.showHeader
        x: 0; y: 0
        width: parent.width
        height: 28 * root.uiScale
        color: "#080e11"
        border.width: 0
        Text {
            anchors.left: parent.left
            anchors.leftMargin: 11 * root.uiScale
            anchors.verticalCenter: parent.verticalCenter
            text: root.title
            color: root.dim
            font.family: root.fontFamily
            font.pixelSize: 9 * root.uiScale
            font.letterSpacing: 0.8 * root.uiScale
        }
        Text {
            anchors.right: parent.right
            anchors.rightMargin: 10 * root.uiScale
            anchors.verticalCenter: parent.verticalCenter
            text: "—  □  ×"
            color: "#526067"
            font.family: root.fontFamily
            font.pixelSize: 9 * root.uiScale
        }
        Rectangle { anchors.left: parent.left; anchors.right: parent.right; anchors.bottom: parent.bottom; height: Math.max(1, root.uiScale); color: root.borderColor }
    }
}

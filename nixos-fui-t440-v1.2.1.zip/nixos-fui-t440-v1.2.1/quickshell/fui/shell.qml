//@ pragma ShellId personal-fui
//@ pragma DropExpensiveFonts
import QtQuick
import Quickshell
import Quickshell.Io

ShellRoot {
    id: root
    property bool launcherOpen: false
    property bool wallpaperMotionEnabled: true
    property bool wallpaperInteractionEnabled: true
    signal launcherRequested(string initialText)

    function requestLauncher(initialText) {
        root.launcherOpen = true
        root.launcherRequested(initialText)
    }

    StatusModel { id: status }

    IpcHandler {
        target: "shell"
        function ping(): string { return "ok" }
        function toggleLauncher(): void {
            if (root.launcherOpen) root.launcherOpen = false
            else root.requestLauncher("find")
        }
        function openLauncher(): void { root.requestLauncher("find") }
        function openCommand(): void { root.requestLauncher(">") }
        function closeLauncher(): void { root.launcherOpen = false }
        function toggleWallpaperMotion(): string {
            root.wallpaperMotionEnabled = !root.wallpaperMotionEnabled
            return root.wallpaperMotionEnabled ? "motion:on" : "motion:off"
        }
        function toggleWallpaperInteraction(): string {
            root.wallpaperInteractionEnabled = !root.wallpaperInteractionEnabled
            return root.wallpaperInteractionEnabled ? "interaction:on" : "interaction:off"
        }
        function wallpaperStatus(): string {
            return (root.wallpaperMotionEnabled ? "motion:on" : "motion:off") + ","
                + (root.wallpaperInteractionEnabled ? "interaction:on" : "interaction:off")
        }
    }

    Variants {
        model: Quickshell.screens
        delegate: Component {
            DesktopSurface {
                required property var modelData
                screen: modelData
                status: status
                controller: root
            }
        }
    }
}

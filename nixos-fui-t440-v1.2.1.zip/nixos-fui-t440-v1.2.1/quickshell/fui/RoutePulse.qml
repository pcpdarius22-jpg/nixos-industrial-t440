import QtQuick

Item {
    id: root

    // End points are normalized to the parent (0..1), so the route remains
    // correct when the shell scales away from the 1600x900 reference canvas.
    property real fromX: 0
    property real fromY: 0
    property real toX: 1
    property real toY: 1
    property color accent: "#66979a"
    property bool running: false
    property bool motionEnabled: true
    property int duration: 3300
    property real uiScale: 1
    property real phase: 0

    NumberAnimation on phase {
        from: 0
        to: 1
        duration: root.duration
        loops: Animation.Infinite
        running: root.running && root.motionEnabled
    }
    onRunningChanged: {
        if (!root.running) root.phase = 0
    }

    Rectangle {
        visible: root.running && root.motionEnabled
        x: root.width * (root.fromX + (root.toX - root.fromX) * root.phase) - width / 2
        y: root.height * (root.fromY + (root.toY - root.fromY) * root.phase) - height / 2
        width: 3 * root.uiScale
        height: width
        radius: width / 2
        color: root.accent
        opacity: 0.8
    }

    Rectangle {
        visible: root.running && root.motionEnabled && root.phase > 0.025
        x: root.width * (root.fromX + (root.toX - root.fromX) * Math.max(0, root.phase - 0.025)) - width / 2
        y: root.height * (root.fromY + (root.toY - root.fromY) * Math.max(0, root.phase - 0.025)) - height / 2
        width: 2 * root.uiScale
        height: width
        radius: width / 2
        color: root.accent
        opacity: 0.28
    }
}

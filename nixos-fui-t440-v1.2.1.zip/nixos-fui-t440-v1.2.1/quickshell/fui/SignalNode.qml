import QtQuick

Item {
    id: root

    property string label: "NODE"
    property string sublabel: ""
    property color accent: "#66979a"
    property color foreground: "#bfc7ca"
    property color dim: "#59686e"
    property string fontFamily: "JetBrains Mono"
    property bool active: false
    property bool motionEnabled: true
    property bool interactionEnabled: true
    property real uiScale: 1
    signal activated()

    implicitWidth: 126 * root.uiScale
    implicitHeight: 48 * root.uiScale

    property real pulsePhase: 0
    NumberAnimation on pulsePhase {
        from: 0
        to: 1
        duration: 2400
        loops: Animation.Infinite
        running: root.active && root.motionEnabled
    }
    onActiveChanged: {
        if (!root.active) root.pulsePhase = 0
    }

    // Fine leader line keeps the label tied to a physical-looking node.
    Rectangle {
        x: 9 * root.uiScale
        y: 23 * root.uiScale
        width: 23 * root.uiScale
        height: Math.max(1, root.uiScale)
        color: nodeMouse.containsMouse || root.active ? root.accent : "#314147"
        opacity: nodeMouse.containsMouse ? 0.9 : 0.55
    }

    Rectangle {
        id: pulseRing
        x: (4 - 5 * root.pulsePhase) * root.uiScale
        y: (18 - 5 * root.pulsePhase) * root.uiScale
        width: (12 + 10 * root.pulsePhase) * root.uiScale
        height: width
        radius: width / 2
        color: "transparent"
        border.width: Math.max(1, root.uiScale)
        border.color: root.accent
        opacity: root.active && root.motionEnabled ? (0.35 * (1 - root.pulsePhase)) : 0
    }

    Rectangle {
        x: 7 * root.uiScale
        y: 21 * root.uiScale
        width: 6 * root.uiScale
        height: width
        radius: width / 2
        color: nodeMouse.containsMouse || root.active ? root.accent : "#657277"
        opacity: nodeMouse.containsMouse || root.active ? 0.95 : 0.55
        border.width: root.active ? Math.max(1, root.uiScale) : 0
        border.color: root.foreground
    }

    Text {
        x: 36 * root.uiScale
        y: 9 * root.uiScale
        width: root.width - x
        text: root.label
        color: nodeMouse.containsMouse || root.active ? root.foreground : root.dim
        font.family: root.fontFamily
        font.pixelSize: 7 * root.uiScale
        font.letterSpacing: 0.55 * root.uiScale
        elide: Text.ElideRight
        opacity: nodeMouse.containsMouse || root.active ? 0.9 : 0.48
    }

    Text {
        x: 36 * root.uiScale
        y: 25 * root.uiScale
        width: root.width - x
        text: root.sublabel
        color: root.accent
        font.family: root.fontFamily
        font.pixelSize: 6 * root.uiScale
        font.letterSpacing: 0.35 * root.uiScale
        elide: Text.ElideRight
        opacity: nodeMouse.containsMouse ? 0.9 : (root.active ? 0.62 : 0.28)
    }

    MouseArea {
        id: nodeMouse
        anchors.fill: parent
        enabled: root.interactionEnabled
        hoverEnabled: true
        cursorShape: Qt.PointingHandCursor
        onClicked: root.activated()
    }
}

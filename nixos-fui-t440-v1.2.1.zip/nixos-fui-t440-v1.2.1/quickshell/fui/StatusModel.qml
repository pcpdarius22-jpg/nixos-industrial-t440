import QtQuick
import Quickshell
import Quickshell.Io

Scope {
    id: root

    property real cpu: 0
    property string memUsed: "0G"
    property string memTotal: "0G"
    property real memPct: 0
    property string swapUsed: "0G"
    property string swapTotal: "0G"
    property real swapPct: 0
    property string diskUsed: "0G"
    property string diskTotal: "0G"
    property real diskPct: 0
    property string temp: "--"
    property int battery: -1
    property string batteryStatus: ""
    property string iface: "offline"
    property string ip: "offline"
    property string rx: "0K/s"
    property string tx: "0K/s"
    property string workspace: "MAIN"
    property var workspaces: ["MAIN", "DEV", "MEDIA", "READ", "MISC"]
    property string model: "ThinkPad"
    property string cpuModel: "CPU"
    property string gpuModel: "Graphics"
    property string netModel: "Network adapter"
    property string diskModel: "System disk"
    property string kernel: ""
    property string timeText: "--:--"
    property string seconds: "--"
    property string dateText: ""
    property bool playing: false
    property string track: "NO ACTIVE SIGNAL"
    property string artist: ""
    property string position: ""
    property string length: ""
    property real playerProgress: 0
    property var cpuHistory: [0, 0, 0, 0, 0, 0, 0, 0]
    property var netHistory: [0, 0, 0, 0, 0, 0, 0, 0]

    Process {
        id: statusProc
        command: ["fui-status"]
        running: true
        onRunningChanged: {
            if (!running) restartTimer.restart()
        }
        stdout: SplitParser {
            onRead: function(line) {
                try {
                    var o = JSON.parse(line)
                    root.cpu = Number(o.cpu || 0)
                    root.memUsed = o.mem_used || "0G"
                    root.memTotal = o.mem_total || "0G"
                    root.memPct = Number(o.mem_pct || 0)
                    root.swapUsed = o.swap_used || "0G"
                    root.swapTotal = o.swap_total || "0G"
                    root.swapPct = Number(o.swap_pct || 0)
                    root.diskUsed = o.disk_used || "0G"
                    root.diskTotal = o.disk_total || "0G"
                    root.diskPct = Number(o.disk_pct || 0)
                    root.temp = o.temp === null || o.temp === undefined ? "--" : Number(o.temp).toFixed(0)
                    root.battery = o.battery === null || o.battery === undefined ? -1 : Number(o.battery)
                    root.batteryStatus = o.battery_status || ""
                    root.iface = o.iface || "offline"
                    root.ip = o.ip || "offline"
                    root.rx = o.rx || "0K/s"
                    root.tx = o.tx || "0K/s"
                    root.workspace = o.workspace || "MAIN"
                    if (o.workspaces && o.workspaces.length) root.workspaces = o.workspaces
                    root.model = o.model || "ThinkPad"
                    root.cpuModel = o.cpu_model || "CPU"
                    root.gpuModel = o.gpu_model || "Graphics"
                    root.netModel = o.net_model || "Network adapter"
                    root.diskModel = o.disk_model || "System disk"
                    root.kernel = o.kernel || ""
                    root.timeText = o.time || "--:--"
                    root.seconds = o.seconds || "--"
                    root.dateText = o.date || ""
                    if (o.player) {
                        root.playing = !!o.player.playing
                        root.track = o.player.title || "NO ACTIVE SIGNAL"
                        root.artist = o.player.artist || ""
                        root.position = o.player.position || ""
                        root.length = o.player.length || ""
                        root.playerProgress = Number(o.player.progress || 0)
                    } else {
                        root.playerProgress = 0
                    }
                    root.cpuHistory = root.cpuHistory.concat([root.cpu]).slice(-40)
                    function rateLevel(text) {
                        var value = String(text || "0")
                        var m = value.match(/([0-9.]+)/)
                        if (!m) return 0
                        var multiplier = value.indexOf("G") >= 0 ? 100
                            : (value.indexOf("M") >= 0 ? 8 : 0.08)
                        return Math.min(100, Number(m[1]) * multiplier)
                    }
                    var netValue = Math.max(rateLevel(root.rx), rateLevel(root.tx))
                    root.netHistory = root.netHistory.concat([netValue]).slice(-40)
                } catch (e) {
                    console.warn("fui-status parse error:", e)
                }
            }
        }
    }

    Timer {
        id: restartTimer
        interval: 1500
        repeat: false
        onTriggered: statusProc.running = true
    }
}

import QtQuick

Item {
    id: root
    property string label: "CPU"
    property string value: "0%"
    property real level: 0
    property color accent: "#698f96"
    property color foreground: "#b9c1c5"
    property color dim: "#58646a"
    property string fontFamily: "JetBrains Mono"
    property real uiScale: 1

    implicitHeight: 18 * uiScale

    Text {
        x: 0
        anchors.verticalCenter: parent.verticalCenter
        text: root.label
        color: root.dim
        font.family: root.fontFamily
        font.pixelSize: 9 * root.uiScale
        font.letterSpacing: 0.6 * root.uiScale
    }
    Text {
        x: Math.max(68 * root.uiScale, parent.width - 118 * root.uiScale)
        width: 64 * root.uiScale
        anchors.verticalCenter: parent.verticalCenter
        horizontalAlignment: Text.AlignRight
        text: root.value
        elide: Text.ElideLeft
        color: root.foreground
        font.family: root.fontFamily
        font.pixelSize: 8 * root.uiScale
    }
    Canvas {
        id: spark
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        width: 50 * root.uiScale; height: 12 * root.uiScale
        onPaint: {
            var c=getContext("2d"); c.clearRect(0,0,width,height)
            c.strokeStyle="#1a262b"; c.lineWidth=Math.max(1, root.uiScale)
            c.beginPath(); c.moveTo(0,height-2*root.uiScale); c.lineTo(width,height-2*root.uiScale); c.stroke()
            c.strokeStyle=root.accent; c.beginPath()
            var v=Math.max(0,Math.min(100,Number(root.level)))
            for(var i=0;i<8;i++){
                var x=i*width/7
                var wave=((i*17 + Math.round(v)) % 23)/23
                var y=height-2*root.uiScale-(2*root.uiScale+wave*(2*root.uiScale+v/18*root.uiScale))
                if(i===0)c.moveTo(x,y); else c.lineTo(x,y)
            }
            c.stroke()
        }
        Connections { target: root; function onLevelChanged() { spark.requestPaint() } }
    }
}

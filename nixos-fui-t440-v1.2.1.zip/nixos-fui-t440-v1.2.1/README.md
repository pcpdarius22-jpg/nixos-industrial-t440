# FUI / ThinkPad T440 — v1.2.1 interactive-field build

A ground-up personal desktop environment built around the approved **1600×900**
reference in `docs/reference-1600x900.png`. Niri is the compositor, Quickshell
draws the persistent operating surfaces, and real applications occupy the
functional frames. It is intentionally not a Linux-desktop skin.

## What the reference becomes in the real desktop

- Exact 1600×900 reference canvas at logical scale 1 on the internal panel.
- 36px top strip, 98px left command rail, right telemetry/device rail, central
  city/signal surface and the bottom command surface at the reference coordinates.
- Five named workspaces: `MAIN`, `DEV`, `MEDIA`, `READ`, `MISC`.
- Real CPU/RAM/swap/disk/temperature/battery/network/MPRIS telemetry from one
  tolerant status process.
- Real Foot terminal and Neovim notes windows fitted into the two drawn home
  frames; Niri rules prevent terminal cell-grid snapping from moving the target.
- Launcher/search with keyboard and mouse control, installed-app search,
  `>` command mode and an independent Fuzzel fallback.
- Custom-drawn persistent shell glyphs where icon-theme differences would alter
  the reference look.
- qutebrowser with Firefox fallback, Yazi, Neovim, Zathura/Foliate, MPV and
  system/network/Bluetooth/audio utilities.
- **Ardour 9 is a guaranteed dependency**; REAPER is included when available in
  the pinned package set.
- Niri's supported X11 compatibility path through `xwayland-satellite`; no
  manual `DISPLAY`, no temporary Mesa stack and no temporary compositor.

The launcher now starts **closed** for normal daily use. Press `Super+D` to open
it and reproduce the command-surface state shown in the reference image.


## Reactive / interactive wallpaper field

The static 1600×900 wallpaper is still the exact underlying visual base, but
the background now has a lightweight Quickshell interaction layer designed
for the T440 rather than a video wallpaper or shader effect.

- Pointer movement shifts only the faint grid/network planes by a few pixels,
  creating depth without moving the base image or the application surfaces.
- Dragging on **empty wallpaper** temporarily grabs the network field and moves
  it like a spatial/holographic plane; releasing it eases it back into place.
- MAIN/DEV/MEDIA/READ/MISC exist as subtle signal nodes. Hover reveals their
  labels; clicking a node focuses the real Niri workspace.
- Real network traffic moves small route pulses. No traffic means no route
  animation.
- Real MPRIS playback enables a restrained MEDIA resonance animation.
- CPU load above 75% and battery <=15% while discharging change tiny instrument
  markers instead of flashing the whole screen.
- The interaction layer uses Qt Quick Shapes and small Rectangle animations; it
  deliberately contains no blur, shader effect, particle system, video loop or
  continuously repainted full-screen Canvas.

`Super+Shift+W` toggles wallpaper motion instantly. The Settings menu also has
`WALLPAPER / MOTION` and `WALLPAPER / INTERACTION` controls. Interaction is
enabled by default and applies only to exposed/empty wallpaper; normal app
windows remain above the background layer.

## Deterministic fonts and scaling

The generation installs JetBrains Mono, Noto and Noto Color Emoji itself. It
also declares explicit Fontconfig defaults for monospace, sans, serif and emoji;
it does not depend on fonts already present in `$HOME`.

Before Niri starts, `fui-preflight` verifies that the requested font families
resolve to the expected real families. The live runtime gate repeats font checks
inside the graphical generation.

The Quickshell layout uses **1600×900 as the design coordinate system**. On the
actual T440 target it is 1:1. Components also inherit the output-derived scale
factor so an external display does not leave fixed-size labels/icons inside a
scaled shell.

GTK and cursor fallbacks are deterministic (`Adwaita:dark`, Adwaita cursor,
20px cursor) without adding a fragile third-party theme engine.

## Guarded test install

Run as your normal user from the extracted directory:

```sh
bash install.sh
```

The distributed `host-base/` contains no machine configuration. A tracked
`host-base-placeholder.nix` produces a clear instruction if somebody evaluates
the full NixOS system before installation. `install.sh` then replaces the empty
host-base directory with a self-contained copy of your real `/etc/nixos` before
the complete system is evaluated. This keeps real host configuration ignored by
Git and means the project never guesses your bootloader, hardware, user,
networking, power or audio configuration.

The installer then:

1. locks the exact pinned flake input;
2. verifies the package source manifest and runs static regression checks;
3. builds a check using the exact pinned Niri/Foot binaries;
4. evaluates the full NixOS system;
5. activates **`nixos-rebuild test` only**;
6. runs the installed font/dependency/panel preflight.

It never calls `nixos-rebuild switch`.

After the test generation activates, switch to a spare TTY and run:

```sh
fui-session
```

`fui-session` runs the TTY preflight again. Once Niri starts, a guarded
`fui-bootstrap` checks the **live Niri output** and requires the internal target
to be 1600×900 logical pixels at scale 1. It then starts Quickshell and waits for
its IPC endpoint before starting the rest of the desktop.

If that live gate fails, Niri is deliberately left running and a simple Foot
diagnostic appears instead of a half-loaded shell. `Super+T`, `Super+Alt+D` and
`Super+Shift+E` remain compositor-owned recovery controls.

On a ThinkPad whose function row is in media-key mode, switching TTYs may require
`Ctrl+Alt+Fn+F2` rather than `Ctrl+Alt+F2`.

## Controls

- `Super+D` — toggle FUI launcher
- `Super+R` — launcher directly in `>` command mode
- `Super+Alt+D` — independent Fuzzel fallback
- `Super+Shift+D` — restart only Quickshell
- `Super+T` / `Super+Enter` — terminal
- `Super+E` — files
- `Super+B` — browser
- `Super+M` — music workstation
- `Super+N` — notes
- `Super+Left` / `Super+Right` — previous / next workspace
- `Super+1..5` — MAIN / DEV / MEDIA / READ / MISC
- `Super+Ctrl+1..5` — move current column to workspace
- `Super+Q` — close window
- `Super+L` — lock
- `Super+Shift+P` — power menu
- `Super+Shift+Q` — normal logout
- `Super+Shift+W` — toggle reactive wallpaper motion
- `Super+Shift+E` — compositor-owned emergency exit

Inside the launcher, `Left`/`Right` select, `Tab` advances, `Enter` executes and
`Escape` closes. Type an application name for real desktop-entry results. Start
a line with `>` to run a shell command.

## Permanent application is additionally gated

A successful graphical bootstrap writes the exact active system generation to:

```text
~/.local/state/fui/runtime-ok
```

`scripts/apply` refuses to switch permanently unless that marker matches the
**currently active test generation**. Rebooting back to the previous generation
therefore invalidates the apply path automatically.

Only after `docs/TEST-CHECKLIST.md` passes:

```sh
bash scripts/apply
```

You still have to type `APPLY` exactly.

## Performance / interaction changes in v1.2.1

- The local IP address is refreshed every 10 seconds (and on interface changes)
  rather than spawning `ip` every telemetry tick.
- CPU/network counters remain one-second live data.
- There is no blur, compositor shadow, video wallpaper, shader or particle system.
- The only always-eligible wallpaper animation is one tiny active-workspace ring; network/media pulses run only when their real data source is active.
- Missing optional sensors/services degrade to empty/warning values rather than
  killing the shell.

## Optional home-screen switch

To keep the FUI shell but suppress the staged terminal + notes windows:

```sh
mkdir -p ~/.config/fui
touch ~/.config/fui/no-home-windows
```

Remove that file to restore them.

Diagnostics:

```sh
bash scripts/doctor
```

## Project map

- `flake.nix` — pinned NixOS input
- `modules/fui.nix` — NixOS overlay, packages, fonts and runtime wrappers
- `niri/config.kdl` — output, workspaces, binds and exact window rules
- `quickshell/fui/` — custom operating surfaces
- `config/` — Foot/Fuzzel/Mako/Swaylock/qutebrowser/Neovim settings
- `scripts/runtime/fui-preflight.sh` — TTY dependency/font/panel gate
- `scripts/runtime/fui-runtime-check.sh` — live Niri output/font/service gate
- `scripts/runtime/fui-bootstrap.sh` — guarded graphical startup
- `scripts/fui-status.py` — single live telemetry stream
- `SOURCE-MANIFEST.sha256` — package-owned file integrity manifest
- `docs/reference-1600x900.png` — approved visual target
- `docs/BUILD-VERIFICATION.md` — verified boundary and hardware-only checks

# Validation checklist

## Automated before test activation

`bash scripts/check` checks:

- bash syntax for every shipped script
- real generated hardware config is present
- required assets/configs exist
- `nix flake check --no-build`
- complete NixOS toplevel evaluation
- Niri KDL validation when Niri is available

`bash scripts/test` then:

- builds/activates the exact NixOS generation with `nixos-rebuild test`
- validates Niri against the Niri package from that generation

## Physical T440 checks after launching Niri

Run:

```bash
bash scripts/doctor
```

Then manually verify:

- keyboard and touchpad tap-to-click
- brightness keys
- volume/mute keys
- Wi-Fi reconnect
- Bluetooth controller and headphones
- suspend and resume
- screen lock
- qutebrowser + file picker
- Firefox fallback launch
- USB flash drive automount + unmount
- YouTube hardware video decode (`vainfo` + practical playback)
- Ardour/Reaper playback
- `industrial-wineasio-register` in the exact 64-bit Wine prefix if WineASIO is needed
- `yabridgectl status` if Windows plugins are used
- external audio interface if used
- XWayland/Wine application
- Super+Shift+E returns to tty1
- reboot starts Niri and another TTY remains reachable

Only after those checks should `scripts/apply` be used.

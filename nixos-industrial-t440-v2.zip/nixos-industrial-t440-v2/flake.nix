{
  description = "Industrial NixOS + Niri desktop for the ThinkPad T440";

  inputs = {
    # Stay on the stable generation already used by the machine.
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-26.05";
  };

  outputs = { self, nixpkgs, ... }: {
    nixosConfigurations.t440 = nixpkgs.lib.nixosSystem {
      system = "x86_64-linux";
      specialArgs = {
        industrialSource = self;
      };
      modules = [
        ./hosts/t440/configuration.nix
      ];
    };
  };
}

set -euo pipefail

state_dir="${XDG_STATE_HOME:-$HOME/.local/state}/industrial"
mode_file="$state_dir/theme-mode"
config_dir="${XDG_CONFIG_HOME:-$HOME/.config}/industrial"
hours_file="$config_dir/theme-hours"
repo_file="$config_dir/repo-path"

if [[ -n "${INDUSTRIAL_REPO:-}" ]]; then
  repo="$INDUSTRIAL_REPO"
elif [[ -r "$repo_file" ]]; then
  repo="$(cat "$repo_file")"
else
  repo="$HOME/nixos-industrial-t440"
fi

mkdir -p "$state_dir" "$config_dir"
[ -f "$mode_file" ] || printf '%s\n' auto > "$mode_file"

resolve_mode() {
  local mode start end hour
  mode="$(cat "$mode_file" 2>/dev/null || printf auto)"

  case "$mode" in
    day|night)
      printf '%s\n' "$mode"
      return
      ;;
  esac

  start=7
  end=19
  if [ -r "$hours_file" ]; then
    # Optional format: DAY_START=7 and NIGHT_START=19.
    # shellcheck disable=SC1090
    . "$hours_file"
    start="${DAY_START:-7}"
    end="${NIGHT_START:-19}"
  fi

  hour="$(date +%H)"
  hour="$((10#$hour))"
  if [ "$hour" -ge "$start" ] && [ "$hour" -lt "$end" ]; then
    printf '%s\n' day
  else
    printf '%s\n' night
  fi
}

apply_theme() {
  local resolved wallpaper
  resolved="$(resolve_mode)"
  wallpaper="$repo/assets/wallpaper-${resolved}.png"

  if [ -r "$wallpaper" ]; then
    pkill -x swaybg 2>/dev/null || true
    nohup swaybg -i "$wallpaper" -m fill >"$state_dir/swaybg.log" 2>&1 &
  fi

  if command -v gsettings >/dev/null 2>&1; then
    if [ "$resolved" = night ]; then
      gsettings set org.gnome.desktop.interface color-scheme 'prefer-dark' >/dev/null 2>&1 || true
      gsettings set org.gnome.desktop.interface gtk-theme 'Adwaita-dark' >/dev/null 2>&1 || true
    else
      gsettings set org.gnome.desktop.interface color-scheme 'default' >/dev/null 2>&1 || true
      gsettings set org.gnome.desktop.interface gtk-theme 'Adwaita' >/dev/null 2>&1 || true
    fi
  fi

  # Mako chooses its day/night config at process start. If the theme changes
  # while the graphical session is already running, restart only the tiny
  # notification daemon so notifications follow the new palette too.
  # During Niri startup there is no mako process yet, so this is a no-op.
  if pgrep -x mako >/dev/null 2>&1 && command -v industrial-mako >/dev/null 2>&1; then
    pkill -x mako 2>/dev/null || true
    nohup industrial-mako >"$state_dir/mako.log" 2>&1 &
  fi

  printf '%s\n' "$resolved" > "$state_dir/theme-resolved"
}

case "${1:-status}" in
  day|night|auto)
    printf '%s\n' "$1" > "$mode_file"
    apply_theme
    printf 'theme mode: %s (resolved: %s)\n' "$1" "$(resolve_mode)"
    ;;
  current)
    resolve_mode
    ;;
  refresh|apply)
    apply_theme
    ;;
  status)
    printf 'mode: %s\n' "$(cat "$mode_file" 2>/dev/null || printf auto)"
    printf 'resolved: %s\n' "$(resolve_mode)"
    ;;
  *)
    echo "usage: industrial-theme {day|night|auto|current|refresh|status}" >&2
    exit 2
    ;;
esac

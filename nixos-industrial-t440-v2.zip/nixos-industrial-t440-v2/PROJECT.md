# Project specification — Industrial Niri T440

## Product idea

The laptop should feel like a deliberately designed instrument, not a normal Linux desktop covered in widgets.

### When idle / working

Almost nothing from the shell is visible.

Persistent:
- `0/7` workspace counter
- mechanical-style time
- thin dotted/technical line and tiny orange index mark

Everything else is contextual.

### Edges

- **Top:** system/control deck: audio, battery, network, Bluetooth, display, theme.
- **Left:** workspace machine: `0/7` through `6/7`; names only while open.
- **Right:** context surface: music/web/reader/code controls derived from the focused application.
- **Bottom:** search launcher. No dock. No permanent app icons.

### Motion

The UI should communicate state change like physical controls:
- counter numbers move in the direction of workspace travel
- time advances as a short slide counter
- panels use one short ~190 ms cubic movement
- no bounce
- no blur
- no decorative constant movement

### Visual language

Industrial minimal maximalism:
- lots of detail only where the user is interacting
- near-black/charcoal night
- warm off-white day
- restrained burnt orange
- technical lines, dots, grids and measurement-style illustrations
- square geometry
- monospace equipment-label typography
- large empty areas

Never turn this into:
- neon cyberpunk
- a gamer HUD
- a giant dashboard
- glassmorphism
- a permanent dock
- a wall of named status items
- Teenage Engineering branding/products/logos

The inspiration is the *design discipline*, not copied proprietary product UI.

## Daily-driver rule

The application is the computer.

Ardour/REAPER, qutebrowser, a reader, Neovim, etc. get most of the screen. Quickshell is framing and controls around the work, not the work itself.

## Performance rule

ThinkPad T440 / i5-4300U / Intel HD 4400.

Prefer:
- native Wayland
- one centralized shell status subprocess
- Niri IPC events
- no blur/shadows
- no Electron shell
- no permanent heavy dashboard
- no pointless background services

## Reliability rule

Never launch a second Niri/Mesa stack from `nix shell` on the real TTY.

Niri must come from the installed/tested NixOS generation so the compositor and Mesa stack stay matched.

## Safety rule

Never invent the machine's hardware configuration or disk UUIDs.

Prepare -> check -> `nixos-rebuild test` -> visually/physically test -> explicit APPLY -> `nixos-rebuild switch`.

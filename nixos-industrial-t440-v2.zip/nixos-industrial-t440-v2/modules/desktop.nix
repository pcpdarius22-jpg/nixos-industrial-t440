{ pkgs, lib, ... }:

let
  industrialTheme = pkgs.writeShellApplication {
    name = "industrial-theme";
    runtimeInputs = with pkgs; [
      coreutils
      procps
      swaybg
      glib
    ];
    text = builtins.readFile ../scripts/runtime-theme.sh;
  };

  industrialFoot = pkgs.writeShellApplication {
    name = "industrial-foot";
    runtimeInputs = [ pkgs.foot industrialTheme ];
    text = ''
      mode="$(industrial-theme current)"
      cfg="$HOME/.config/industrial/foot-''${mode}.ini"
      if [ ! -r "$cfg" ]; then
        echo "Industrial Foot config missing: $cfg" >&2
        exec ${pkgs.foot}/bin/foot "$@"
      fi
      exec ${pkgs.foot}/bin/foot --config="$cfg" "$@"
    '';
  };

  industrialPolkitAgent = pkgs.writeShellApplication {
    name = "industrial-polkit-agent";
    text = ''
      exec ${pkgs.polkit_gnome}/libexec/polkit-gnome-authentication-agent-1
    '';
  };

  industrialFuzzel = pkgs.writeShellApplication {
    name = "industrial-fuzzel";
    runtimeInputs = [ pkgs.fuzzel industrialTheme ];
    text = ''
      mode="$(industrial-theme current)"
      cfg="$HOME/.config/industrial/fuzzel-$mode.ini"
      exec ${pkgs.fuzzel}/bin/fuzzel --config="$cfg" "$@"
    '';
  };

  industrialSwaylock = pkgs.writeShellApplication {
    name = "industrial-swaylock";
    runtimeInputs = [ pkgs.swaylock industrialTheme ];
    text = ''
      mode="$(industrial-theme current)"
      cfg="$HOME/.config/industrial/swaylock-$mode.conf"
      exec ${pkgs.swaylock}/bin/swaylock --config "$cfg" "$@"
    '';
  };

  industrialMako = pkgs.writeShellApplication {
    name = "industrial-mako";
    runtimeInputs = [ pkgs.mako industrialTheme ];
    text = ''
      mode="$(industrial-theme current)"
      cfg="$HOME/.config/industrial/mako-$mode.conf"
      exec ${pkgs.mako}/bin/mako --config "$cfg" "$@"
    '';
  };

  industrialPower = pkgs.writeShellApplication {
    name = "industrial-power";
    runtimeInputs = [ pkgs.systemd industrialSwaylock industrialFuzzel ];
    text = ''
      choice="$(printf '%s\n' lock suspend reboot poweroff | industrial-fuzzel --dmenu --prompt='power > ' --lines=4 --width=28)" || exit 0
      case "$choice" in
        lock) industrial-swaylock -f ;;
        suspend) systemctl suspend ;;
        reboot) systemctl reboot ;;
        poweroff) systemctl poweroff ;;
      esac
    '';
  };

  industrialNiriSession = pkgs.writeShellApplication {
    name = "industrial-niri-session";
    runtimeInputs = [ pkgs.niri ];
    text = ''
      config="$HOME/.config/niri/config.kdl"
      if [ ! -r "$config" ]; then
        echo "Industrial Niri config not found: $config" >&2
        echo "Run scripts/prepare from the extracted/cloned Industrial repository first." >&2
        exit 1
      fi

      export NIRI_CONFIG="$config"
      exec ${pkgs.niri}/bin/niri-session
    '';
  };
in
{
  programs.niri = {
    enable = true;
    useNautilus = false;
  };

  # programs.niri already enables the GNOME screencast portal and configures
  # GTK as its FileChooser fallback. Install the GTK implementation explicitly.
  xdg.portal.extraPortals = [ pkgs.xdg-desktop-portal-gtk ];

  security.polkit.enable = true;
  programs.dconf.enable = true;
  services.gnome.gnome-keyring.enable = true;

  environment.sessionVariables = {
    NIXOS_OZONE_WL = "1";
    MOZ_ENABLE_WAYLAND = "1";
    QT_QPA_PLATFORM = "wayland;xcb";
    QT_WAYLAND_DISABLE_WINDOWDECORATION = "1";
    GDK_BACKEND = "wayland,x11";
    TERMINAL = "industrial-foot";
    BROWSER = "qutebrowser";
    EDITOR = "nvim";
    VISUAL = "nvim";
  };

  environment.systemPackages = with pkgs; [
    industrialTheme
    industrialFoot
    industrialPolkitAgent
    industrialFuzzel
    industrialSwaylock
    industrialMako
    industrialPower
    industrialNiriSession

    # Shell / compositor
    quickshell
    foot
    fuzzel
    xwayland-satellite
    swaybg
    mako
    swayidle
    swaylock
    polkit_gnome

    # Wayland utilities
    wl-clipboard
    grim
    slurp
    brightnessctl
    playerctl

    # The shell's single status probe uses these.
    jq
    procps
    networkmanager
    bluez
    blueman
    upower
    wireplumber
    pipewire
    libnotify
    xdg-utils
    xdg-user-dirs
    udisks2
    udiskie
  ];

  # Fail-safe graphical autostart:
  # - only local tty1
  # - never over SSH
  # - can be disabled with ~/.disable-industrial
  # - does NOT exec, so if Niri exits/crashes you land in the TTY shell.
  environment.loginShellInit = ''
    if [ -z "''${WAYLAND_DISPLAY:-}" ] \
       && [ -z "''${DISPLAY:-}" ] \
       && [ -z "''${SSH_TTY:-}" ] \
       && [ "''${USER:-}" = "sloth" ] \
       && [ "$(tty 2>/dev/null || true)" = "/dev/tty1" ] \
       && [ ! -e "$HOME/.disable-industrial" ]; then
      industrial-niri-session || true
      printf '\nIndustrial Niri exited. You are back on tty1.\n'
      printf 'Create ~/.disable-industrial to disable graphical autostart.\n'
    fi
  '';

  fonts.packages = with pkgs; [
    ultimate-oldschool-pc-font-pack
    nerd-fonts.symbols-only
    dejavu_fonts
    noto-fonts-color-emoji
  ];
  fonts.fontconfig.defaultFonts = {
    monospace = [ "PxPlus IBM VGA 8x16" "DejaVu Sans Mono" ];
    # Keep the equipment-label typeface for shell/terminal monospace only.
    # Normal webpages/readers retain comfortable proportional fonts.
    sansSerif = [ "DejaVu Sans" ];
    serif = [ "DejaVu Serif" ];
    emoji = [ "Noto Color Emoji" ];
  };
}

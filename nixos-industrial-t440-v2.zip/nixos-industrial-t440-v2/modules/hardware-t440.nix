{ pkgs, ... }:

{
  boot.loader.systemd-boot = {
    enable = true;
    configurationLimit = 4;
    editor = true;
  };
  boot.loader.efi.canTouchEfiVariables = true;

  # threadirqs is useful for low-latency audio. HDA power saving is disabled
  # because aggressive codec suspend can cause pops/wake latency in DAWs.
  boot.kernelParams = [
    "threadirqs"
    "snd_hda_intel.power_save=0"
  ];

  hardware.enableRedistributableFirmware = true;

  # ThinkPad T440: Haswell i5-4300U + Intel HD 4400.
  # Haswell uses the legacy i965 VA-API driver. 32-bit graphics is needed by
  # Wine/XWayland applications and some plugins.
  environment.variables.LIBVA_DRIVER_NAME = "i965";
  hardware.graphics = {
    enable = true;
    enable32Bit = true;
    extraPackages = with pkgs; [
      intel-vaapi-driver
      libvdpau-va-gl
    ];
  };

  # Compressed swap cushions heavy browser/DAW sessions before the kernel has
  # to lean hard on the existing SSD swap discovered by the hardware scan.
  zramSwap = {
    enable = true;
    memoryPercent = 50;
  };

  # Avoid proactive desktop-app killing; the machine already has zram plus the
  # disk swap discovered in hardware-configuration.nix.
  systemd.oomd.enable = false;

  services.tlp = {
    enable = true;
    settings = {
      CPU_SCALING_GOVERNOR_ON_AC = "performance";
      CPU_SCALING_GOVERNOR_ON_BAT = "powersave";
      CPU_ENERGY_PERF_POLICY_ON_AC = "performance";
      CPU_ENERGY_PERF_POLICY_ON_BAT = "power";

      START_CHARGE_THRESH_BAT0 = 40;
      STOP_CHARGE_THRESH_BAT0 = 80;
      START_CHARGE_THRESH_BAT1 = 40;
      STOP_CHARGE_THRESH_BAT1 = 80;
    };
  };

  services.thermald.enable = true;
  services.fstrim.enable = true;

  hardware.bluetooth = {
    enable = true;
    powerOnBoot = true;
  };
  services.blueman.enable = true;

  # brightnessctl ships permission rules for backlight/LED sysfs nodes; adding
  # the package to udev rules makes the hardware keys work without sudo.
  services.udev.packages = [ pkgs.brightnessctl ];

  services.upower.enable = true;
  services.udisks2.enable = true;
}

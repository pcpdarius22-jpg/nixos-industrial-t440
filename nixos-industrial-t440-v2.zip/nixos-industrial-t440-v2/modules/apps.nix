{ pkgs, ... }:

let
  # Curated iconic systems only. This avoids retroarchFull/MAME-style giant
  # builds while still making RetroArch useful immediately.
  retroarchIndustrial = pkgs.retroarch.withCores (cores: with cores; [
    quicknes          # NES
    snes9x            # SNES
    mgba              # GB/GBC/GBA
    genesis-plus-gx   # Master System / Mega Drive / Genesis
    pcsx-rearmed      # PlayStation 1
    mupen64plus       # Nintendo 64
    stella            # Atari 2600
    hatari            # Atari ST (historic MIDI/music workstation)
    vice-x64          # Commodore 64
    puae              # Amiga
    dosbox-pure       # DOS / classic PC
  ]);

  # Nixpkgs' WineASIO package ships the 64-bit DLLs and settings GUI, but not
  # upstream's distro-oriented registration helper. This wrapper performs the
  # equivalent registration for one Wine prefix without guessing a prefix.
  # Usage: WINEPREFIX=/path/to/prefix industrial-wineasio-register
  industrialWineAsioRegister = pkgs.writeShellApplication {
    name = "industrial-wineasio-register";
    runtimeInputs = [ pkgs.coreutils pkgs.wineWow64Packages.stable ];
    text = ''
      prefix="''${WINEPREFIX:-$HOME/.wine}"
      export WINEPREFIX="$prefix"

      unix_dll="${pkgs.wineasio}/lib/wine/x86_64-unix/wineasio64.dll.so"
      win_dll="${pkgs.wineasio}/lib/wine/x86_64-windows/wineasio64.dll"

      if [ ! -r "$unix_dll" ] || [ ! -r "$win_dll" ]; then
        echo "WineASIO 64-bit DLLs are missing from the Nix store." >&2
        exit 1
      fi

      if [ ! -d "$prefix/drive_c" ]; then
        echo "Creating Wine prefix: $prefix"
        ${pkgs.wineWow64Packages.stable}/bin/wineboot -u
      fi

      mkdir -p "$prefix/drive_c/windows/system32"
      cp -f "$win_dll" "$prefix/drive_c/windows/system32/wineasio64.dll"

      if [ -x "${pkgs.wineWow64Packages.stable}/bin/wine64" ]; then
        wine64="${pkgs.wineWow64Packages.stable}/bin/wine64"
      else
        wine64="${pkgs.wineWow64Packages.stable}/bin/wine"
      fi

      echo "Registering 64-bit WineASIO in: $prefix"
      "$wine64" regsvr32 "$unix_dll"
      echo "WineASIO registration completed for this prefix."
      echo "Note: this Nixpkgs WineASIO build is 64-bit only."
    '';
  };
in
{
  environment.systemPackages = with pkgs; [
    # Core terminal / development
    git
    gh
    codex
    neovim
    vim
    curl
    wget
    unzip
    zip
    file
    fzf
    fd
    ripgrep
    zoxide
    jq
    gawk
    lazygit
    python3

    # Terminal-first daily tools
    yazi
    btop
    fastfetch
    lynx
    pulsemixer
    socat

    # Browser / media / reading
    qutebrowser
    firefox
    mpv
    yt-dlp
    ffmpeg
    imv
    zathura
    foliate
    sox
    libqalculate
    cmus
    senpai

    # Music production: native first, Windows compatibility retained.
    industrialWineAsioRegister
    ardour
    reaper
    wineWow64Packages.stable
    wineasio
    winetricks
    yabridge
    yabridgectl
    qpwgraph
    pavucontrol

    # Lightweight compatibility / optional daily tools, no background daemon.
    retroarchIndustrial
    transmission_4
    tremc

    # Diagnostics used by scripts/doctor.
    pciutils
    usbutils
    libva-utils
    mesa-demos
    alsa-utils
    lm_sensors
    smartmontools
  ];
}

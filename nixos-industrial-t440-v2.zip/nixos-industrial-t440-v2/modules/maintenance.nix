{ pkgs, ... }:

{
  # Weekly maintenance without an always-running helper.
  systemd.services.nixos-generation-trimmer = {
    description = "Trim old NixOS system generations";
    serviceConfig.Type = "oneshot";
    script = ''
      ${pkgs.nix}/bin/nix-env -p /nix/var/nix/profiles/system --delete-generations +4 || true
      ${pkgs.nix}/bin/nix-collect-garbage
    '';
  };

  systemd.timers.nixos-generation-trimmer = {
    wantedBy = [ "timers.target" ];
    timerConfig = {
      OnCalendar = "weekly";
      Persistent = true;
    };
  };
}

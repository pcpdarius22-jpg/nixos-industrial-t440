# Industrial qutebrowser config.
# It deliberately keeps websites recognizable; only browser chrome and the
# preferred page color scheme follow the shell.

import subprocess

config.load_autoconfig(False)

try:
    mode = subprocess.check_output(
        ["industrial-theme", "current"], text=True, timeout=1
    ).strip()
except Exception:
    mode = "night"

dark = mode != "day"

c.tabs.position = "right"
c.tabs.width = 30
c.tabs.title.alignment = "center"
c.tabs.favicons.show = "never"
c.tabs.indicator.width = 0
c.tabs.title.format = "{index}"
c.tabs.show = "multiple"
c.tabs.tooltips = False

c.statusbar.show = "in-mode"
c.statusbar.position = "bottom"
c.scrolling.bar = "never"
c.hints.radius = 0
c.window.hide_decoration = True

c.fonts.default_family = "PxPlus IBM VGA 8x16"
c.fonts.default_size = "10pt"
c.fonts.statusbar = "10pt PxPlus IBM VGA 8x16"
c.fonts.tabs.selected = "10pt PxPlus IBM VGA 8x16"
c.fonts.tabs.unselected = "10pt PxPlus IBM VGA 8x16"
c.fonts.completion.entry = "10pt PxPlus IBM VGA 8x16"
c.fonts.completion.category = "bold 10pt PxPlus IBM VGA 8x16"

c.content.javascript.enabled = True
c.content.blocking.enabled = True
c.content.blocking.method = "auto"
c.content.notifications.presenter = "libnotify"
c.colors.webpage.darkmode.enabled = dark
c.colors.webpage.darkmode.policy.images = "never"
c.colors.webpage.preferred_color_scheme = "dark" if dark else "light"

c.url.start_pages = ["about:blank"]
c.url.default_page = "about:blank"

c.tabs.padding = {"top": 4, "bottom": 4, "left": 8, "right": 6}
c.statusbar.padding = {"top": 5, "bottom": 5, "left": 8, "right": 8}

# Browser chrome follows the Industrial palette; actual websites keep their own
# identity except for the normal preferred light/dark color-scheme hint above.
if dark:
    bg, panel, fg, dim, line, accent = (
        "#07090a", "#101416", "#c9c7c1", "#747a7c", "#293035", "#d15a22"
    )
else:
    bg, panel, fg, dim, line, accent = (
        "#f1eee6", "#e4dfd4", "#171717", "#736d64", "#b9b1a5", "#d45b1e"
    )

c.colors.tabs.bar.bg = bg
c.colors.tabs.odd.bg = bg
c.colors.tabs.even.bg = bg
c.colors.tabs.odd.fg = dim
c.colors.tabs.even.fg = dim
c.colors.tabs.selected.odd.bg = panel
c.colors.tabs.selected.even.bg = panel
c.colors.tabs.selected.odd.fg = fg
c.colors.tabs.selected.even.fg = fg
c.colors.statusbar.normal.bg = bg
c.colors.statusbar.normal.fg = fg
c.colors.statusbar.insert.bg = panel
c.colors.statusbar.insert.fg = accent
c.colors.statusbar.command.bg = bg
c.colors.statusbar.command.fg = fg
c.colors.statusbar.url.fg = dim
c.colors.statusbar.url.success.http.fg = fg
c.colors.statusbar.url.success.https.fg = fg
c.colors.completion.fg = fg
c.colors.completion.odd.bg = bg
c.colors.completion.even.bg = bg
c.colors.completion.category.bg = panel
c.colors.completion.category.fg = accent
c.colors.completion.item.selected.bg = panel
c.colors.completion.item.selected.fg = fg
c.colors.completion.match.fg = accent
c.colors.hints.bg = accent
c.colors.hints.fg = bg
c.colors.hints.match.fg = fg

config.bind("d", "tab-close")
config.bind("u", "undo")
config.bind(",m", "spawn mpv {url}")
config.bind(",y", "spawn yt-dlp {url}")

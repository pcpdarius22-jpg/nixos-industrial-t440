# NixOS Industrial T440 — v2

A complete NixOS 26.05 + Niri + Quickshell daily-driver configuration for the Lenovo ThinkPad T440.

The release is pinned to the same Nixpkgs revision family already used for this T440 project, with **Niri 26.04** and **Quickshell 0.3.0** fixed by `flake.lock` instead of being updated unpredictably during install.

The desktop is intentionally **almost invisible while you work**:

- persistent top strip: `0/7` + deliberate empty/dotted space + time
- top edge: system/control deck
- left edge: workspace machine
- right edge: app-aware context surface
- bottom edge: search launcher
- no permanent dock
- no permanent CPU/RAM/battery clutter
- no blur or shadows
- no temporary `nix shell` compositor

## Important safety design

This repository never guesses disk UUIDs.

`bash scripts/prepare` generates `hosts/t440/hardware-configuration.nix` on the actual laptop and backs up `/etc/nixos` first.

The first activation is always:

```bash
sudo nixos-rebuild test --flake path:.#t440
```

Only `scripts/apply` performs a permanent `switch`.

## Install

The installer works whether this folder came from Git, a GitHub ZIP, or the provided archive; the scripts use an explicit local `path:` flake so uncommitted/untracked extracted files are not silently omitted.

If `~/nixos-industrial-t440` is an old experiment:

```bash
cd ~
mv nixos-industrial-t440 nixos-industrial-t440-old
git clone https://github.com/pcpdarius22-jpg/nixos-industrial-t440.git
cd nixos-industrial-t440
```

If GitHub currently contains the release as a ZIP, extract that ZIP so `flake.nix` is in the directory you run from.

**Run the installer from tty1, not from inside an already-running Niri/Sway session.** Exit the graphical session first (`Super+Shift+E` in the Industrial Niri test), then:

```bash
bash install.sh
```

`install.sh` performs:
1. `/etc/nixos` backup
2. real T440 hardware scan
3. live config links
4. verifies the shipped reproducible NixOS 26.05 flake lock
5. static/evaluation checks
6. `nixos-rebuild test`
7. Niri validation

When it finishes, start the test session:

```bash
industrial-niri-session
```

Use it. Check Wi-Fi, Bluetooth, audio, browser, sleep/wake and your DAW.

Exit with:

```text
Super+Shift+E
```

Then, only if you want to keep it:

```bash
bash scripts/apply
```

## Recovery

The graphical autostart is deliberately fail-safe. It runs Niri from tty1 **without `exec`**, so exiting/crashing returns to the shell.

Disable automatic Niri start:

```bash
touch ~/.disable-industrial
```

Re-enable:

```bash
rm ~/.disable-industrial
```

You can always use another TTY with `Ctrl+Alt+F3`.

## Core controls

| Binding | Action |
|---|---|
| `Super+T` | Industrial Foot terminal |
| `Super+Space` | custom bottom launcher; Fuzzel fallback |
| `Super+S` | system deck |
| `Super+A` | context deck |
| `Super+Tab` | Niri overview |
| `Super+Shift+L` | lock |
| `Super+1..7` | workspaces |
| `Super+Shift+1..7` | move to workspace |
| `Super+H/J/K/L` | navigate |
| `Super+Ctrl+H/J/K/L` | move |
| `Super+Q` | close |
| `Super+Shift+E` | exit Niri |

## Workspaces

The visible counter is `0/7` through `6/7`; the names only appear when the left edge is opened.

0. work
1. web
2. music
3. reader
4. code
5. comm
6. files

## Day / night

Default mode is `auto`, using a lightweight time schedule instead of a location daemon:

```bash
industrial-theme auto
industrial-theme day
industrial-theme night
industrial-theme status
```

The default automatic hours are in `config/theme-hours`. The shell and technical wallpaper switch; GTK is asked to follow the mode too.

## Music production

Included:

- PipeWire + WirePlumber
- ALSA 32-bit
- PulseAudio compatibility
- JACK compatibility
- realtime kit / audio limits
- 48 kHz / 256 default quantum with 64–1024 allowed
- Ardour
- REAPER
- Wine 64/32 compatibility package
- yabridge + yabridgectl for Windows VST2/VST3/CLAP plugins in native Linux DAWs
- WineASIO 64-bit + `industrial-wineasio-register` helper (optional; register only the Wine prefix that needs ASIO)
- Winetricks
- qpwgraph
- pavucontrol

The desktop does **not** force the whole machine to 64/128 samples all day. Select a smaller buffer when a project needs it.

WineASIO is installed but deliberately **not auto-registered into every Wine prefix**. Registration is per-prefix. For a 64-bit Windows DAW, run for example:

```bash
WINEPREFIX="$HOME/.wine" industrial-wineasio-register
```

Use the same `WINEPREFIX` that contains the DAW. The helper copies/registers the WineASIO DLL from the pinned Nix store package. The pinned Nixpkgs WineASIO package is 64-bit, so a 32-bit-only Windows DAW/plugin cannot use that ASIO DLL; those apps can still use Wine's normal PipeWire/Pulse path. Likewise, the pinned yabridge build is intended for 64-bit Windows plugins.

## T440 hardware support

Included/configured:

- Intel Haswell microcode/redistributable firmware
- Intel HD 4400 graphics
- 32-bit graphics for Wine/XWayland
- Haswell `i965` VA-API driver
- kernel firmware + Intel microcode
- NetworkManager
- Bluetooth + Blueman
- UPower
- TLP
- thermald
- SSD TRIM
- zram
- systemd-boot recovery generations
- DejaVu fallback fonts + Noto Color Emoji so normal web/Romanian text is not limited by the industrial bitmap-style UI font

Extra daily-driver pieces include the OpenAI Codex CLI (installed permanently, so it no longer needs a temporary `nix shell`), GitHub CLI, qutebrowser plus Firefox as a compatibility fallback, ffmpeg/yt-dlp, Foliate/Zathura, cmus, Senpai, RetroArch with a curated NES/SNES/GB-GBA/Mega Drive/PS1/N64/Atari 2600/Atari ST/Commodore 64/Amiga/DOS core set (not `retroarchFull`), Transmission/tremc, sensors/smartctl, and diagnostic tools. `udiskie` is the one deliberate tiny desktop helper added for automatic removable-drive mounting; it runs without a tray.

Run the runtime check after entering Niri:

```bash
bash scripts/doctor
```

## Live design editing

These are deliberately symlinked from the Git checkout:

- `niri/config.kdl`
- `quickshell/shell.qml`

Niri live-reloads config changes. Quickshell also watches its config. This is the intended Codex loop:

```text
Niri -> Foot -> Codex/editor -> save -> inspect -> refine
```

No NixOS rebuild is needed for ordinary visual edits.

## Known boundary

This repo statically checks shell scripts, evaluates the complete NixOS toplevel before activation, and validates Niri after the test generation is installed. The final hardware validation still has to happen on the physical T440 because this repository cannot emulate its Wi-Fi card, battery, audio codec, BIOS, or external USB audio hardware.

# Codex instructions — Industrial T440

Read `PROJECT.md` and `README.md` before making changes.

Primary priorities:
1. reliability on the physical ThinkPad T440
2. daily usability
3. low CPU/GPU/idle overhead
4. the Industrial visual/interaction language
5. features only after the above

Do not reintroduce:
- `preview.sh`
- temporary `nix shell` Niri/Mesa
- a permanent dock
- a giant status dashboard
- blur/shadows
- generic neon/cyberpunk styling
- unrelated cleanup while iterating on one visual detail

The shell should be invisible until needed. `0/7` and the clock are the only persistent anchors.

For visual edits:
- prefer modifying `quickshell/shell.qml` or `niri/config.kdl`
- preserve live reload
- make focused diffs
- tell the user whether a Nix rebuild is actually needed

Before system changes:
- run `bash scripts/check`
- use `nixos-rebuild test`, never switch automatically
- never modify hardware UUIDs by hand

The reference board is `docs/visual-target.jpg`.

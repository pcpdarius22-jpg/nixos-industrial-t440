//@ pragma ShellId industrial
//@ pragma NativeTextRendering

import QtQuick
import QtQuick.Layouts
import Quickshell
import Quickshell.Io
import Quickshell.Services.UPower

ShellRoot {
    id: root

    property var workspaceNames: ["work", "web", "music", "reader", "code", "comm", "files"]
    property int workspaceIndex: 0
    property string workspaceName: "work"
    property string activeTitle: "DESKTOP"
    property string activeApp: "niri"
    property var windowsById: ({})

    property bool dayMode: false
    property bool launcherRequested: false
    property bool systemRequested: false
    property bool contextRequested: false

    property string volumeText: "--"
    property string sinkText: "--"
    property string networkText: "--"
    property string bluetoothText: "--"
    property string brightnessText: "--"

    property color bg: dayMode ? "#f1eee6" : "#07090a"
    property color panel: dayMode ? "#ebe7dd" : "#0b0e10"
    property color panel2: dayMode ? "#e4dfd4" : "#101416"
    property color text: dayMode ? "#171717" : "#c9c7c1"
    property color dim: dayMode ? "#736d64" : "#747a7c"
    property color line: dayMode ? "#b9b1a5" : "#293035"
    property color orange: dayMode ? "#d45b1e" : "#d15a22"
    property color green: dayMode ? "#56785b" : "#607d68"

    // Day/night should feel like the same physical machine changing state,
    // not an instant black/white skin swap. These animations run only when
    // the mode changes, so they add no continuous idle cost.
    Behavior on bg { ColorAnimation { duration: 700; easing.type: Easing.OutCubic } }
    Behavior on panel { ColorAnimation { duration: 700; easing.type: Easing.OutCubic } }
    Behavior on panel2 { ColorAnimation { duration: 700; easing.type: Easing.OutCubic } }
    Behavior on text { ColorAnimation { duration: 700; easing.type: Easing.OutCubic } }
    Behavior on dim { ColorAnimation { duration: 700; easing.type: Easing.OutCubic } }
    Behavior on line { ColorAnimation { duration: 700; easing.type: Easing.OutCubic } }
    Behavior on orange { ColorAnimation { duration: 700; easing.type: Easing.OutCubic } }
    Behavior on green { ColorAnimation { duration: 700; easing.type: Easing.OutCubic } }

    function workspaceNumber(name) {
        for (var i = 0; i < workspaceNames.length; ++i)
            if (workspaceNames[i] === name)
                return i
        return -1
    }

    function setFocusedWindow(win) {
        if (!win)
            return
        activeTitle = (win.title && win.title.length > 0) ? win.title : "UNTITLED"
        activeApp = (win.app_id && win.app_id.length > 0) ? win.app_id : "unknown"
    }

    function handleNiriEvent(lineText) {
        if (!lineText || lineText.length === 0)
            return

        try {
            var event = JSON.parse(lineText)

            if (event.WorkspacesChanged) {
                var workspaces = event.WorkspacesChanged.workspaces
                for (var i = 0; i < workspaces.length; ++i) {
                    var ws = workspaces[i]
                    if (ws.is_focused) {
                        var n = workspaceNumber(ws.name)
                        if (n >= 0) {
                            workspaceIndex = n
                            workspaceName = ws.name
                        }
                    }
                }
            }

            if (event.WindowsChanged) {
                var next = ({})
                var windows = event.WindowsChanged.windows
                for (var j = 0; j < windows.length; ++j) {
                    next[String(windows[j].id)] = windows[j]
                    if (windows[j].is_focused)
                        setFocusedWindow(windows[j])
                }
                windowsById = next
                if (windows.length === 0) {
                    activeTitle = "DESKTOP"
                    activeApp = "niri"
                }
            }

            if (event.WindowOpenedOrChanged) {
                var changed = event.WindowOpenedOrChanged.window
                var copy = ({})
                for (var key in windowsById)
                    copy[key] = windowsById[key]
                copy[String(changed.id)] = changed
                windowsById = copy
                if (changed.is_focused)
                    setFocusedWindow(changed)
            }

            if (event.WindowClosed) {
                var kept = ({})
                for (var k in windowsById)
                    if (k !== String(event.WindowClosed.id))
                        kept[k] = windowsById[k]
                windowsById = kept
            }

            if (event.WindowFocusChanged) {
                var id = event.WindowFocusChanged.id
                if (id === null) {
                    activeTitle = "DESKTOP"
                    activeApp = "niri"
                } else {
                    setFocusedWindow(windowsById[String(id)])
                }
            }
        } catch (error) {
            console.log("industrial: ignored niri event:", error)
        }
    }

    function run(command) {
        Quickshell.execDetached(["sh", "-lc", command])
    }

    function contextKind() {
        var a = activeApp.toLowerCase()
        var t = activeTitle.toLowerCase()

        if (a.indexOf("ardour") >= 0 || a.indexOf("reaper") >= 0 ||
            t.indexOf("fl studio") >= 0 || t.indexOf("ableton") >= 0 ||
            t.indexOf("studio one") >= 0)
            return "music"

        if (a.indexOf("qutebrowser") >= 0 || a.indexOf("firefox") >= 0 ||
            a.indexOf("chrom") >= 0)
            return "web"

        if (a.indexOf("zathura") >= 0 || a.indexOf("foliate") >= 0 ||
            t.indexOf(".epub") >= 0 || t.indexOf(".pdf") >= 0)
            return "reader"

        if (a.indexOf("foot") >= 0 || a.indexOf("code") >= 0 ||
            a.indexOf("nvim") >= 0)
            return "code"

        return workspaceName
    }

    function closeTemporarySurfaces() {
        launcherRequested = false
        systemRequested = false
        contextRequested = false
    }

    IpcHandler {
        target: "industrial"

        function launcher(): void {
            root.launcherRequested = !root.launcherRequested
            if (root.launcherRequested) {
                root.systemRequested = false
                root.contextRequested = false
            }
        }

        function systemDeck(): void {
            root.systemRequested = !root.systemRequested
            if (root.systemRequested) {
                root.launcherRequested = false
                root.contextRequested = false
            }
        }

        function contextDeck(): void {
            root.contextRequested = !root.contextRequested
            if (root.contextRequested) {
                root.launcherRequested = false
                root.systemRequested = false
            }
        }

        function close(): void {
            root.closeTemporarySurfaces()
        }

        function themeRefresh(): void {
            if (!themeProbe.running)
                themeProbe.running = true
        }
    }

    SystemClock {
        id: clock
        precision: SystemClock.Seconds
    }

    Process {
        id: niriEvents
        running: true
        command: ["niri", "msg", "--json", "event-stream"]

        stdout: SplitParser {
            onRead: data => root.handleNiriEvent(data)
        }

        onRunningChanged: {
            if (!running)
                reconnect.start()
        }
    }

    Timer {
        id: reconnect
        interval: 1200
        repeat: false
        onTriggered: niriEvents.running = true
    }

    // One process supplies all shell status fields. This is deliberately
    // centralized instead of running a process per widget.
    Timer {
        interval: 5000
        repeat: true
        running: true
        triggeredOnStart: true
        onTriggered: {
            if (!statusProbe.running)
                statusProbe.running = true
        }
    }

    Process {
        id: statusProbe
        command: ["sh", "-lc",
            "vol=$(wpctl get-volume @DEFAULT_AUDIO_SINK@ 2>/dev/null | " +
            "awk '{ if ($0 ~ /MUTED/) print \"MUTE\"; else printf \"%d%%\", $2*100 }'); " +
            "sink=$(wpctl inspect @DEFAULT_AUDIO_SINK@ 2>/dev/null | " +
            "sed -n 's/.*node.description = \"\\([^\"]*\\)\".*/\\1/p' | head -1); " +
            "ssid=$(nmcli -t -f NAME,TYPE connection show --active 2>/dev/null | awk -F: '$2 == \"802-11-wireless\" {print $1; exit}'); " +
            "bright=$(brightnessctl -m 2>/dev/null | awk -F, 'NR==1 {print $4}'); " +
            "bt=$(bluetoothctl show 2>/dev/null | awk '/Powered:/ {print ($2 == \"yes\" ? \"ON\" : \"OFF\"); exit}'); " +
            "jq -nc --arg v \"${vol:---}\" --arg s \"${sink:---}\" --arg n \"${ssid:---}\" " +
            "--arg b \"${bright:---}\" --arg bt \"${bt:---}\" " +
            "'{volume:$v,sink:$s,network:$n,brightness:$b,bluetooth:$bt}'"
        ]

        stdout: StdioCollector {
            onStreamFinished: {
                try {
                    var s = JSON.parse(this.text.trim())
                    root.volumeText = s.volume
                    root.sinkText = s.sink
                    root.networkText = s.network
                    root.brightnessText = s.brightness
                    root.bluetoothText = s.bluetooth
                } catch (error) {
                    console.log("industrial: ignored status sample:", error)
                }
            }
        }
    }

    Timer {
        interval: 30000
        repeat: true
        running: true
        triggeredOnStart: true
        onTriggered: {
            if (!themeProbe.running)
                themeProbe.running = true
        }
    }

    Process {
        id: themeProbe
        command: ["industrial-theme", "current"]

        stdout: StdioCollector {
            onStreamFinished: {
                var nextDay = this.text.trim() === "day"
                if (nextDay !== root.dayMode) {
                    root.dayMode = nextDay
                    root.run("industrial-theme refresh")
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // TOP: always only the two anchors + deliberate empty/dotted space.
    // Hover/pin expands the hidden system deck.
    // ─────────────────────────────────────────────────────────────────────
    Variants {
        model: Quickshell.screens

        delegate: PanelWindow {
            id: topPanel
            required property var modelData
            screen: modelData

            anchors {
                top: true
                left: true
                right: true
            }

            property bool expanded: topHover.hovered || root.systemRequested
            implicitHeight: expanded ? 158 : 26
            exclusiveZone: 26
            color: root.bg
            aboveWindows: true

            Behavior on implicitHeight {
                NumberAnimation { duration: 190; easing.type: Easing.OutCubic }
            }

            Rectangle {
                anchors.fill: parent
                color: root.bg
                border.color: root.line
                border.width: 1
            }

            HoverHandler { id: topHover }

            Item {
                id: persistentBar
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                }
                height: 26

                // Workspace counter: old value physically leaves, new value enters.
                Item {
                    id: workspaceCounter
                    anchors {
                        left: parent.left
                        leftMargin: 18
                        verticalCenter: parent.verticalCenter
                    }
                    width: 48
                    height: 18
                    clip: true

                    // These are intentionally plain state, not bindings to root.
                    // A binding would update before onWorkspaceIndexChanged fires and
                    // erase the old value, preventing the mechanical counter animation.
                    property int lastIndex: 0
                    property string currentText: "0/7"

                    Text {
                        id: workspaceOld
                        anchors.left: parent.left
                        y: 0
                        text: workspaceCounter.currentText
                        color: root.text
                        font.family: "monospace"
                        font.pixelSize: 12
                    }

                    Text {
                        id: workspaceNew
                        anchors.left: parent.left
                        y: -parent.height
                        text: workspaceCounter.currentText
                        color: root.text
                        font.family: "monospace"
                        font.pixelSize: 12
                    }

                    function animateTo(nextIndex) {
                        if (nextIndex === lastIndex)
                            return

                        var forward = nextIndex > lastIndex
                        if (lastIndex === 6 && nextIndex === 0)
                            forward = true
                        if (lastIndex === 0 && nextIndex === 6)
                            forward = false

                        workspaceOld.text = currentText
                        currentText = nextIndex + "/7"
                        workspaceNew.text = currentText

                        workspaceOld.y = 0
                        workspaceNew.y = forward ? -height : height

                        wsOldAnim.to = forward ? height : -height
                        wsNewAnim.from = workspaceNew.y
                        wsNewAnim.to = 0

                        wsParallel.start()
                        lastIndex = nextIndex
                    }

                    Connections {
                        target: root
                        function onWorkspaceIndexChanged() {
                            workspaceCounter.animateTo(root.workspaceIndex)
                        }
                    }

                    Component.onCompleted: {
                        lastIndex = root.workspaceIndex
                        currentText = root.workspaceIndex + "/7"
                        workspaceOld.text = currentText
                        workspaceNew.text = currentText
                    }

                    ParallelAnimation {
                        id: wsParallel

                        NumberAnimation {
                            id: wsOldAnim
                            target: workspaceOld
                            property: "y"
                            duration: 190
                            easing.type: Easing.OutCubic
                        }

                        NumberAnimation {
                            id: wsNewAnim
                            target: workspaceNew
                            property: "y"
                            duration: 190
                            easing.type: Easing.OutCubic
                        }
                    }
                }

                Text {
                    anchors {
                        left: parent.left
                        leftMargin: 76
                        right: timeCounter.left
                        rightMargin: 56
                        verticalCenter: parent.verticalCenter
                    }
                    text: "·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·  ·"
                    color: root.dim
                    opacity: 0.7
                    font.family: "monospace"
                    font.pixelSize: 9
                    elide: Text.ElideRight
                }

                Rectangle {
                    anchors {
                        horizontalCenter: parent.horizontalCenter
                        top: parent.top
                    }
                    width: 1
                    height: 4
                    color: root.orange
                }

                Item {
                    id: timeCounter
                    anchors {
                        right: parent.right
                        rightMargin: 18
                        verticalCenter: parent.verticalCenter
                    }
                    width: 58
                    height: 18
                    clip: true

                    property string currentText: Qt.formatDateTime(clock.date, "HH:mm")
                    property int lastMinutes: -1

                    Text {
                        id: timeOld
                        anchors.right: parent.right
                        y: 0
                        text: timeCounter.currentText
                        color: root.text
                        font.family: "monospace"
                        font.pixelSize: 12
                        font.letterSpacing: 1
                    }

                    Text {
                        id: timeNew
                        anchors.right: parent.right
                        y: -parent.height
                        text: timeCounter.currentText
                        color: root.text
                        font.family: "monospace"
                        font.pixelSize: 12
                        font.letterSpacing: 1
                    }

                    function updateClock() {
                        var nextText = Qt.formatDateTime(clock.date, "HH:mm")
                        var nextMinutes = clock.date.getHours() * 60 + clock.date.getMinutes()

                        if (lastMinutes < 0) {
                            lastMinutes = nextMinutes
                            currentText = nextText
                            timeOld.text = nextText
                            timeNew.text = nextText
                            return
                        }

                        if (nextText === currentText)
                            return

                        var diff = nextMinutes - lastMinutes
                        var forward = diff > 0
                        if (diff < -720)
                            forward = true
                        if (diff > 720)
                            forward = false

                        timeOld.text = currentText
                        currentText = nextText
                        timeNew.text = nextText

                        timeOld.y = 0
                        timeNew.y = forward ? -height : height

                        timeOldAnim.to = forward ? height : -height
                        timeNewAnim.from = timeNew.y
                        timeNewAnim.to = 0

                        timeParallel.start()
                        lastMinutes = nextMinutes
                    }

                    Connections {
                        target: clock
                        function onDateChanged() {
                            timeCounter.updateClock()
                        }
                    }

                    Component.onCompleted: updateClock()

                    ParallelAnimation {
                        id: timeParallel

                        NumberAnimation {
                            id: timeOldAnim
                            target: timeOld
                            property: "y"
                            duration: 190
                            easing.type: Easing.OutCubic
                        }

                        NumberAnimation {
                            id: timeNewAnim
                            target: timeNew
                            property: "y"
                            duration: 190
                            easing.type: Easing.OutCubic
                        }
                    }
                }
            }

            Rectangle {
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                    topMargin: 25
                }
                height: 1
                color: root.line
            }

            GridLayout {
                visible: topPanel.expanded
                columns: 3
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                    topMargin: 40
                    leftMargin: 18
                    rightMargin: 18
                }
                rowSpacing: 1
                columnSpacing: 1

                Repeater {
                    model: [
                        ["AUDIO", root.volumeText, root.sinkText],
                        ["BATTERY",
                         UPower.displayDevice.ready ? Math.round(UPower.displayDevice.percentage * 100) + "%" : "--",
                         UPower.onBattery ? "DISCHARGING" : "AC / CHARGING"],
                        ["NETWORK", root.networkText, "Wi-Fi"],
                        ["BLUETOOTH", root.bluetoothText, "RADIO"],
                        ["DISPLAY", root.brightnessText, root.dayMode ? "DAY" : "NIGHT"],
                        ["POWER", UPower.onBattery ? "BATTERY" : "AC", "LOCK / SUSPEND / OFF"]
                    ]

                    delegate: Rectangle {
                        required property var modelData
                        Layout.fillWidth: true
                        Layout.preferredHeight: 48
                        color: root.panel
                        border.color: root.line
                        border.width: 1

                        RowLayout {
                            anchors {
                                fill: parent
                                margins: 9
                            }
                            spacing: 8

                            Rectangle {
                                Layout.preferredWidth: 5
                                Layout.preferredHeight: 5
                                color: root.orange
                                opacity: 0.75
                            }

                            ColumnLayout {
                                Layout.fillWidth: true
                                spacing: 2

                                Text {
                                    text: modelData[0]
                                    color: root.dim
                                    font.family: "monospace"
                                    font.pixelSize: 9
                                }

                                Text {
                                    text: modelData[1]
                                    color: root.text
                                    font.family: "monospace"
                                    font.pixelSize: 12
                                    elide: Text.ElideRight
                                    Layout.fillWidth: true
                                }
                            }

                            Text {
                                text: modelData[2]
                                color: root.dim
                                opacity: 0.7
                                font.family: "monospace"
                                font.pixelSize: 8
                                elide: Text.ElideRight
                                Layout.maximumWidth: 105
                            }
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                if (modelData[0] === "AUDIO")
                                    root.run("qpwgraph")
                                else if (modelData[0] === "NETWORK")
                                    root.run("industrial-foot -e nmtui")
                                else if (modelData[0] === "BLUETOOTH")
                                    root.run("blueman-manager")
                                else if (modelData[0] === "DISPLAY")
                                    root.run("industrial-theme " + (root.dayMode ? "night" : "day"))
                                else if (modelData[0] === "POWER")
                                    root.run("industrial-power")
                            }
                        }
                    }
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // LEFT: workspace machine. Names are intentionally hidden at rest.
    // ─────────────────────────────────────────────────────────────────────
    Variants {
        model: Quickshell.screens

        delegate: PanelWindow {
            id: leftPanel
            required property var modelData
            screen: modelData

            anchors {
                left: true
                top: true
                bottom: true
            }

            property bool expanded: leftHover.hovered
            implicitWidth: expanded ? 156 : 3
            exclusiveZone: 0
            color: "transparent"
            aboveWindows: true

            Behavior on implicitWidth {
                NumberAnimation { duration: 190; easing.type: Easing.OutCubic }
            }

            Rectangle {
                anchors.fill: parent
                color: leftPanel.expanded ? root.bg : "transparent"
                border.color: leftPanel.expanded ? root.line : "transparent"
                border.width: 1
            }

            HoverHandler { id: leftHover }

            Column {
                visible: leftPanel.expanded
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                    topMargin: 48
                    leftMargin: 10
                    rightMargin: 10
                }
                spacing: 2

                Text {
                    text: root.workspaceIndex + "/7"
                    color: root.orange
                    font.family: "monospace"
                    font.pixelSize: 12
                    height: 28
                }

                Rectangle {
                    width: parent.width
                    height: 1
                    color: root.line
                }

                Repeater {
                    model: root.workspaceNames

                    delegate: Rectangle {
                        required property string modelData
                        required property int index
                        width: parent.width
                        height: 31
                        color: index === root.workspaceIndex ? root.panel2 : "transparent"
                        border.color: index === root.workspaceIndex ? root.orange : "transparent"
                        border.width: index === root.workspaceIndex ? 1 : 0

                        Text {
                            anchors {
                                left: parent.left
                                leftMargin: 9
                                verticalCenter: parent.verticalCenter
                            }
                            text: index + "/7   " + modelData.toUpperCase()
                            color: index === root.workspaceIndex ? root.orange : root.text
                            font.family: "monospace"
                            font.pixelSize: 10
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: root.run("niri msg action focus-workspace " + modelData)
                        }
                    }
                }

                Item { width: 1; height: 22 }

                Canvas {
                    width: parent.width
                    height: 86
                    onPaint: {
                        var ctx = getContext("2d")
                        ctx.clearRect(0, 0, width, height)
                        ctx.strokeStyle = root.dim
                        ctx.globalAlpha = 0.35
                        ctx.lineWidth = 1
                        var cx = width / 2
                        var cy = height / 2
                        ctx.beginPath()
                        ctx.arc(cx, cy, 17, 0, Math.PI * 2)
                        ctx.moveTo(cx - 35, cy)
                        ctx.lineTo(cx + 35, cy)
                        ctx.moveTo(cx, cy - 35)
                        ctx.lineTo(cx, cy + 35)
                        ctx.stroke()
                        ctx.globalAlpha = 1
                        ctx.fillStyle = root.orange
                        ctx.fillRect(cx - 1, cy - 1, 2, 2)
                    }
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // RIGHT: context-aware, not a permanent dashboard.
    // ─────────────────────────────────────────────────────────────────────
    Variants {
        model: Quickshell.screens

        delegate: PanelWindow {
            id: rightPanel
            required property var modelData
            screen: modelData

            anchors {
                right: true
                top: true
                bottom: true
            }

            property bool expanded: rightHover.hovered || root.contextRequested
            property string kind: root.contextKind()
            implicitWidth: expanded ? 258 : 3
            exclusiveZone: 0
            color: "transparent"
            aboveWindows: true

            Behavior on implicitWidth {
                NumberAnimation { duration: 190; easing.type: Easing.OutCubic }
            }

            Rectangle {
                anchors.fill: parent
                color: rightPanel.expanded ? root.bg : "transparent"
                border.color: rightPanel.expanded ? root.line : "transparent"
                border.width: 1
            }

            HoverHandler { id: rightHover }

            Column {
                visible: rightPanel.expanded
                anchors {
                    fill: parent
                    margins: 15
                    topMargin: 48
                }
                spacing: 9

                Text {
                    text: rightPanel.kind.toUpperCase()
                    color: root.orange
                    font.family: "monospace"
                    font.pixelSize: 10
                }

                Rectangle { width: parent.width; height: 1; color: root.line }

                Text {
                    text: root.activeTitle
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 12
                    width: parent.width
                    elide: Text.ElideRight
                }

                Text {
                    visible: rightPanel.kind === "music"
                    text: "OUTPUT\n  " + root.sinkText
                        + "\n\nVOLUME\n  " + root.volumeText
                        + "\n\nPIPEWIRE\n  qpwgraph / routing"
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 10
                    lineHeight: 1.45
                }

                Row {
                    visible: rightPanel.kind === "music"
                    spacing: 1

                    Repeater {
                        model: [
                            ["−", "wpctl set-volume @DEFAULT_AUDIO_SINK@ 5%-"],
                            ["MUTE", "wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle"],
                            ["+", "wpctl set-volume -l 1.0 @DEFAULT_AUDIO_SINK@ 5%+"],
                            ["ROUTE", "qpwgraph"]
                        ]

                        delegate: Rectangle {
                            required property var modelData
                            width: modelData[0] === "ROUTE" ? 60 : 44
                            height: 30
                            color: root.panel
                            border.color: root.line
                            border.width: 1

                            Text {
                                anchors.centerIn: parent
                                text: modelData[0]
                                color: root.text
                                font.family: "monospace"
                                font.pixelSize: 9
                            }

                            MouseArea {
                                anchors.fill: parent
                                onClicked: root.run(modelData[1])
                            }
                        }
                    }
                }

                Text {
                    visible: rightPanel.kind === "web"
                    text: "NETWORK\n  " + root.networkText
                        + "\n\nMEDIA\n  playerctl"
                        + "\n\nACTIONS\n  downloads / history / find"
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 10
                    lineHeight: 1.45
                }

                Row {
                    visible: rightPanel.kind === "web"
                    spacing: 1

                    Repeater {
                        model: [
                            ["PLAY", "playerctl play-pause"],
                            ["PREV", "playerctl previous"],
                            ["NEXT", "playerctl next"]
                        ]

                        delegate: Rectangle {
                            required property var modelData
                            width: 62
                            height: 30
                            color: root.panel
                            border.color: root.line
                            border.width: 1

                            Text {
                                anchors.centerIn: parent
                                text: modelData[0]
                                color: root.text
                                font.family: "monospace"
                                font.pixelSize: 9
                            }

                            MouseArea {
                                anchors.fill: parent
                                onClicked: root.run(modelData[1])
                            }
                        }
                    }
                }

                Text {
                    visible: rightPanel.kind === "reader"
                    text: "READER\n\n"
                        + "quiet workspace\n"
                        + "brightness  " + root.brightnessText
                        + "\n\nDISPLAY\n  day / night follows shell"
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 10
                    lineHeight: 1.45
                }

                Row {
                    visible: rightPanel.kind === "reader"
                    spacing: 1

                    Repeater {
                        model: [
                            ["DIM", "brightnessctl set 5%-"],
                            ["LIGHT", "brightnessctl set +5%"],
                            ["THEME", "industrial-theme " + (root.dayMode ? "night" : "day")]
                        ]

                        delegate: Rectangle {
                            required property var modelData
                            width: 62
                            height: 30
                            color: root.panel
                            border.color: root.line
                            border.width: 1

                            Text {
                                anchors.centerIn: parent
                                text: modelData[0]
                                color: root.text
                                font.family: "monospace"
                                font.pixelSize: 9
                            }

                            MouseArea {
                                anchors.fill: parent
                                onClicked: root.run(modelData[1])
                            }
                        }
                    }
                }

                Text {
                    visible: rightPanel.kind === "code" ||
                             (rightPanel.kind !== "music" &&
                              rightPanel.kind !== "web" &&
                              rightPanel.kind !== "reader")
                    text: "APP\n  " + root.activeApp
                        + "\n\nWORKSPACE\n  " + root.workspaceName
                        + "\n\nTOOLS\n  terminal / files / git"
                    color: root.text
                    font.family: "monospace"
                    font.pixelSize: 10
                    lineHeight: 1.45
                }

                Rectangle { width: parent.width; height: 1; color: root.line }

                Text {
                    text: "The app remains the computer.\nThis surface only exposes context."
                    color: root.dim
                    font.family: "monospace"
                    font.pixelSize: 9
                    lineHeight: 1.35
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // BOTTOM: search only. No permanent dock and no generic icon row.
    // ─────────────────────────────────────────────────────────────────────
    Variants {
        model: Quickshell.screens

        delegate: PanelWindow {
            id: bottomPanel
            required property var modelData
            screen: modelData

            anchors {
                left: true
                right: true
                bottom: true
            }

            property bool expanded: bottomHover.hovered || root.launcherRequested
            implicitHeight: expanded ? (searchField.text.length > 0 ? 184 : 76) : 3
            exclusiveZone: 0
            color: "transparent"
            aboveWindows: true
            focusable: root.launcherRequested

            Behavior on implicitHeight {
                NumberAnimation { duration: 190; easing.type: Easing.OutCubic }
            }

            Rectangle {
                anchors.fill: parent
                color: bottomPanel.expanded ? root.bg : "transparent"
                border.color: bottomPanel.expanded ? root.line : "transparent"
                border.width: 1
            }

            HoverHandler { id: bottomHover }

            ScriptModel {
                id: filteredApps
                values: {
                    var q = searchField.text.toLowerCase().trim()
                    if (q.length === 0)
                        return []

                    return DesktopEntries.applications.values
                        .filter(entry => {
                            if (entry.noDisplay)
                                return false
                            if (entry.id === "foot.desktop")
                                return false

                            var name = entry.name || ""
                            var genericName = entry.genericName || ""
                            var comment = entry.comment || ""
                            var keywords = entry.keywords ? entry.keywords.join(" ") : ""
                            var haystack = (name + " " + genericName + " " + comment + " " + keywords).toLowerCase()
                            return haystack.indexOf(q) >= 0
                        })
                        .slice(0, 6)
                }
            }

            Column {
                visible: bottomPanel.expanded
                anchors {
                    left: parent.left
                    right: parent.right
                    top: parent.top
                    topMargin: 14
                    leftMargin: 18
                    rightMargin: 18
                }
                spacing: 7

                Rectangle {
                    width: parent.width
                    height: 42
                    color: root.panel
                    border.color: searchField.activeFocus ? root.orange : root.line
                    border.width: 1

                    TextInput {
                        id: searchField
                        anchors {
                            fill: parent
                            leftMargin: 13
                            rightMargin: 13
                        }
                        verticalAlignment: TextInput.AlignVCenter
                        color: root.text
                        selectionColor: root.orange
                        selectedTextColor: root.bg
                        font.family: "monospace"
                        font.pixelSize: 12
                        clip: true
                        focus: root.launcherRequested

                        Text {
                            visible: searchField.text.length === 0
                            anchors.verticalCenter: parent.verticalCenter
                            text: "○  search applications..."
                            color: root.dim
                            font.family: "monospace"
                            font.pixelSize: 11
                        }

                        Keys.onEscapePressed: {
                            searchField.text = ""
                            root.launcherRequested = false
                        }

                        Keys.onReturnPressed: {
                            if (filteredApps.values.length > 0) {
                                filteredApps.values[0].execute()
                                searchField.text = ""
                                root.launcherRequested = false
                            }
                        }
                    }

                    MouseArea {
                        anchors.fill: parent
                        acceptedButtons: Qt.LeftButton
                        onClicked: {
                            root.launcherRequested = true
                            searchField.forceActiveFocus()
                        }
                    }
                }

                Repeater {
                    model: filteredApps

                    delegate: Rectangle {
                        required property var modelData
                        width: parent.width
                        height: 17
                        color: "transparent"

                        RowLayout {
                            anchors.fill: parent

                            Text {
                                text: "○  " + modelData.name
                                color: root.text
                                font.family: "monospace"
                                font.pixelSize: 10
                                Layout.fillWidth: true
                                elide: Text.ElideRight
                            }

                            Text {
                                text: modelData.genericName.length > 0
                                    ? modelData.genericName.toUpperCase()
                                    : "APP"
                                color: root.dim
                                font.family: "monospace"
                                font.pixelSize: 8
                                elide: Text.ElideRight
                                Layout.maximumWidth: 160
                            }
                        }

                        MouseArea {
                            anchors.fill: parent
                            onClicked: {
                                modelData.execute()
                                searchField.text = ""
                                root.launcherRequested = false
                            }
                        }
                    }
                }
            }

            Connections {
                target: root
                function onLauncherRequestedChanged() {
                    if (root.launcherRequested)
                        focusTimer.start()
                    else
                        searchField.text = ""
                }
            }

            Timer {
                id: focusTimer
                interval: 70
                repeat: false
                onTriggered: searchField.forceActiveFocus()
            }
        }
    }
}

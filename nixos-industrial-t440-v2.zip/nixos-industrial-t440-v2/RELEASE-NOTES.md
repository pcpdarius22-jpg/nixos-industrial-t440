# Industrial T440 v2 — release notes

## What changed from the first prototype

- Replaced the temporary `nix shell` compositor experiment with the NixOS Niri module.
- Pinned NixOS 26.05 / Nixpkgs so installs do not silently move to a new compositor/shell version.
- Added a live hardware scan before building; disk UUIDs are never guessed.
- Added Haswell Intel HD 4400 VA-API/32-bit graphics support and the brightness udev permissions.
- Added PipeWire/WirePlumber + ALSA/Pulse/JACK, realtime permissions and music-production tools.
- Added permanent Codex CLI, GitHub CLI, Wine/yabridge/WineASIO tooling and a 64-bit WineASIO registration helper.
- Added automatic removable-drive mounting, portals/file chooser/screencast support, notifications, polkit, lock/idle and recovery behavior.
- Replaced `retroarchFull` with a curated core set to avoid giant MAME-style builds.
- Added a day/night technical wallpaper + shell palette and a 700 ms shell palette transition.
- Implemented the intended edge shell: minimal persistent bar, top system deck, left workspace machine, right context deck and bottom search-only launcher.
- Fixed the mechanical workspace counter so the old value is retained while the new value slides in.
- Added a Qt Wayland -> XCB fallback so Qt utilities that lack the Wayland plugin can still run through XWayland.
- Disabled the old Home Manager Dunst service during preparation to avoid two notification daemons racing.

## Validation performed before packaging

- Bash syntax checked for installer and every script.
- qutebrowser Python config compiled successfully.
- `flake.lock` parsed as valid JSON.
- Quickshell QML passed lexical error scanning and balanced-delimiter checks.
- Niri KDL passed balanced-delimiter/static review; the installer also runs real `niri validate` after `nixos-rebuild test` on the T440.
- Base64 recovery copies of all binary assets decode byte-for-byte to the packaged images.
- Unsafe old patterns (`preview.sh`, temporary Niri through `nix shell`, manual `DISPLAY`/Xwayland-satellite startup) were scanned out.
- Required install/config/assets were checked present.

## What still must be proven on the physical T440

The installer intentionally performs the real Nix evaluation/build and Niri validation on the laptop, because this build environment does not have NixOS or the T440 hardware. After entering the test generation, run `bash scripts/doctor` and physically test Wi-Fi, Bluetooth, suspend/resume, brightness, audio, VA-API video playback, Wine/XWayland and any USB audio interface before `bash scripts/apply`.

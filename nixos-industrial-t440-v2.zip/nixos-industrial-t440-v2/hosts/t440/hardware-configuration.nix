# PLACEHOLDER ONLY.
# Run: bash scripts/prepare
#
# The prepare script replaces this file with hardware configuration generated
# on the actual T440. This prevents disk UUIDs from ever being guessed.
{ lib, ... }:
{
  assertions = [
    {
      assertion = false;
      message = "Run `bash scripts/prepare` before building Industrial NixOS; hardware-configuration.nix is still the safety placeholder.";
    }
  ];

  nixpkgs.hostPlatform = lib.mkDefault "x86_64-linux";
}

{ pkgs, ... }:

{
  imports = [
    ./hardware-configuration.nix
    ../../modules/hardware-t440.nix
    ../../modules/audio.nix
    ../../modules/desktop.nix
    ../../modules/apps.nix
    ../../modules/maintenance.nix
  ];

  networking.hostName = "thinkpad";
  networking.networkmanager.enable = true;
  networking.firewall.enable = true;

  time.timeZone = "Europe/Bucharest";
  i18n.defaultLocale = "en_US.UTF-8";
  console.keyMap = "us";

  nix.settings = {
    experimental-features = [ "nix-command" "flakes" ];
    auto-optimise-store = true;
  };
  nixpkgs.config.allowUnfree = true;

  users.users.sloth = {
    isNormalUser = true;
    shell = pkgs.bashInteractive;
    extraGroups = [ "wheel" "networkmanager" "audio" "video" "input" ];
  };

  # Keep the already-used appliance-like tty1 path. The desktop module starts
  # Niri from tty1 in a fail-safe way: if Niri exits, the shell remains.
  services.getty.autologinUser = "sloth";

  # Preserve the state version from the existing working configuration.
  system.stateVersion = "24.11";
}

# NixOS FVWM Bloodlines v1.1 — ThinkPad T440

A clean FVWM3-only rebuild of the previous Sway setup.

The design target is the original unixporn FVWM workflow:
- **FVWM Pages**, not ordinary workspace switching
- one 3×2 virtual desktop which can be scrolled at the screen edges
- flat rectangular windows
- tiny top panel
- no rounded corners
- no compositor
- no notification daemon
- no separate application launcher

The visual identity is **Vampire: The Masquerade — Bloodlines**:
near-black, ash, blood red, tarnished brass, dirty ivory.

## Chosen stack

| Role | App |
|---|---|
| WM | FVWM3 |
| Session | tty1 login → automatic `startx` |
| Terminal | URxvt |
| Browser | qutebrowser |
| Editor | Emacs |
| Files | Emacs Dired |
| Launcher | FVWM native menu |
| Top panel | FvwmButtons + FvwmIconMan |
| Notifications | none |
| Music | cmus |
| Video | mpv |
| Images | Emacs image-mode |
| PDF | Emacs DocView |
| Screenshots | none |
| Clipboard | xclip |
| Monitor | top |
| Network | nmtui / nmcli |
| Bluetooth | bluetoothctl |
| Audio | pulsemixer + hardware keys |
| Brightness | brightnessctl + hardware keys |
| Lock | slock + xss-lock suspend protection |
| Font | Terminus |

## Pages

```text
┌────────────────┬────────────────┬────────────────┐
│ 0,0            │ 1,0            │ 2,0            │
│ santa monica   │ downtown       │ hollywood      │
├────────────────┼────────────────┼────────────────┤
│ 0,1            │ 1,1            │ 2,1            │
│ chinatown      │ haven          │ nocturne       │
└────────────────┴────────────────┴────────────────┘
```

Move with `Super+H/J/K/L`, `Super+Arrow`, or push the pointer against a
screen edge. This is a single larger desktop, not six independent workspaces.

## Main keys

| Key | Action |
|---|---|
| `Super+Enter` | URxvt |
| `Super+B` | qutebrowser |
| `Super+E` | Emacs |
| `Super+D` | Dired |
| `Super+M` | cmus |
| `Super+T` | top |
| `Super+N` | nmtui |
| `Super+A` | pulsemixer |
| `Super+Space` | FVWM Bloodlines menu |
| `Super+Escape` | slock |
| `Super+H/J/K/L` | move between Pages |
| `Super+Arrow` | move between Pages |
| `Super+Q` | close focused window |
| `Alt+Tab` | window list |
| `Super+F6` | move window |
| `Super+F7` | resize window |
| `Super+F8` | maximize |
| `Super+Shift+R` | restart FVWM config |

## Safe test on the laptop

Keep a rescue path while testing:

```sh
cd ~/nixos-fvwm-bloodlines

# Stops the automatic GUI launch on the next tty1 shell.
touch ~/.disable-gui

nix flake check
sudo nixos-rebuild test --flake .#thinkpad
```

Then leave the current graphical session and go to tty1. Test manually:

```sh
startx
```

If something is wrong, exit FVWM and you are back at tty1.

If it works:

```sh
sudo nixos-rebuild switch --flake .#thinkpad
rm -f ~/.disable-gui
sudo reboot
```

After reboot, log in normally as `sloth` on tty1; the shell immediately launches FVWM.

### Emergency rescue

From a TTY:

```sh
touch ~/.disable-gui
```

FVWM will no longer auto-start on future tty1 logins.

## Files to edit

- `user/fvwm/config` — Pages, panel, window geometry, menus, keybinds
- `user/Xresources` — URxvt palette/font
- `user/apps.nix` — qutebrowser, Emacs and app packages
- `user/wallpaper/bloodlines.png` — wallpaper
- `system/configuration.nix` — Xorg/FVWM, T440 hardware behavior

## Notes

The configuration deliberately does **not** include Sway, Waybar, Fuzzel,
Foot, Dunst, grim, slurp, wl-clipboard, a GUI file manager, Rofi, or a
display manager.

The existing hardware UUIDs are copied from the current T440 configuration.
If this folder is ever used on a different machine, regenerate
`system/hardware-configuration.nix` first.


## v1.1 audit fixes

- fixes FVWM page-menu navigation: `GotoPage` is deferred with `Schedule`
  instead of being executed directly from a popup menu;
- fixes dynamic top-bar updates to address the actual `FvwmTopBar` module alias;
- replaces 500 ms page-status polling with `FvwmEvent new_page`;
- adds `xss-lock` using the NixOS `slock` setuid wrapper so suspend/resume is locked;
- lets FVWM own qutebrowser's X11 window decoration;
- uses Home Manager's proper Emacs default-editor wrapper and adds daemon fallback;
- replaces the potentially-missing Terminus ankh glyph with a font-safe `V`;
- restores REAPER, Wine/Winetricks, RetroArch, Transmission/tremc and senpai
  as installed-but-not-autostarted functionality from the mature T440 configuration;
- adds `nix-test` and `nix-apply` helpers.

The 3×2 page layout and 1600×22 top-bar geometry remain deliberately
T440-specific. They are valid defaults, but are expected to be tuned after the
first real 1600×900 test.

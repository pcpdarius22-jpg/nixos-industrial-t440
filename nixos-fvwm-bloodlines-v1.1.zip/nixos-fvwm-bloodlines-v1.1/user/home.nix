{ config, pkgs, ... }:
{
  home.username = "sloth";
  home.homeDirectory = "/home/sloth";
  home.stateVersion = "24.11";

  imports = [ ./apps.nix ];

  home.sessionPath = [ "$HOME/.local/bin" ];

  fonts.fontconfig = {
    enable = true;
    defaultFonts = {
      monospace = [ "Terminus" ];
      sansSerif = [ "Terminus" ];
      serif = [ "Terminus" ];
    };
  };

  home.sessionVariables = {
    XDG_CONFIG_HOME = "$HOME/.config";
    XDG_CACHE_HOME = "$HOME/.cache";
    XDG_DATA_HOME = "$HOME/.local/share";
    TERMINAL = "urxvt";
    BROWSER = "qutebrowser";
  };

  gtk = {
    enable = true;
    colorScheme = "dark";
    font = {
      name = "Terminus";
      size = 10;
    };
  };

  programs.bash = {
    enable = true;

    profileExtra = ''
      # Automatic FVWM start after a normal tty1 login. Exit/crash returns to the
      # shell instead of looping. `touch ~/.disable-gui` is the rescue switch.
      if [ -z "''${DISPLAY:-}" ] \
         && [ "$(tty 2>/dev/null || true)" = "/dev/tty1" ] \
         && [ ! -e "$HOME/.disable-gui" ]; then
        startx
        printf '\nFVWM exited. Staying on tty1. `touch ~/.disable-gui` disables autostart.\n'
      fi
    '';

    bashrcExtra = ''
      PS1='\[\e[38;5;7m\]\u@\h\[\e[38;5;1m\]:\[\e[38;5;7m\]\w\[\e[0m\] $ '
      alias ll='ls -lah'
      alias net='nmtui'
      alias bt='bluetoothctl'
      alias vol='pulsemixer'
    '';
  };

  # The entire desktop is declarative.
  home.file.".fvwm/config".source = ./fvwm/config;
  home.file.".Xresources".source = ./Xresources;
  home.file.".config/cmus/rc".source = ./cmusrc;
  home.file.".local/share/wallpapers/bloodlines.png".source = ./wallpaper/bloodlines.png;

  home.file.".local/bin/nix-test" = {
    source = ./scripts/nix-test;
    executable = true;
  };
  home.file.".local/bin/nix-apply" = {
    source = ./scripts/nix-apply;
    executable = true;
  };

  programs.home-manager.enable = true;
}

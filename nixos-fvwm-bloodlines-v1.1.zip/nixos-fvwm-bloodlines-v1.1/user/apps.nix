{ pkgs, ... }:
{
  home.packages = with pkgs; [
    # Chosen desktop stack
    rxvt-unicode
    cmus
    xclip
    procps
    pulsemixer
    brightnessctl
    bluez
    networkmanager

    # Emacs image/PDF support
    ghostscript
    poppler

    # X11 helpers used by the FVWM session
    feh
    xorg.xrandr

    # Small command-line essentials
    ripgrep
    fd
    fzf
    jq
    file
    unzip
    p7zip
    yt-dlp

    # Existing useful functionality retained from the mature T440 config.
    # None of these autostart or alter the FVWM desktop.
    reaper
    wineWow64Packages.stable
    winetricks
    retroarch
    transmission_4
    tremc
    senpai
  ];

  programs.qutebrowser = {
    enable = true;
    loadAutoconfig = false;

    keyBindings.normal = {
      "d" = "tab-close";
      "u" = "undo";
      ",m" = "spawn mpv {url}";
    };

    searchEngines = {
      DEFAULT = "https://duckduckgo.com/?q={}";
      nw = "https://wiki.nixos.org/index.php?search={}";
    };

    settings = {
      tabs.position = "right";
      tabs.width = 30;
      tabs.title.alignment = "center";
      tabs.favicons.show = "never";
      tabs.indicator.width = 0;
      tabs.title.format = "{index}";
      tabs.show = "multiple";

      statusbar.show = "in-mode";
      statusbar.position = "bottom";

      fonts.default_family = "Terminus";
      fonts.default_size = "10pt";
      fonts.statusbar = "10pt Terminus";
      fonts.tabs.selected = "10pt Terminus";
      fonts.tabs.unselected = "10pt Terminus";
      fonts.completion.entry = "10pt Terminus";
      fonts.completion.category = "bold 10pt Terminus";

      content.javascript.enabled = true;
      content.blocking.enabled = true;
      content.blocking.method = "auto";
      colors.webpage.darkmode.enabled = true;
      colors.webpage.darkmode.policy.images = "never";
      colors.webpage.preferred_color_scheme = "dark";
      scrolling.bar = "never";
      hints.radius = 0;
      tabs.tooltips = false;
      window.hide_decoration = false;
      url.start_pages = [ "about:blank" ];
      url.default_page = "about:blank";

      editor.command = [ "emacsclient" "-c" "-a" "emacs" "+{line}:{column}" "{file}" ];
    };

    extraConfig = ''
      # Bloodlines palette: black / ash / blood / tarnished brass.
      c.colors.completion.fg = '#c7bfb1'
      c.colors.completion.odd.bg = '#0a0909'
      c.colors.completion.even.bg = '#11100f'
      c.colors.completion.category.fg = '#9a8052'
      c.colors.completion.category.bg = '#0a0909'
      c.colors.completion.item.selected.fg = '#f1eadb'
      c.colors.completion.item.selected.bg = '#4a1111'
      c.colors.completion.item.selected.border.top = '#8a1f1f'
      c.colors.completion.item.selected.border.bottom = '#8a1f1f'

      c.colors.statusbar.normal.fg = '#c7bfb1'
      c.colors.statusbar.normal.bg = '#0a0909'
      c.colors.statusbar.insert.fg = '#0a0909'
      c.colors.statusbar.insert.bg = '#9a8052'
      c.colors.statusbar.command.fg = '#c7bfb1'
      c.colors.statusbar.command.bg = '#0a0909'
      c.colors.statusbar.url.fg = '#9a8052'
      c.colors.statusbar.url.success.http.fg = '#9a8052'
      c.colors.statusbar.url.success.https.fg = '#c7bfb1'

      c.colors.tabs.bar.bg = '#0a0909'
      c.colors.tabs.odd.fg = '#7c756d'
      c.colors.tabs.odd.bg = '#0a0909'
      c.colors.tabs.even.fg = '#7c756d'
      c.colors.tabs.even.bg = '#11100f'
      c.colors.tabs.selected.odd.fg = '#f1eadb'
      c.colors.tabs.selected.odd.bg = '#4a1111'
      c.colors.tabs.selected.even.fg = '#f1eadb'
      c.colors.tabs.selected.even.bg = '#4a1111'

      c.colors.hints.fg = '#f1eadb'
      c.colors.hints.bg = '#8a1f1f'
      c.hints.border = '1px solid #4a1111'

      c.tabs.padding = {'top': 3, 'bottom': 3, 'left': 6, 'right': 5}
      c.statusbar.padding = {'top': 3, 'bottom': 3, 'left': 6, 'right': 6}
    '';
  };

  programs.mpv = {
    enable = true;
    config = {
      hwdec = "auto-safe";
      vo = "gpu-next";
      keep-open = "yes";
      save-position-on-quit = "yes";
      osc = "no";
    };
  };

  programs.emacs = {
    enable = true;
    package = pkgs.emacs;
    extraConfig = ''
      (setq inhibit-startup-screen t
            initial-scratch-message nil
            ring-bell-function 'ignore
            make-backup-files nil
            auto-save-default nil
            visible-bell nil
            use-dialog-box nil)

      (menu-bar-mode -1)
      (tool-bar-mode -1)
      (scroll-bar-mode -1)
      (blink-cursor-mode -1)

      (set-face-attribute 'default nil
                          :family "Terminus"
                          :height 110
                          :foreground "#c7bfb1"
                          :background "#0a0909")
      (set-face-attribute 'cursor nil :background "#8a1f1f")
      (set-face-attribute 'fringe nil :background "#0a0909")
      (set-face-attribute 'region nil :foreground "#f1eadb" :background "#4a1111")
      (set-face-attribute 'mode-line nil
                          :foreground "#c7bfb1"
                          :background "#181514"
                          :box nil)
      (set-face-attribute 'mode-line-inactive nil
                          :foreground "#7c756d"
                          :background "#0a0909"
                          :box nil)
      (set-face-attribute 'minibuffer-prompt nil
                          :foreground "#9a8052"
                          :weight 'normal)
      (set-face-attribute 'font-lock-comment-face nil :foreground "#65604a")
      (set-face-attribute 'font-lock-keyword-face nil :foreground "#9a8052")
      (set-face-attribute 'font-lock-string-face nil :foreground "#a66b62")
      (set-face-attribute 'font-lock-function-name-face nil :foreground "#c7bfb1")
      (set-face-attribute 'font-lock-variable-name-face nil :foreground "#b89070")

      (setq-default mode-line-format
                    '(" " mode-line-buffer-identification
                      "  " mode-line-position "  " mode-name " "))

      (setq dired-listing-switches "-alh --group-directories-first"
            dired-kill-when-opening-new-dired-buffer t
            doc-view-resolution 110)

      (global-display-line-numbers-mode -1)
      (column-number-mode -1)
      (size-indication-mode -1)
    '';
  };

  services.emacs = {
    enable = true;
    client.enable = true;
    defaultEditor = true;
    startWithUserSession = "graphical";
  };
}

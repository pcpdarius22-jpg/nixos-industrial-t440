# v1.1 audit changes

This release is the corrected pre-install build.

1. Deferred page-menu `GotoPage` calls with `Schedule`.
2. Corrected `SendToModule` target from generic `FvwmButtons` to alias `FvwmTopBar`.
3. Replaced page-label 500 ms polling with `FvwmEvent new_page`.
4. Added `xss-lock` with `/run/wrappers/bin/slock`.
5. Restored FVWM window decoration ownership for qutebrowser on X11.
6. Enabled Home Manager's proper Emacs default editor wrapper and graphical daemon.
7. Added `emacsclient -a emacs` fallback for FVWM/qutebrowser actions.
8. Replaced the uncertain Terminus `☥` glyph with a font-safe `V`.
9. Restored non-autostarting REAPER/Wine/RetroArch/Transmission/senpai functionality.
10. Added safe `nix-test` and `nix-apply` helpers.

Still requires a real T440 `nix flake check` and `nixos-rebuild test` before switch.

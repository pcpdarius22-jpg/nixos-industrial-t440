#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "1/2  Checking flake..."
nix flake check

echo "2/2  Activating a temporary test generation..."
sudo nixos-rebuild test --flake .#thinkpad

cat <<'EOF'

Temporary test generation activated.

Before leaving your current desktop:
  touch ~/.disable-gui

Then exit the current graphical session, log in on tty1 and run:
  startx

If FVWM works correctly:
  cd back into this config
  nix-apply
  rm -f ~/.disable-gui
  sudo reboot

If it does not work, exit FVWM. You will be back at tty1 and the current
boot generation is still available.

EOF

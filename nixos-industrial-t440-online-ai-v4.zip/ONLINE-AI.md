# Online AI configuration agent

This version intentionally has no local LLM and no Ollama service.

## Codex CLI

The `nix-ai` wrapper runs Codex from the NixOS repository.

Set the API key only for the current shell:

    export OPENAI_API_KEY='your-key'
    nix-ai

Do NOT put the key into `configuration.nix`, `home.nix`, `flake.nix`,
`AGENTS.md`, Git, or any Nix store path.

## Safety workflow

    nix-ai
      -> inspect/edit
      -> nix flake check
      -> nix-ai-check
      -> review changes
      -> nixos-rebuild switch

The agent should ask before destructive hardware/boot/filesystem changes.

## API vs ChatGPT

API-key authentication uses OpenAI's API and is billed separately from a
ChatGPT subscription. Codex can also authenticate through ChatGPT, but this
build is deliberately configured for the API-key route you requested.

{ pkgs, ... }:
{
  # Codex CLI is intentionally user-invoked; no AI daemon runs in the background.
  environment.systemPackages = with pkgs; [
    nodejs
    git
    ripgrep
    fd
    jq
  ];
}
import Quickshell
import Quickshell.Wayland
import QtQuick

ShellRoot {
    property bool night: false
    property bool topOpen: false
    property bool leftOpen: false
    property bool rightOpen: false
    property bool bottomOpen: false
    property string timeText: Qt.formatTime(new Date(), "HH:mm")

    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: timeText = Qt.formatTime(new Date(), "HH:mm")
    }

    PanelWindow {
        id: bar
        anchors { top: true; left: true; right: true }
        implicitHeight: 44
        exclusiveZone: 44
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Top

        Rectangle {
            anchors.fill: parent
            color: night ? "#0b0c0d" : "#ebe7df"
            border.color: night ? "#34383b" : "#bdb7ac"
            border.width: 1

            Text {
                anchors.left: parent.left
                anchors.leftMargin: 18
                anchors.verticalCenter: parent.verticalCenter
                text: "0 / 7"
                color: night ? "#e7e1d6" : "#18191a"
                font.family: "monospace"
                font.pixelSize: 17
            }

            Text {
                anchors.centerIn: parent
                text: timeText
                color: night ? "#e7e1d6" : "#18191a"
                font.family: "monospace"
                font.pixelSize: 18
            }

            Text {
                anchors.right: parent.right
                anchors.rightMargin: 18
                anchors.verticalCenter: parent.verticalCenter
                text: "VOL 45%   BAT 78%   RAM 1.3G   CPU 2%"
                color: night ? "#aaa69e" : "#56524b"
                font.family: "monospace"
                font.pixelSize: 10
            }

            Rectangle {
                anchors.horizontalCenter: parent.horizontalCenter
                anchors.bottom: parent.bottom
                width: topOpen ? 42 : 12
                height: 2
                color: "#d66b2c"
                Behavior on width { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }
            }
        }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onEntered: topOpen = true
            onExited: topOpen = false
            onClicked: night = !night
        }
    }

    PanelWindow {
        anchors { top: true; left: true; right: true }
        implicitHeight: topOpen ? 150 : 2
        exclusiveZone: 0
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        Rectangle {
            anchors { top: parent.top; left: parent.left; right: parent.right }
            height: parent.height
            color: night ? "#101214f2" : "#eeeae2f2"
            border.color: night ? "#45494c" : "#c6c0b5"
            border.width: 1
            visible: topOpen
            opacity: topOpen ? 1 : 0
            Behavior on opacity { NumberAnimation { duration: 160 } }

            Row {
                anchors.centerIn: parent
                spacing: 36
                Text { text: "14:23\nWEDNESDAY\nMAY 15"; color: night ? "#e7e1d6" : "#18191a"; font.family: "monospace"; font.pixelSize: 13 }
                Text { text: "VOL 45%\nBAT 78%\nRAM 1.3G\nCPU 2%"; color: night ? "#aaa69e" : "#56524b"; font.family: "monospace"; font.pixelSize: 11 }
                Text { text: "WIFI  •  BLUETOOTH\nNIGHT LIGHT  •  LOCK\nPOWER"; color: night ? "#aaa69e" : "#56524b"; font.family: "monospace"; font.pixelSize: 11 }
            }
        }
    }

    PanelWindow {
        anchors { left: true; top: true; bottom: true }
        implicitWidth: leftOpen ? 210 : 3
        exclusiveZone: 0
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        MouseArea { anchors.fill: parent; hoverEnabled: true; onEntered: leftOpen = true; onExited: leftOpen = false }
        Rectangle {
            anchors.fill: parent
            visible: leftOpen
            color: night ? "#0d0f10f5" : "#ece8e0f5"
            border.color: night ? "#3b3f42" : "#c4beb3"
            border.width: 1
            Column {
                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter }
                spacing: 7
                Text { text: "WORKSPACES"; leftPadding: 18; color: night ? "#e7e1d6" : "#18191a"; font.family: "monospace"; font.pixelSize: 11 }
                Repeater {
                    model: ["0 / 7   WORK", "1 / 7   WEB", "2 / 7   MUSIC", "3 / 7   READ", "4 / 7   CODE", "5 / 7   COMM", "6 / 7   FILES"]
                    delegate: Text { text: modelData; leftPadding: 18; color: index === 0 ? "#d66b2c" : (night ? "#aaa69e" : "#56524b"); font.family: "monospace"; font.pixelSize: 11 }
                }
            }
        }
    }

    PanelWindow {
        anchors { right: true; top: true; bottom: true }
        implicitWidth: rightOpen ? 290 : 3
        exclusiveZone: 0
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        MouseArea { anchors.fill: parent; hoverEnabled: true; onEntered: rightOpen = true; onExited: rightOpen = false }
        Rectangle {
            anchors.fill: parent
            visible: rightOpen
            color: night ? "#0d0f10f5" : "#ece8e0f5"
            border.color: night ? "#3b3f42" : "#c4beb3"
            border.width: 1
            Column {
                anchors { left: parent.left; right: parent.right; verticalCenter: parent.verticalCenter; margins: 22 }
                spacing: 18
                Text { text: "CONTEXT"; color: night ? "#e7e1d6" : "#18191a"; font.family: "monospace"; font.pixelSize: 11 }
                Text { text: "AUDIO\n\nOUTPUT     PipeWire\nMASTER     -9.2 LU\nARDOUR     -8.6 LU\nSYSTEM     -31.2 LU"; color: night ? "#aaa69e" : "#56524b"; font.family: "monospace"; font.pixelSize: 11 }
                Rectangle { width: parent.width; height: 1; color: night ? "#34383b" : "#c5bfb5" }
                Text { text: "ROUTING   DEVICES   MIDI   PLUGINS"; color: "#d66b2c"; font.family: "monospace"; font.pixelSize: 9 }
            }
        }
    }

    PanelWindow {
        anchors { bottom: true; left: true; right: true }
        implicitHeight: bottomOpen ? 88 : 3
        exclusiveZone: 0
        color: "transparent"
        WlrLayershell.layer: WlrLayer.Overlay
        MouseArea { anchors.fill: parent; hoverEnabled: true; onEntered: bottomOpen = true; onExited: bottomOpen = false }
        Rectangle {
            anchors.fill: parent
            visible: bottomOpen
            color: night ? "#0d0f10f5" : "#ece8e0f5"
            border.color: night ? "#3b3f42" : "#c4beb3"
            border.width: 1
            Text {
                anchors.centerIn: parent
                text: "SEARCH"
                color: night ? "#e7e1d6" : "#18191a"
                font.family: "monospace"
                font.pixelSize: 14
            }
            MouseArea { anchors.fill: parent; onClicked: Quickshell.execDetached(["fuzzel"]) }
        }
    }
}

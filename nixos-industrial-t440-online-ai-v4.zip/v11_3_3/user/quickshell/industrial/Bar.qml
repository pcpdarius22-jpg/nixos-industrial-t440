// Kept as a placeholder for future extracted widgets. The first version keeps
// the UI in one file so it is easy to modify while the system is being tested.

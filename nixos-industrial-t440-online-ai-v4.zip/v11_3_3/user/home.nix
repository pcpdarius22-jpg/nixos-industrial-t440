{ config, pkgs, ... }:
{
  home.username = "sloth";
  home.homeDirectory = "/home/sloth";
  home.stateVersion = "24.11";
  home.sessionPath = [ "$HOME/.local/bin" ];
  home.sessionVariables = {
    XDG_CONFIG_HOME = "$HOME/.config";
    TERMINAL = "foot";
    EDITOR = "nvim";
    VISUAL = "nvim";
  };

  imports = [ ./apps.nix ];

  home.file."AGENTS.md".source = ../AGENTS.md;
  home.file.".config/niri/config.kdl".source = ./niri/config.kdl;
  home.file.".config/quickshell/industrial/shell.qml".source = ./quickshell/industrial/shell.qml;

  home.file.".config/foot/foot.ini".text = ''
    font=monospace:size=10
    pad=8x8
    dpi-aware=no
    [colors]
    background=0b0c0d
    foreground=e7e1d6
    selection-background=34383b
    selection-foreground=e7e1d6
    regular0=0b0c0d
    regular1=9d4c35
    regular2=899b7d
    regular3=c2a66b
    regular4=6d8495
    regular5=8c788f
    regular6=789a98
    regular7=d7d1c5
  '';

  home.file.".config/fuzzel/fuzzel.ini".text = ''
    [main]
    terminal=foot
    font=monospace:size=11
    prompt=>
    width=55
    lines=10
    horizontal-pad=18
    vertical-pad=12
    inner-pad=8
    [colors]
    background=0b0c0df2
    text=e7e1d6ff
    match=d66b2cff
    selection=34383bff
    selection-text=e7e1d6ff
    border=45494cff
    [border]
    width=1
    radius=0
  '';

  home.file.".config/industrial-wallpaper/day.png".source = ./wallpaper/773.jpg;
  home.file.".config/industrial-wallpaper/night.png".source = ./wallpaper/773.jpg;

  programs.home-manager.enable = true;

  home.file.".local/bin/nix-ai" = {
    executable = true;
    text = ''
      #!/usr/bin/env bash
      set -euo pipefail
      cd "''${NIXOS_CONFIG_DIR:-$HOME/nixos}"
      if [ -z "''${OPENAI_API_KEY:-}" ]; then
        echo "OPENAI_API_KEY is not set."
        echo "Set it for this session, then run nix-ai again."
        echo "Example: export OPENAI_API_KEY='...'"
        exit 1
      fi
      exec codex "$@"
    '';
  };

  home.file.".local/bin/nix-ai-check" = {
    executable = true;
    text = ''
      #!/usr/bin/env bash
      set -euo pipefail
      cd "''${NIXOS_CONFIG_DIR:-$HOME/nixos}"
      nix flake check
      nixos-rebuild dry-build --flake .#t440
    '';
  };

}

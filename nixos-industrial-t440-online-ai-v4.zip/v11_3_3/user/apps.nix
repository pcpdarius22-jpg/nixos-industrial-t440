{ pkgs, ... }:
{
  home.packages = with pkgs; [
    foot fuzzel firefox
    yazi btop fastfetch fzf fd ripgrep zoxide jq gawk lazygit
    imv zathura foliate mpv yt-dlp wl-clipboard
    brightnessctl playerctl grim slurp swaylock swayidle
    pulsemixer qpwgraph pavucontrol
    ardour reaper wineWow64Packages.stable winetricks
    sox ffmpeg libnotify
  ];

  programs.neovim = {
    enable = true;
    defaultEditor = true;
    viAlias = true;
    vimAlias = true;
    initLua = ''
      vim.opt.number = true
      vim.opt.relativenumber = false
      vim.opt.termguicolors = true
      vim.opt.signcolumn = "yes"
      vim.opt.tabstop = 2
      vim.opt.shiftwidth = 2
      vim.opt.expandtab = true
      vim.opt.smartindent = true
      vim.opt.ignorecase = true
      vim.opt.smartcase = true
    '';
  };

  programs.mpv.enable = true;

  # OpenAI Codex CLI: a local coding/configuration agent. It starts in the
  # NixOS repo via the nix-agent helper and remains interactive by default.
  programs.codex.enable = true;
  programs.codex.context = builtins.toString ../AGENTS.md;
  programs.codex.profiles.default = {
    approval_policy = "on-request";
    sandbox_mode = "workspace-write";
  };

  programs.bash = {
    enable = true;
    bashrcExtra = ''
      export TERMINAL=foot
      export EDITOR=nvim
      export VISUAL=nvim
      export NIXOS_CONFIG_DIR="$HOME/nixos-industrial-t440"
    '';
  };

  home.file.".local/bin/nix-agent" = {
    executable = true;
    text = ''
      #!/usr/bin/env bash
      set -euo pipefail
      DIR="${HOME}/nixos-industrial-t440"
      if [ ! -f "$DIR/flake.nix" ]; then
        echo "NixOS config not found at $DIR" >&2
        exit 1
      fi
      cd "$DIR"
      exec codex "$@"
    '';
  };

  home.file.".local/bin/nix-check" = {
    executable = true;
    text = ''
      #!/usr/bin/env bash
      set -euo pipefail
      cd "${HOME}/nixos-industrial-t440"
      nix flake check
      niri validate "$HOME/.config/niri/config.kdl" 2>/dev/null || true
    '';
  };
}

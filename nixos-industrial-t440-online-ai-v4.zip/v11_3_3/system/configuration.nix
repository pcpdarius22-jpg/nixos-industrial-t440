{ pkgs, lib, ... }:
{
  imports = [ ./hardware-configuration.nix ];

  boot.loader.systemd-boot = { enable = true; configurationLimit = 4; editor = true; };
  boot.loader.efi.canTouchEfiVariables = true;
  boot.kernelParams = [ "threadirqs" "snd_hda_intel.power_save=1" ];

  networking.hostName = "thinkpad";
  networking.networkmanager.enable = true;
  networking.firewall.enable = true;
  time.timeZone = "Europe/Bucharest";
  i18n.defaultLocale = "en_US.UTF-8";
  console.keyMap = "us";

  nix.settings = {
    experimental-features = [ "nix-command" "flakes" ];
    auto-optimise-store = true;
    builders-use-substitutes = true;
  };
  nixpkgs.config.allowUnfree = true;

  # T440 Haswell graphics.
  environment.variables.LIBVA_DRIVER_NAME = "i965";
  hardware.graphics = {
    enable = true;
    enable32Bit = true;
    extraPackages = with pkgs; [ intel-vaapi-driver libvdpau-va-gl ];
  };

  # 12 GiB RAM: keep swap available without creating a huge disk swap.
  # 3 GiB compressed zram handles bursts cheaply; 4 GiB disk swap is the
  # fallback for genuinely heavy memory pressure. Hardware swap from a
  # previous install is deliberately overridden to avoid stacking swaps.
  swapDevices = lib.mkForce [
    { device = "/var/lib/swapfile"; size = 4 * 1024; }
  ];
  zramSwap = {
    enable = true;
    memoryPercent = 25;
    priority = 100;
  };
  systemd.oomd.enable = true;
  boot.kernel.sysctl."vm.swappiness" = 10;

  services.tlp = {
    enable = true;
    settings = {
      CPU_SCALING_GOVERNOR_ON_AC = "performance";
      CPU_SCALING_GOVERNOR_ON_BAT = "powersave";
      CPU_ENERGY_PERF_POLICY_ON_AC = "performance";
      CPU_ENERGY_PERF_POLICY_ON_BAT = "power";
      START_CHARGE_THRESH_BAT0 = 40;
      STOP_CHARGE_THRESH_BAT0 = 80;
    };
  };
  services.thermald.enable = true;
  services.fstrim.enable = true;

  hardware.bluetooth = { enable = true; powerOnBoot = true; };
  services.blueman.enable = true;
  security.polkit.enable = true;
  security.rtkit.enable = true;

  programs.niri.enable = true;

  fonts.packages = with pkgs; [ nerd-fonts.symbols-only ];

  environment.systemPackages = with pkgs; [
    git vim curl wget unzip jq libva-utils
    xwayland-satellite swaybg
  ];

  users.users.sloth = {
    isNormalUser = true;
    shell = pkgs.bashInteractive;
    extraGroups = [ "wheel" "networkmanager" "audio" "video" ];
  };

  services.greetd = {
    enable = true;
    settings.default_session = {
      command = "${pkgs.niri}/bin/niri-session";
      user = "sloth";
    };
  };

  system.stateVersion = "24.11";
}

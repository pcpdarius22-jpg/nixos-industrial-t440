# Industrial T440 NixOS install

## 1. Install a normal NixOS base

Use the NixOS graphical installer. Do not manually create a giant swapfile.
After installation, boot into the new system and make sure networking works.

## 2. Put this repository in your home directory

Extract it as:

    ~/nixos-industrial-t440

The configured user is `sloth`. If your installed username is different, change
`sloth` consistently in `flake.nix`, `system/configuration.nix`, and
`user/home.nix` before building.

## 3. Generate the real hardware configuration

From this repo:

    sudo nixos-generate-config --show-hardware-config > system/hardware-configuration.nix

This is important: never reuse the old disk UUIDs from another installation.

## 4. Prepare and test

    ./prepare.sh
    nix flake check
    sudo nixos-rebuild test --flake .#thinkpad

If the test boots correctly, switch:

    sudo nixos-rebuild switch --flake .#thinkpad

Reboot.

## AI configuration agent

After signing into Codex with ChatGPT:

    nix-agent

Codex will start in this repository and read `AGENTS.md`. It is intentionally
interactive rather than auto-applying changes. Ask it to edit, then have it
run `nix-check` and prefer `nixos-rebuild test` before switching.

## Swap

The configuration deliberately overrides old swap entries and uses:

- 25% zram (~3 GiB with 12 GiB RAM)
- 4 GiB disk swapfile
- vm.swappiness = 10

This avoids the oversized swap setup from the older configuration while still
leaving enough headroom for browsers, Wine and music projects.

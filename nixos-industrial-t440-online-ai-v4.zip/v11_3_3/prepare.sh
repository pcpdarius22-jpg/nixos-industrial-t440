#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="${1:-}"
DST="$ROOT/system/hardware-configuration.nix"

if [ -n "$SRC" ]; then
  [ -f "$SRC/system/hardware-configuration.nix" ] || { echo "No hardware-configuration.nix in $SRC/system" >&2; exit 1; }
  cp -f "$SRC/system/hardware-configuration.nix" "$DST"
elif [ -f /etc/nixos/hardware-configuration.nix ]; then
  cp -f /etc/nixos/hardware-configuration.nix "$DST"
else
  echo "Generate hardware config on this T440 first:" >&2
  echo "nixos-generate-config --show-hardware-config > system/hardware-configuration.nix" >&2
  exit 1
fi

# The main configuration intentionally overrides old hardware swap entries with
# a 4 GiB swapfile + 25% zram, suitable for the current 12 GiB RAM machine.
cd "$ROOT"
printf '\nPrepared hardware configuration. Swap policy: 4 GiB disk + 25%% zram.\n'
printf 'Run: nix flake check\n'
printf 'Then: sudo nixos-rebuild test --flake .#thinkpad\n'

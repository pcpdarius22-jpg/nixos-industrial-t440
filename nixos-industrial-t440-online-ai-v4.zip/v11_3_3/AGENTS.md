# Local NixOS configuration agent instructions

You are modifying a real ThinkPad T440 NixOS configuration.

Goals:
- Keep the system light and reliable for 12 GiB RAM and Intel Haswell HD 4400.
- Use niri + Quickshell for the industrial minimal-maximalist UI.
- Preserve day/night theme switching and the visible 0/7 workspace indicator.
- Prioritize daily usability, music production, browser/video, reading, coding and file work.
- Avoid pointless daemons, duplicate services, docks and decorative bloat.
- Prefer declarative Nix/Home Manager changes.

Safety:
- Never partition, format, wipe, or delete user data without explicit approval.
- Never replace hardware-configuration.nix with guessed UUIDs.
- Before applying a change, run `nix flake check` when possible.
- Prefer `nixos-rebuild test` before `nixos-rebuild switch`.
- If a change could prevent boot, explain the risk and ask first.
- Keep rollback possible through NixOS generations.

Hardware baseline:
- ThinkPad T440
- Intel i5-4300U / Haswell
- Intel HD 4400
- 12 GiB RAM
- Linux audio via PipeWire/JACK

UI direction:
- industrial minimal maximalism
- restrained neutral palette with small orange/amber machine-like accents
- thin technical lines, sparse typography, functional information
- no product logos, copied product artwork, or brand imagery
- animations should feel mechanical, precise and fluid rather than flashy

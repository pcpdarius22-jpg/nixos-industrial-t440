# T440 NixOS configuration agent

Target: ThinkPad T440, 12 GB RAM, Intel Haswell/HD 4400.
Desktop: Niri + Quickshell, industrial minimal/maximalist instrument-like UI.
Music production: Ardour, REAPER, Wine, PipeWire/JACK.

Rules:
- Keep the system lightweight, fluid and reliable.
- No dock, permanent app labels, or pointless widgets.
- Keep the idle desktop clean: workspace counter + clock only.
- Seven workspaces and the animated 0/7-style counter.
- Never partition disks, format filesystems, change filesystem UUIDs, or alter bootloader settings without explicit approval.
- Never remove the current working NixOS generation.
- Prefer `nix flake check` and `nixos-rebuild dry-build` before switching.
- Prefer reversible declarative changes.
- Do not add large software stacks without a reason.
- Do not make aggressive PipeWire latency changes during normal desktop use.
- Ask before destructive operations.
- AI is online-only. Do not add Ollama, local LLMs, or background AI services.
- Keep API credentials out of Nix files, Git, Home Manager, and the repository.
- Use `OPENAI_API_KEY` only through the user's shell/session or a proper secret manager.

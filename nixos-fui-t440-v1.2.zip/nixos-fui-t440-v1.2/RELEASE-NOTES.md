# FUI v1.2 — interactive-field wallpaper pass

v1.2 keeps the v1.1 guarded install/rendering architecture and turns the
wallpaper into a real low-overhead interaction surface rather than a video or
shader wallpaper.

## What changed

- Added `ReactiveWallpaper.qml`, `SignalNode.qml` and `RoutePulse.qml`.
- The approved static wallpaper asset remains the exact visual base. Dynamic layers
  are drawn above it; disabling motion freezes the reactive field without changing
  the underlying wallpaper image.
- Pointer proximity drives a few-pixel two-plane parallax field.
- Dragging exposed wallpaper with the pointer/TrackPoint grabs the network plane
  and snaps it back on release.
- Five subtle signal nodes map directly to the real named Niri workspaces.
- Network route pulses are conditional on real live traffic from the existing
  telemetry stream.
- MEDIA resonance is conditional on real MPRIS playback.
- CPU >=75% and low discharging battery alter small instrument markers only.
- `Super+Shift+W` and Settings can disable wallpaper motion immediately; Settings
  can also disable wallpaper interaction.

## Performance boundary

The implementation intentionally avoids full-screen Canvas animation, blur,
ShaderEffect, particle systems and video playback. Static routes use Qt Quick
Shapes; continuous animations are limited to tiny objects and are conditional
where possible. This is specifically meant to keep the Haswell iGPU path sane.

## v1.1 reliability foundation retained


v1.1 keeps the approved 1600×900 visual composition and hardens the things that
commonly make automated rices render differently or fail on another machine.

## Font and visual determinism

- JetBrains Mono, Noto and Noto Color Emoji are NixOS generation dependencies.
- Explicit `fonts.fontconfig.defaultFonts` are declared for monospace, sans,
  serif and emoji.
- `fui-preflight` and the live runtime gate use `fc-match` to verify the actual
  family resolution rather than trusting package installation alone.
- Adwaita dark/toolkit and cursor fallbacks are explicitly defined without a
  third-party theme engine.
- Persistent device-rail glyphs were moved from Unicode-symbol dependence to
  custom Canvas vectors.
- Reusable Quickshell components now receive the reference output scale factor,
  while the 1600×900 T440 remains exactly scale 1.

## Safer graphical startup

- Niri now starts one `fui-bootstrap` process instead of racing Quickshell,
  notifications, idle handling and the staged windows independently.
- The bootstrap reads `niri msg --json outputs` and requires the target logical
  canvas to be exactly 1600×900 at scale 1.
- Quickshell must answer its real IPC `ping` before home windows or secondary
  helpers are started.
- Failure opens a diagnostic Foot window while leaving Niri/recovery keybinds
  alive; it does not present a half-broken desktop.
- Successful startup records the exact active NixOS generation. `scripts/apply`
  refuses to make anything permanent unless that exact generation passed the
  runtime gate.

## Claude review items addressed

- The distributed `host-base/` stays empty/ignored. A root-level
  `host-base-placeholder.nix` gives a clear pre-install evaluation error, while
  `install.sh` replaces `host-base/` with the real `/etc/nixos` tree. This avoids
  accidentally tracking a user's machine configuration after installation.
- Launcher default changed from open to closed. `Super+D` reproduces the open
  reference state.
- Local IP discovery is cached for 10 seconds / interface changes instead of
  spawning `ip` once per second.
- The seeded personal/mock-up note text was removed; a new notes file starts
  with only `# NOTES`.
- Ardour 9 is unconditional in the system and `fui-music` runtime dependencies;
  REAPER remains optional.

## Integrity and test flow

- Added package-owned SHA-256 source manifest verification to `scripts/check`.
- Installer still activates only `nixos-rebuild test`.
- No `.bash_profile`, `environment.loginShellInit`, temporary `nix shell`
  compositor, manual `DISPLAY` or hand-started Xwayland path was introduced.
- Foot/Niri config parsing remains checked using the pinned generation before
  graphical testing.

No document in this package claims physical-hardware or pixel-rendering success
before the live T440 acceptance pass. See `docs/BUILD-VERIFICATION.md`.

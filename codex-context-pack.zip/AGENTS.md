# AGENTS.md — Niri Industrial T440

This repository is a personal NixOS/Niri desktop project for a Lenovo ThinkPad T440.

Before changing anything, read:
- `PROJECT.md`
- `README.md`
- `docs/DESIGN.md`
- `docs/target-ui-reference.jpeg`

The image `docs/target-ui-reference.jpeg` is the PRIMARY visual reference. Treat it as the target, not as loose inspiration.

## Product goal

Build a very lightweight, dark, industrial, instrument-panel-like Niri desktop for the ThinkPad T440.

At rest, the desktop must be almost empty. The visual identity should come from:
- near-black / graphite background
- thin structural lines
- compact monospace text
- muted off-white labels
- burnt-orange accent used sparingly for state/focus
- wireframe / technical-grid landscape wallpaper
- square corners
- precise spacing
- minimal persistent information

Do NOT drift toward:
- paper-white themes
- rounded cards/pills
- glassmorphism
- generic cyberpunk/neon UI
- gamer HUD aesthetics
- large widgets
- blur-heavy effects
- decorative clutter

## Exact desktop concept

Always visible:
- thin top instrumentation bar hugging the top edge
- left: workspace position shown as `0/7`, then a subtle dotted/technical line
- center: clock, e.g. `14:23`, with a tiny orange center-axis/crosshair accent
- right: compact system indicators only
- wallpaper visible over almost the whole screen

Hidden until interaction:
- hover top edge -> system overview panel
- hover left edge -> workspace rail
- hover right edge -> contextual panel
- hover bottom edge -> launcher panel

Panels should slide/reveal from edges and disappear when no longer needed.

## Workspaces

Use seven named workspaces:
0. work
1. web
2. music
3. reader
4. code
5. comm
6. files

Niri should still behave like Niri; do not force Sway's exact tiling model onto it.

## Top panel

The top edge panel should resemble the reference:
- instrument cells for audio, battery, network, Bluetooth, brightness, date/system state
- compact, line-based visuals
- no giant cards
- square corners
- thin separators
- orange only for meaningful active/focus state

The persistent 30px-ish bar should be much quieter than the expanded panel.

## Left panel

Workspace rail:
- narrow
- seven rows
- current workspace highlighted with orange and a small directional/edge marker
- index and short uppercase workspace name
- minimal borders

## Right panel

Context-sensitive panel:
- show active app/window context
- for music software later, it may show audio-related context
- v1 can remain simple until the base session is stable
- do not fake app-specific data

## Bottom panel

Launcher:
- search/launcher field
- compact launch targets such as Apps, Files, Commands, Web, Music, Calc
- no large dock
- no permanent app icons on the desktop

## Animation

Subtle and short only:
- panels slide from edges
- workspace indicator can move
- clock digit transitions may slide vertically
- wallpaper may later react very subtly to workspace changes/music/system state

Avoid:
- bounce
- long easing
- constant motion
- expensive visual effects

## Day/night

The long-term design includes:
- dark mode as the primary target
- optional paper/light day mode based on the same technical drawing language
- automatic sunset/sunrise switching may be added later

Do not implement this before the base dark session is stable.

## Performance constraints

Target machine: ThinkPad T440 with Intel integrated graphics.

Keep idle overhead low.
Prefer:
- native Wayland
- event-driven Niri IPC
- simple QtQuick geometry
- low-frequency polling only where unavoidable
- no blur
- no shadows
- no unnecessary daemons

Before adding a dependency, ask whether it needs to exist permanently.

## NixOS safety rules

Never recreate the old unsafe `preview.sh` workflow that launched a temporary Niri/Mesa stack from `nix shell` on the real TTY.

Niri must come from the installed/tested NixOS generation.

The repository overlays the machine's existing `/etc/nixos/configuration.nix`. Do not invent:
- disk UUIDs
- boot configuration
- hardware configuration
- users/passwords
- system state version

Do not permanently switch a system change automatically.

Workflow:
1. edit
2. validate
3. `nixos-rebuild test`
4. visually inspect
5. refine
6. only after explicit approval use permanent `switch`

## Live design workflow

Once the Niri session is running:
- edit `niri/config.kdl`
- edit `quickshell/shell.qml`
- rely on supported live reload where possible
- visually inspect on the actual T440 display
- make small diffs
- iterate from user feedback

The user wants to say things like:
- "thinner"
- "move this left"
- "remove that"
- "too bright"
- "not like the mockup"
- "keep the old version of that part"

Respond with focused edits rather than redesigning unrelated parts.

## Codex behavior

Before editing:
1. inspect the relevant files
2. read the design docs and target image
3. identify the smallest change
4. preserve working behavior

After editing, report:
- files changed
- what changed visually/functionally
- whether live reload is enough
- whether a Nix rebuild is required
- how to undo the specific experiment

Do not do unrelated cleanup during visual iteration.

## Current priority

Match the provided target reference more closely before adding extra features.

Order:
1. reliable Niri base
2. exact top bar proportions/spacing
3. edge panel geometry
4. workspace rail
5. bottom launcher
6. right context panel
7. refined wallpaper
8. animations
9. optional day/night mode
10. deeper app-specific context

The reference image is more important than inventing new UI ideas.

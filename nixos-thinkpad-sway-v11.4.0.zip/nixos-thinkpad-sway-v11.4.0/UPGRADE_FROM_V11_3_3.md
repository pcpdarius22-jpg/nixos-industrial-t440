# Upgrade from v11.3.3 to v11.4.0

Keep your current working generation until v11.4.0 has been tested.

From the v11.4.0 repository on the T440:

```sh
touch ~/.disable-gui
bash ./prepare.sh
nix flake check
sudo nixos-rebuild test --flake .#thinkpad
rice-doctor
```

Your existing `~/.local/share/rice/wallpaper.jpg` is preserved. The old webpage
monochrome stylesheet is no longer loaded and is removed by `theme-sync`.

Test Sway manually, then run `nix-apply` only when everything is good.

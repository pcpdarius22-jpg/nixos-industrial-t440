# Put v11.4.0 on GitHub

This ZIP is a complete repository tree. To replace/update the existing repo,
upload the **contents** of the `nixos-thinkpad-sway-v11.4.0` folder so
`flake.nix`, `README.md`, `system/` and `user/` remain at the repository root.

If you are doing it from a git checkout instead:

```sh
git add -A
git commit -m "Release v11.4.0"
git push
```

On the T440 after pulling the release, follow `QUICKSTART.md` and test before
running the permanent switch.

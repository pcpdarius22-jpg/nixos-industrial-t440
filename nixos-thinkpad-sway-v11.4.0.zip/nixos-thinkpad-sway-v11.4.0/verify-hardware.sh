#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
HW="${1:-$ROOT/system/hardware-configuration.nix}"

[ -f "$HW" ] || { echo "Missing hardware config: $HW" >&2; exit 1; }
if grep -q 'This is a safety placeholder' "$HW"; then
  echo "Refusing placeholder hardware configuration: $HW" >&2
  exit 1
fi
if ! grep -q 'fileSystems\."/"' "$HW"; then
  echo "Hardware config has no root filesystem declaration: $HW" >&2
  exit 1
fi

mapfile -t paths < <(grep -oE '/dev/disk/by-uuid/[A-Za-z0-9-]+' "$HW" | sort -u)
if [ "${#paths[@]}" -eq 0 ]; then
  echo "No /dev/disk/by-uuid entries found in $HW; refusing to guess." >&2
  exit 1
fi

missing=0
for path in "${paths[@]}"; do
  if [ ! -e "$path" ]; then
    echo "Hardware UUID is not present on this machine: $path" >&2
    missing=1
  fi
done

if [ "$missing" -ne 0 ]; then
  echo "hardware-configuration.nix does not match the currently attached storage." >&2
  echo "Refresh it from /etc/nixos on this T440 before rebuilding." >&2
  exit 1
fi

printf 'hardware UUID check: OK (%d device path%s)\n' \
  "${#paths[@]}" "$([ "${#paths[@]}" -eq 1 ] && printf '' || printf 's')"

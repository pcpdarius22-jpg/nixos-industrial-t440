# Changelog

## v11.4.0

- Add storage UUID verification before helper-driven rebuilds.
- Make `nix-apply` perform a temporary test before switching.
- Remove stale automatic discovery of old v10/v11 configuration trees.
- Add smart non-overlapping placement for different floating applications.
- Keep same-app windows free to cascade.
- Restore native website colors in qutebrowser while preserving monochrome UI.
- Add NixOS Flatpak support and `flatpak-setup` for per-user Flathub.
- Fix weighted dual-battery percentage calculation.
- Remove broken hard dependency on missing `773.jpg` and license file.
- Preserve an existing wallpaper on upgrade; create a dark fallback on fresh install.
- Align RAM/Waybar documentation with the actual T440/current generated UI.
- Supervise the window organizer through `rice-session` to avoid duplicates.

## v11.3.3

Reference release that established the current monochrome application chrome,
frameless Sway geometry, PxPlus IBM VGA 8x16 font and native Waybar edge UI.

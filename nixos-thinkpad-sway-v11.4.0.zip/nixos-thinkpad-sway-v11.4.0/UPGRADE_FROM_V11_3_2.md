# Upgrade from v11.3.2 to v11.4.0

Use the same safe path as every v11.4.0 migration. On the T440:

```sh
touch ~/.disable-gui
bash ./prepare.sh
nix flake check
sudo nixos-rebuild test --flake .#thinkpad
rice-doctor
```

If `/etc/nixos/hardware-configuration.nix` is unavailable, pass the old config
folder explicitly to `prepare.sh`. Do not switch until the manual Sway test is good.

# Upgrade from v11.2 to v11.4.0

v11.4.0 no longer auto-selects old test folders. Prefer the real machine config
from `/etc/nixos`. If that is unavailable, explicitly provide the known-good old
folder:

```sh
bash ./prepare.sh /path/to/v11.2
```

Then:

```sh
touch ~/.disable-gui
nix flake check
sudo nixos-rebuild test --flake .#thinkpad
rice-doctor
```

Only use `nix-apply` after the manual Sway test passes.

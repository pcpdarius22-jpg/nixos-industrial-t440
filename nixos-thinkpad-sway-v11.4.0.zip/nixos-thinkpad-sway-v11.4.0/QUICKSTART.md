# v11.4.0 quick start — ThinkPad T440

Do this **on the T440**, from the repo directory:

```sh
touch ~/.disable-gui
bash ./prepare.sh
nix flake check
sudo nixos-rebuild test --flake .#thinkpad
rice-doctor
```

`prepare.sh` refreshes the machine hardware config from `/etc/nixos` when
available and rejects storage UUIDs that do not exist on the current machine.

Test Sway manually from tty1:

```sh
theme-sync --startup
sway
```

Verify at least:

- qutebrowser opens and websites have their normal colors;
- new floating windows from different apps move into available space;
- Wi-Fi and Bluetooth work;
- audio and hardware volume/brightness keys work;
- suspend/resume works;
- `Super+Shift+E` exits back to tty1 cleanly.

Only then:

```sh
nix-apply
rm -f ~/.disable-gui ~/.disable-sway ~/.disable-x
flatpak-setup
sudo reboot
```

Useful keys: `Super+Enter` terminal, `Super+B` browser, `Super+W` wallpaper,
`Super+Shift+R` reference layout, `Super+Ctrl+R` reload Sway.

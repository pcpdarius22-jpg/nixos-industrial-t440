# v11.4.0 validation

## Static/package validation performed before packaging

- all repository shell scripts pass `bash -n`;
- `rice-window-organizer` compiles with Python;
- `flake.nix` and Home Manager files were checked for obvious reference/path
  mismatches;
- every `./scripts/...` source referenced by `user/theme.nix` exists;
- qutebrowser no longer sources a webpage CSS override;
- qutebrowser forced webpage dark mode is disabled;
- no config path references the missing old `773.jpg` or wallpaper license;
- theme generation creates a fresh-install fallback wallpaper;
- Sway contains no duplicate exact `bindsym` combinations;
- smart organizer startup is supervised by `rice-session` rather than duplicated;
- Flatpak is enabled together with the Sway/XDG portal path;
- hardware verification is called by prepare/test/sync/apply helpers;
- `nix-apply` tests before switching;
- ZIP integrity is tested after packaging.

## Hardware/runtime validation still required on the real T440

```sh
touch ~/.disable-gui
bash ./prepare.sh
nix flake check
sudo nixos-rebuild test --flake .#thinkpad
rice-doctor
```

Then from tty1:

```sh
theme-sync --startup
sway
```

Do not use the permanent switch until graphics, qutebrowser, smart placement,
Wi-Fi, Bluetooth, audio, hardware keys, suspend/resume and clean Sway exit have
all been exercised on the real machine.

# Wallpaper directory

v11.4.0 intentionally does not require a repository-bundled wallpaper.

On upgrade, your existing `~/.local/share/rice/wallpaper.jpg` is preserved.
On a fresh install, `theme-sync` creates a safe dark fallback so Sway can start.
Choose your real wallpaper with `Super+W` or:

```sh
set-wallpaper ~/Pictures/your-image.jpg
```

If you want `theme-sync --reset-reference` to restore a particular image, put it
at `~/.config/rice/reference/reference.jpg` after activation.

{ config, lib, pkgs, ... }:
{
  home.username = "sloth";
  home.homeDirectory = "/home/sloth";
  # Keep in lockstep with system.stateVersion in system/configuration.nix.
  home.stateVersion = "24.11";

  imports = [ ./apps.nix ./theme.nix ];

  home.sessionPath = [ "$HOME/.local/bin" ];
  fonts.fontconfig = {
    enable = true;
    defaultFonts = {
      monospace = [ "PxPlus IBM VGA 8x16" ];
      sansSerif = [ "PxPlus IBM VGA 8x16" ];
      serif = [ "PxPlus IBM VGA 8x16" ];
    };
  };

  home.sessionVariables = {
    XDG_CONFIG_HOME = "$HOME/.config";
    XDG_CACHE_HOME = "$HOME/.cache";
    XDG_DATA_HOME = "$HOME/.local/share";
    TERMINAL = "rice-foot";
    EDITOR = "nvim";
    VISUAL = "nvim";
    BROWSER = "qutebrowser";
  };

  gtk = {
    enable = true;
    colorScheme = "dark";
    font = {
      name = "PxPlus IBM VGA 8x16";
      size = 10;
    };
  };

  programs.bash = {
    enable = true;
    profileExtra = ''
      if [ -z "''${WAYLAND_DISPLAY:-}" ] \
         && [ -z "''${DISPLAY:-}" ] \
         && [ "$(tty 2>/dev/null || true)" = "/dev/tty1" ] \
         && [ ! -e "$HOME/.disable-gui" ] \
         && [ ! -e "$HOME/.disable-sway" ] \
         && [ ! -e "$HOME/.disable-x" ]; then
        "$HOME/.local/bin/theme-sync" --startup >/tmp/rice-theme.log 2>&1 || {
          printf '\nTheme preparation failed; staying on tty1. Log: /tmp/rice-theme.log\n'
          return 0 2>/dev/null || true
        }
        sway
        printf '\nSway exited. Staying on tty1. `touch ~/.disable-gui` disables autostart.\n'
      fi
    '';
    bashrcExtra = ''
      PS1='\[\e[38;5;7m\]\u@\h\[\e[0m\] \w $ '
    '';
  };

  programs.neovim = {
    enable = true;
    defaultEditor = true;
    viAlias = true;
    vimAlias = true;
    withRuby = false;
    withPython3 = false;
    initLua = ''
      vim.opt.number = false
      vim.opt.relativenumber = false
      vim.opt.cursorline = false
      vim.opt.termguicolors = true
      vim.opt.signcolumn = "no"
      vim.opt.laststatus = 0
      vim.opt.showmode = false
      vim.opt.ruler = false
      vim.opt.showcmd = false
      vim.opt.cmdheight = 1
      vim.opt.tabstop = 2
      vim.opt.shiftwidth = 2
      vim.opt.expandtab = true
      vim.opt.smartindent = true
      vim.opt.ignorecase = true
      vim.opt.smartcase = true
      vim.opt.updatetime = 250
      local p = vim.fn.expand("~/.config/rice/generated/nvim-colors.lua")
      if vim.fn.filereadable(p) == 1 then dofile(p) end
    '';
  };

  programs.tmux = {
    enable = true;
    baseIndex = 1;
    escapeTime = 0;
    mouse = true;
    terminal = "screen-256color";
    extraConfig = ''
      set -as terminal-features ',*:RGB'
      set -g status off
      if-shell '[ -f ~/.config/rice/generated/tmux.conf ]' 'source-file ~/.config/rice/generated/tmux.conf'
    '';
  };

  programs.mpv = {
    enable = true;
    config = {
      hwdec = "auto-safe";
      vo = "gpu-next";
      keep-open = "yes";
      save-position-on-quit = "yes";
      osc = "no";
    };
  };

  programs.home-manager.enable = true;
}

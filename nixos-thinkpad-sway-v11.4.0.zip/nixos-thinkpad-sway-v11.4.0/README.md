# ThinkPad T440 — NixOS/Sway monochrome rice v11.4.0

Personal NixOS 26.05 configuration for a Lenovo ThinkPad T440 with an
Intel i5-4300U, Intel HD 4400, 12 GB RAM and SSD storage.

v11.4.0 keeps the v11.3.3 visual direction but hardens the machine config and
adds smarter window placement, normal-color websites in qutebrowser and
Flatpak support.

## Visual target

- Dark Sway session with a full-color user wallpaper.
- Application chrome stays black / white / gray.
- **Websites keep their native colors.** qutebrowser itself remains monochrome.
- No Sway window borders, titlebar bezel, rounded corners or colored focus edge.
- Most daily apps open as deliberate floating rectangles rather than maximized
  desktop windows.
- Top-left clock and bottom-right workspace/battery/RAM status are Waybar layers
  with transparent layer surfaces and compact black text plates.
- PxPlus IBM VGA 8x16 is the primary UI/terminal font.

## v11.4.0 changes

### Critical safety fixes

- `verify-hardware.sh` checks every `/dev/disk/by-uuid/...` declared by the
  machine-specific hardware configuration before helper-driven rebuilds.
- `prepare.sh` prefers `/etc/nixos/hardware-configuration.nix` on the T440 and
  no longer searches a long list of stale v10/v11 folders by default.
- `nix-apply` now performs `flake check -> rebuild test -> rice-doctor -> switch`.
- Rebuild helpers only auto-discover the current repo locations instead of
  potentially selecting an old test tree.
- Root setup scripts have proper shebangs and are shipped executable in the ZIP;
  `bash ./prepare.sh` also works even when a web upload loses executable bits.
- The old broken `773.jpg` / `WALLPAPER-LICENSE.txt` dependency is gone. A fresh
  install can always start with a dark fallback; upgrades preserve the current
  `~/.local/share/rice/wallpaper.jpg`.

### Smart floating placement

`rice-window-organizer` subscribes to Sway's window IPC events. For new floating
windows it searches for nearby free screen space and minimizes overlap with
**different applications**. Windows belonging to the same app are allowed to
cascade/overlap so multi-window workflows remain natural. Native tiled windows
are untouched and continue to use Sway's own tiler. If an existing window is
later toggled into floating mode with `Super+Space`, it is organized then too.

`rice-session` supervises one organizer process, so Sway reloads do not create
multiple subscribers and a reload can restart it if it was killed.

### qutebrowser websites use normal colors

The monochrome qutebrowser tabs/status/completion UI is retained, but v11.4.0:

- disables qutebrowser webpage dark-mode forcing;
- stops loading the old generated `web.css` into webpages;
- removes stale `web.css` during theme generation.

Site content is therefore rendered with its own colors and theme choices.

### Flatpak

Flatpak is enabled at the NixOS level with XDG portals. Sway's NixOS integration
provides the wlroots/GTK portal pieces used by sandboxed desktop apps.

After the first successful v11.4.0 rebuild, add Flathub for your user with:

```sh
flatpak-setup
```

Then, for example:

```sh
flatpak search <name>
flatpak install flathub <app-id>
```

### Other fixes

- Dual-battery status is weighted by actual `energy_now/energy_full` (or charge
  values) instead of taking an incorrect 50/50 average of battery percentages.
- RAM comments/documentation now match the 12 GB T440.
- Waybar documentation now matches the actual 15 px black-backed edge labels.
- `rice-doctor` checks Flatpak and, inside Sway, the smart organizer process.

## Main stack

Sway, Foot, qutebrowser, Neovim, Yazi, btop, cmus, senpai, Dunst, Fuzzel,
Waybar, mpv, Zathura, NetworkManager, BlueZ/Blueman, PipeWire/WirePlumber,
TLP, thermald, zram, REAPER/Wine, RetroArch, Transmission/tremc and Flatpak.

## Safe first test

From the repository directory on the T440:

```sh
touch ~/.disable-gui
bash ./prepare.sh
nix flake check
sudo nixos-rebuild test --flake .#thinkpad
rice-doctor
```

Then test the graphical session manually from tty1:

```sh
theme-sync --startup
sway
```

Check qutebrowser, audio, Wi-Fi, Bluetooth, brightness/media keys, suspend/resume
and `Super+Shift+E` before making the generation permanent.

When satisfied:

```sh
nix-apply
rm -f ~/.disable-gui ~/.disable-sway ~/.disable-x
flatpak-setup
sudo reboot
```

## Wallpaper workflow

v11.4.0 does not require a repository-bundled image. Your current wallpaper is
preserved during upgrades. On a fresh install the session starts with a dark
fallback until you choose one:

```sh
set-wallpaper ~/Pictures/something.jpg
```

or press `Super+W`.

To give `theme-sync --reset-reference` a custom reference image, place it at:

```text
~/.config/rice/reference/reference.jpg
```

## Important keys

| Key | Action |
|---|---|
| `Super+Enter` | Foot terminal |
| `Super+D` | Fuzzel launcher |
| `Super+B` | qutebrowser |
| `Super+E` | Neovim |
| `Super+Y` | Yazi |
| `Super+X` | btop |
| `Super+M` | cmus |
| `Super+I` | senpai |
| `Super+W` | wallpaper picker |
| `Super+Shift+W` | NetworkManager TUI |
| `Super+Shift+B` | Blueman |
| `Super+Shift+A` | pulsemixer |
| `Super+Shift+F` | system/rice info |
| `Super+Shift+R` | reference window layout |
| `Super+Ctrl+R` | reload Sway |
| `Super+Space` | floating/tiled toggle |
| `Super+C` | center current window |
| `Super+F` | fullscreen |
| `Super+Q` | close window |
| `Super+Shift+H/J/K/L` | move floating window |
| `Super+Ctrl+H/J/K/L` | resize |
| `Super+Escape` | lock |
| `Super+Shift+S` | lock + suspend |
| `Super+Shift+E` | safely exit Sway to tty1 |

## T440-specific choices

- Intel Haswell / HD 4400 with i965 VA-API and 32-bit graphics support.
- 50% zram plus the machine's real hardware-declared disk swap.
- TLP: performance on AC, powersave on battery, 40-80% charge thresholds.
- thermald and SSD TRIM.
- PipeWire 48 kHz / 256-frame default with a 128-frame helper for production.
- tty1 autologin with recoverable Sway autostart; Sway exit/crash returns to a
  shell rather than restart-looping.
- three systemd-boot generations plus weekly generation/store cleanup.

## Helpers

- `nix-test` — verify hardware, flake check, temporary rebuild, doctor.
- `nix-apply` — verify, test, doctor, then permanent switch.
- `nix-sync` — fast-forward pull + safe test, never auto-switches.
- `rice-doctor` / `rice-check` — runtime/config checks.
- `audio-lowlatency` / `audio-normal` — PipeWire quantum override/reset.
- `reaper-pw` — launch REAPER against PipeWire JACK compatibility.
- `flatpak-setup` — add/update per-user Flathub.

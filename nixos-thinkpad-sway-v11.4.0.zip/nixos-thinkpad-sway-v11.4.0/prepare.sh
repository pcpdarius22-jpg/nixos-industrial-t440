#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="${1:-}"
DST="$ROOT/system/hardware-configuration.nix"

is_real_hw() {
  local p="$1"
  [ -f "$p" ] || return 1
  ! grep -q 'This is a safety placeholder' "$p" || return 1
  grep -q 'fileSystems\."/"' "$p" || return 1
}

source_hw() {
  local base="$1"
  if is_real_hw "$base/system/hardware-configuration.nix"; then
    printf '%s\n' "$base/system/hardware-configuration.nix"
  elif is_real_hw "$base/hardware-configuration.nix"; then
    printf '%s\n' "$base/hardware-configuration.nix"
  else
    return 1
  fi
}

copy_hw() {
  local p="$1"
  is_real_hw "$p" || return 1
  if [ -e "$DST" ] && [ "$(readlink -f "$p")" = "$(readlink -f "$DST")" ]; then
    return 2
  fi
  cp -f -- "$p" "$DST"
  echo "hardware config <- $p"
}

copy_lock() {
  local base="$1"
  [ -f "$base/flake.lock" ] || return 1
  cp -f -- "$base/flake.lock" "$ROOT/flake.lock"
  echo "flake.lock <- $base/flake.lock"
}

if [ -n "$SRC" ]; then
  HW="$(source_hw "$SRC")" || {
    echo "No real hardware-configuration.nix under: $SRC" >&2
    exit 1
  }
  copy_hw "$HW" || {
    rc=$?
    [ "$rc" -eq 2 ] || { echo "Failed to copy hardware config from: $HW" >&2; exit "$rc"; }
  }
  copy_lock "$SRC" || true
else
  if is_real_hw /etc/nixos/hardware-configuration.nix; then
    copy_hw /etc/nixos/hardware-configuration.nix || {
      rc=$?
      [ "$rc" -eq 2 ] || { echo "Failed to refresh hardware config from /etc/nixos." >&2; exit "$rc"; }
    }
  elif is_real_hw "$DST"; then
    echo "Using existing machine-specific hardware config: $DST"
  else
    echo "Could not find a real hardware-configuration.nix." >&2
    echo "Run this on the T440 after generating /etc/nixos/hardware-configuration.nix," >&2
    echo "or pass an old config directory explicitly: bash ./prepare.sh /path/to/old-config" >&2
    exit 1
  fi
fi

# Refuse to test/switch a hardware file whose UUIDs are absent on this machine.
bash "$ROOT/verify-hardware.sh" "$DST"

cd "$ROOT"
# Reconcile the lock file with the inputs declared by this release without
# intentionally upgrading already-locked inputs.
nix flake lock

if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  git add system/hardware-configuration.nix flake.lock 2>/dev/null || true
fi

printf '\nPrepared v11.4.0. Next commands:\n'
printf '  touch ~/.disable-gui\n'
printf '  nix flake check\n'
printf '  sudo nixos-rebuild test --flake .#thinkpad\n'
printf '  rice-doctor\n'
